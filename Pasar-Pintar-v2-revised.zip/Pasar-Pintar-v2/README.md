# Pasar Pintar Ecosystem (V2)

Platform digital untuk pasar tradisional: satu keranjang dari banyak lapak, satu pembayaran, pesanan lewat WhatsApp, kasir offline, dan kulakan bersama. Semua kanal (web, WhatsApp, kasir) membaca dan menulis **satu sumber kebenaran** untuk stok dan harga.

## Mulai cepat
1. `npm install`
2. Salin `.env.example` menjadi `.env`, isi semua nilai wajib (server menolak start jika kurang).
3. **Backup database**, lalu jalankan migrasi di staging dulu: `npm run db:migrate:v2` (butuh `DATABASE_URL`).
4. `npm test` (uji unit tanpa database) dan `npm run check` (cek sintaks).
5. `npm start`

## Dokumen
- `docs/CHANGES-V2.md`: apa yang diperbarui, apa yang dihapus, apa yang sebaiknya dihapus, dan risiko yang diketahui
- `docs/PANDUAN-V2.md`: migrasi, alur WhatsApp, kasir, kulakan bersama, ringkasan API, daftar uji manual

## Satu sumber kebenaran
| Data | Sumber tunggal | Dibaca oleh |
|---|---|---|
| Stok | `tbl_inventory` (diubah hanya lewat `StockService`) | katalog web, WhatsApp, kasir, checkout |
| Ketersediaan | view `v_product_availability` (stok dikurangi tahanan) | semua kanal |
| Harga | `tbl_product_prices` (baris terbaru = harga berlaku, riwayat tersimpan) | semua kanal |
| Penjualan | `v_sales_unified` (online + kasir) | laporan & KPI |


## Admin Control Center V2 (tambahan)
- Buka `/admin-v2.html` setelah login.
- Fitur: pengelolaan voucher, laporan jurnal, neraca saldo, laba rugi, neraca, mutasi kas/bank, periode akuntansi, integrasi API write-only, hak akses staf, telemetri server/database, worker heartbeat, dan audit log.
- Migrasi tambahan: `npm run db:migrate:v3` (WAJIB backup dan uji di staging setelah migrasi V2).
- Buat `INTEGRATION_ENCRYPTION_KEY` terpisah dari `JWT_SECRET` dengan `openssl rand -hex 32`. Kunci ini wajib dijaga; kehilangan kunci berarti secret integrasi yang tersimpan tidak dapat didekripsi.
- Izin staf: `admin.vouchers.manage`, `admin.finance.read`, `admin.finance.post`, `admin.integrations.manage`, `admin.access.manage`, `admin.operations.manage`, `admin.security.read`. Role 4 tetap Super Admin.
- Voucher diterapkan atomik di API `/api/v3/checkout` melalui `promo_code`. UI pelanggan lama masih menggunakan `/api/orders/checkout-v2`; integrasi antarmuka pelanggan ke checkout grup V3 dan perpindahan alur pembayaran/tempo belum dilakukan.
- Jurnal otomatis lama sengaja dihentikan sampai pemetaan komisi marketplace, utang merchant, subsidi voucher/ongkir, biaya gateway, pajak, dan settlement diverifikasi. Jangan menganggap laporan dari jurnal manual sebagai laporan perusahaan final sebelum saldo awal dan seluruh transaksi dimigrasikan.
