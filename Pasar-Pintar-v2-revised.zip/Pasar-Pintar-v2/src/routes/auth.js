'use strict';

const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { signToken } = require('../middleware/auth');
const { createRateLimiter } = require('../middleware/security');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// Hash palsu agar waktu respons login tidak membedakan "user ada" vs "user tidak ada".
const DUMMY_HASH = bcrypt.hashSync('pasar-pintar-dummy-password', 10);

const loginLimiter = createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 10,
    keyFn: (req) => `${req.ip}|${String(req.body?.username || '').toLowerCase()}`,
    message: 'Terlalu banyak percobaan login. Coba lagi dalam beberapa menit.'
});
const registerLimiter = createRateLimiter({
    windowMs: 60 * 60 * 1000,
    max: 10,
    message: 'Terlalu banyak pendaftaran dari alamat ini. Coba lagi nanti.'
});

function passwordProblem(password) {
    if (typeof password !== 'string' || password.length < 8) return 'Password minimal 8 karakter';
    if (password.length > 72) return 'Password maksimal 72 karakter';
    if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
        return 'Password harus mengandung huruf dan angka';
    }
    return null;
}

function usernameFrom(email, name) {
    const base = (email ? email.split('@')[0] : String(name || 'user'))
        .toLowerCase()
        .replace(/[^a-z0-9_]+/g, '_')
        .replace(/^_+|_+$/g, '')
        .slice(0, 40);
    return base || 'user';
}

module.exports = (pool, CommerceKernel) => {
    // 1. Pendaftaran (publik selalu Customer)
    router.post('/register', registerLimiter, async (req, res) => {
        const { name, email, password } = req.body || {};
        const role_id = 1;

        if (!email || !EMAIL_RE.test(String(email)) || String(email).length > 100) {
            return res.status(400).json({ error: 'Email tidak valid' });
        }
        const pwProblem = passwordProblem(password);
        if (pwProblem) return res.status(400).json({ error: pwProblem });

        try {
            const password_hash = await bcrypt.hash(password, 10);
            const baseUsername = usernameFrom(email, name);
            let newUser = null;

            for (let attempt = 0; attempt < 4 && !newUser; attempt += 1) {
                const username =
                    attempt === 0
                        ? baseUsername
                        : `${baseUsername}${Math.floor(1000 + Math.random() * 9000)}`;
                try {
                    const result = await pool.query(
                        `INSERT INTO tbl_users (username, email, password_hash, role_id)
                         VALUES ($1, $2, $3, $4)
                         RETURNING id, username, email, role_id`,
                        [username, String(email).toLowerCase(), password_hash, role_id]
                    );
                    newUser = result.rows[0];
                } catch (err) {
                    if (err.code !== '23505') throw err;
                    if (String(err.constraint || '').includes('email')) {
                        return res.status(409).json({ error: 'Email sudah terdaftar' });
                    }
                    // bentrok username -> coba dengan akhiran acak
                }
            }
            if (!newUser) {
                return res.status(409).json({ error: 'Gagal membuat username unik, coba lagi' });
            }

            CommerceKernel.emitEvent('USER_REGISTERED', 'USER', newUser.id, {
                userId: newUser.id,
                username: newUser.username,
                actor: newUser.username
            });
            return res.status(201).json({ status: 'success', user: newUser });
        } catch (err) {
            console.error('[REGISTER]', err.message);
            return res.status(500).json({ error: 'Gagal mendaftarkan akun' });
        }
    });

    // 2. Login (username atau email)
    router.post('/login', loginLimiter, async (req, res) => {
        const { username, password } = req.body || {};
        if (typeof username !== 'string' || typeof password !== 'string' || !username || !password) {
            return res.status(400).json({ error: 'Username dan password wajib diisi' });
        }
        try {
            const userResult = await pool.query(
                `SELECT * FROM tbl_users WHERE username = $1 OR email = LOWER($1) LIMIT 1`,
                [username]
            );
            const user = userResult.rows[0] || null;
            const match = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);

            if (!user || !match || user.is_active === false) {
                return res.status(401).json({ error: 'Username atau password salah' });
            }

            const token = signToken({
                id: user.id,
                username: user.username,
                role_id: user.role_id
            });

            CommerceKernel.emitEvent('USER_LOGGED_IN', 'USER', user.id, {
                userId: user.id,
                username: user.username,
                actor: user.username,
                ip: req.ip
            });
            return res.json({ status: 'success', token, role_id: user.role_id });
        } catch (err) {
            console.error('[LOGIN]', err.message);
            return res.status(500).json({ error: 'Terjadi kesalahan pada server' });
        }
    });

    return router;
};
