'use strict';

/**
 * Kulakan bersama (pembelian gabungan banyak lapak).
 *
 * Banyak lapak menyatakan komitmen jumlah untuk satu barang; setelah ditutup, harga
 * mengikuti tingkat (tier) yang tercapai dari total gabungan. Pasar Pintar TIDAK memegang
 * barang maupun uang: tiap lapak membayar bagiannya langsung ke prinsipal/distributor dan
 * barang dikirim langsung ke tiap lapak. Pasar Pintar hanya mencatat bagian pendapatannya
 * (platform_share_per_unit) saat pesanan selesai (settle).
 *
 *  POST /api/groupbuys                 admin: buat kampanye
 *  GET  /api/groupbuys                 admin/pedagang: daftar + proyeksi harga
 *  GET  /api/groupbuys/:id             detail
 *  POST /api/groupbuys/:id/commit      pedagang: ikut / ubah / tarik komitmen (quantity 0 = tarik)
 *  POST /api/groupbuys/:id/close       admin: tutup, tentukan harga akhir & alokasi
 *  POST /api/groupbuys/:id/settle      admin: barang sudah sampai -> catat pendapatan platform
 *  POST /api/groupbuys/:id/cancel      admin: batalkan
 */

const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, requireRole } = require('../middleware/auth');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const { normalizeTiers, tierFor, nextTier } = require('../services/groupbuy/tiers');

async function merchantIdOf(userId) {
    const r = await pool.query(
        `SELECT id FROM tbl_merchants WHERE user_id = $1 AND status = 'ACTIVE' LIMIT 1`,
        [userId]
    );
    return r.rows[0]?.id || null;
}

function present(row, myQty = null) {
    const total = Number(row.committed_qty || 0);
    const tiers = row.tiers || [];
    const now = tierFor(tiers, total);
    const next = nextTier(tiers, total);
    const baseline = Number(row.baseline_price);
    const price = row.final_unit_price !== null ? Number(row.final_unit_price) : now ? Number(now.unit_price) : null;
    return {
        id: row.id,
        title: row.title,
        item_name: row.item_name,
        unit: row.unit,
        principal_name: row.principal_name,
        status: row.status,
        closes_at: row.closes_at,
        baseline_price: baseline,
        tiers,
        min_total_qty: Number(row.min_total_qty),
        participants: Number(row.participants || 0),
        committed_qty: total,
        current_unit_price: price,
        saving_per_unit: price !== null ? baseline - price : 0,
        next_tier: next
            ? { min_qty: Number(next.min_qty), unit_price: Number(next.unit_price), kurang: Number(next.min_qty) - total }
            : null,
        my_quantity: myQty
    };
}

const LIST_SQL = `
    SELECT g.*,
           COALESCE(c.total, 0) AS committed_qty,
           COALESCE(c.n, 0) AS participants
    FROM tbl_group_buys g
    LEFT JOIN (
        SELECT group_buy_id, SUM(quantity) AS total, COUNT(*) AS n
        FROM tbl_group_buy_commitments GROUP BY group_buy_id
    ) c ON c.group_buy_id = g.id`;

router.post('/groupbuys', verifyToken, requireRole(4), async (req, res) => {
    const b = req.body || {};
    const tiers = normalizeTiers(b.tiers);
    const baseline = Number(b.baseline_price);
    const closesAt = new Date(b.closes_at);
    if (!b.title || !b.item_name || !tiers || !(baseline > 0) || Number.isNaN(closesAt.getTime()) || closesAt <= new Date()) {
        return res.status(400).json({
            error: 'title, item_name, baseline_price, closes_at (masa depan), dan tiers valid wajib diisi',
            hint: 'tiers: [{"min_qty":50,"unit_price":9500},{"min_qty":100,"unit_price":9000}] — makin banyak makin murah'
        });
    }
    try {
        const r = await pool.query(
            `INSERT INTO tbl_group_buys
               (title, item_name, unit, principal_name, baseline_price, tiers,
                min_total_qty, platform_share_per_unit, closes_at, created_by)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
             RETURNING *`,
            [
                String(b.title).slice(0, 200),
                String(b.item_name).slice(0, 200),
                String(b.unit || 'kg').slice(0, 20),
                b.principal_name ? String(b.principal_name).slice(0, 200) : null,
                baseline,
                JSON.stringify(tiers),
                Number(b.min_total_qty || 0),
                Number(b.platform_share_per_unit || 0),
                closesAt.toISOString(),
                req.user.id
            ]
        );
        res.status(201).json({ status: 'success', data: present({ ...r.rows[0], committed_qty: 0, participants: 0 }) });
    } catch (err) {
        console.error('[GROUPBUY CREATE]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

router.get('/groupbuys', verifyToken, requireRole(2, 4), async (req, res) => {
    try {
        const status = String(req.query.status || 'OPEN').toUpperCase();
        const rows = await pool.query(`${LIST_SQL} WHERE g.status = $1 ORDER BY g.closes_at ASC LIMIT 100`, [status]);
        let mine = new Map();
        if (Number(req.user.role_id) === 2) {
            const mid = await merchantIdOf(req.user.id);
            if (mid) {
                const c = await pool.query(
                    `SELECT group_buy_id, quantity FROM tbl_group_buy_commitments WHERE merchant_id = $1`,
                    [mid]
                );
                mine = new Map(c.rows.map((x) => [x.group_buy_id, Number(x.quantity)]));
            }
        }
        res.json({ status: 'success', data: rows.rows.map((r) => present(r, mine.get(r.id) ?? null)) });
    } catch (err) {
        console.error('[GROUPBUY LIST]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

router.get('/groupbuys/:id', verifyToken, requireRole(2, 4), async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    try {
        const g = await pool.query(`${LIST_SQL} WHERE g.id = $1`, [req.params.id]);
        if (!g.rowCount) return res.status(404).json({ error: 'Tidak ditemukan' });
        const out = present(g.rows[0]);
        if (Number(req.user.role_id) === 4) {
            const p = await pool.query(
                `SELECT c.merchant_id, m.store_name, c.quantity
                 FROM tbl_group_buy_commitments c JOIN tbl_merchants m ON m.id = c.merchant_id
                 WHERE c.group_buy_id = $1 ORDER BY m.store_name`,
                [req.params.id]
            );
            out.participants_detail = p.rows.map((r) => ({ ...r, quantity: Number(r.quantity) }));
        } else {
            const mid = await merchantIdOf(req.user.id);
            const mine = mid
                ? await pool.query(
                      `SELECT quantity FROM tbl_group_buy_commitments WHERE group_buy_id = $1 AND merchant_id = $2`,
                      [req.params.id, mid]
                  )
                : { rows: [] };
            out.my_quantity = mine.rows[0] ? Number(mine.rows[0].quantity) : null;
        }
        res.json({ status: 'success', data: out });
    } catch (err) {
        console.error('[GROUPBUY GET]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

router.post('/groupbuys/:id/commit', verifyToken, requireRole(2), async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    const qty = Number(req.body?.quantity);
    if (!Number.isFinite(qty) || qty < 0 || qty > 100000) {
        return res.status(400).json({ error: 'quantity harus 0 sampai 100000 (0 = tarik komitmen)' });
    }
    const client = await pool.connect();
    try {
        const mid = await merchantIdOf(req.user.id);
        if (!mid) return res.status(403).json({ error: 'Merchant aktif tidak ditemukan' });

        await client.query('BEGIN');
        const g = await client.query(`SELECT status, closes_at FROM tbl_group_buys WHERE id = $1 FOR UPDATE`, [req.params.id]);
        if (!g.rowCount) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Kulakan tidak ditemukan' });
        }
        if (g.rows[0].status !== 'OPEN' || new Date(g.rows[0].closes_at) <= new Date()) {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'Kulakan sudah ditutup' });
        }
        if (qty === 0) {
            await client.query(`DELETE FROM tbl_group_buy_commitments WHERE group_buy_id = $1 AND merchant_id = $2`, [req.params.id, mid]);
        } else {
            await client.query(
                `INSERT INTO tbl_group_buy_commitments (group_buy_id, merchant_id, quantity)
                 VALUES ($1, $2, $3)
                 ON CONFLICT (group_buy_id, merchant_id)
                 DO UPDATE SET quantity = EXCLUDED.quantity, updated_at = CURRENT_TIMESTAMP`,
                [req.params.id, mid, qty]
            );
        }
        await client.query('COMMIT');
        const out = await pool.query(`${LIST_SQL} WHERE g.id = $1`, [req.params.id]);
        res.json({ status: 'success', data: present(out.rows[0], qty || null) });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[GROUPBUY COMMIT]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    } finally {
        client.release();
    }
});

router.post('/groupbuys/:id/close', verifyToken, requireRole(4), async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const g = await client.query(`SELECT * FROM tbl_group_buys WHERE id = $1 FOR UPDATE`, [req.params.id]);
        if (!g.rowCount) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Kulakan tidak ditemukan' });
        }
        const group = g.rows[0];
        if (group.status !== 'OPEN') {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: `Status sekarang ${group.status}, hanya OPEN yang bisa ditutup` });
        }
        const commits = await client.query(
            `SELECT c.merchant_id, m.store_name, c.quantity
             FROM tbl_group_buy_commitments c JOIN tbl_merchants m ON m.id = c.merchant_id
             WHERE c.group_buy_id = $1 ORDER BY m.store_name`,
            [group.id]
        );
        const total = commits.rows.reduce((s, r) => s + Number(r.quantity), 0);
        const tier = tierFor(group.tiers, total);
        const success = Boolean(tier) && total >= Number(group.min_total_qty);

        await client.query(
            `UPDATE tbl_group_buys SET status = $2, total_qty = $3, final_unit_price = $4 WHERE id = $1`,
            [group.id, success ? 'CLOSED' : 'FAILED', total, success ? Number(tier.unit_price) : null]
        );
        await client.query('COMMIT');

        const baseline = Number(group.baseline_price);
        res.json({
            status: 'success',
            result: success ? 'CLOSED' : 'FAILED',
            total_qty: total,
            final_unit_price: success ? Number(tier.unit_price) : null,
            reason: success ? null : 'Total komitmen belum mencapai tingkat harga atau minimum jumlah',
            allocation: success
                ? commits.rows.map((r) => ({
                      merchant_id: r.merchant_id,
                      store_name: r.store_name,
                      quantity: Number(r.quantity),
                      amount_to_pay_principal: Math.round(Number(r.quantity) * Number(tier.unit_price)),
                      saving_vs_baseline: Math.round(Number(r.quantity) * (baseline - Number(tier.unit_price)))
                  }))
                : [],
            note: 'Tiap lapak membayar langsung ke prinsipal; Pasar Pintar tidak memegang uang atau barang.'
        });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[GROUPBUY CLOSE]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    } finally {
        client.release();
    }
});

router.post('/groupbuys/:id/settle', verifyToken, requireRole(4), async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const g = await client.query(`SELECT * FROM tbl_group_buys WHERE id = $1 FOR UPDATE`, [req.params.id]);
        if (!g.rowCount) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Kulakan tidak ditemukan' });
        }
        const group = g.rows[0];
        if (group.status !== 'CLOSED') {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'Hanya kulakan berstatus CLOSED yang bisa diselesaikan' });
        }
        const revenue = Math.round(Number(group.total_qty) * Number(group.platform_share_per_unit));
        if (revenue > 0) {
            await client.query(
                `INSERT INTO tbl_platform_revenue (source, ref_type, ref_id, amount, note)
                 VALUES ('B2B_REBATE', 'GROUP_BUY', $1, $2, $3)`,
                [group.id, revenue, `Kulakan bersama: ${group.title}`]
            );
        }
        await client.query(`UPDATE tbl_group_buys SET status = 'DELIVERED' WHERE id = $1`, [group.id]);
        await client.query('COMMIT');
        res.json({ status: 'success', platform_revenue_recorded: revenue });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[GROUPBUY SETTLE]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    } finally {
        client.release();
    }
});

router.post('/groupbuys/:id/cancel', verifyToken, requireRole(4), async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    try {
        const r = await pool.query(
            `UPDATE tbl_group_buys SET status = 'CANCELLED'
             WHERE id = $1 AND status IN ('OPEN','CLOSED') RETURNING id`,
            [req.params.id]
        );
        if (!r.rowCount) return res.status(409).json({ error: 'Tidak bisa dibatalkan pada status sekarang' });
        res.json({ status: 'success' });
    } catch (err) {
        console.error('[GROUPBUY CANCEL]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

module.exports = router;
