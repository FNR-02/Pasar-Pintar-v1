'use strict';
const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { requireAdminPermission } = require('../middleware/adminAccess');
router.get('/finance/ledger', ...requireAdminPermission(pool, 'admin.finance.read'), async (req,res)=>{
  try {
    const result = await pool.query(
      `SELECT h.id,h.journal_number,h.journal_date,h.description,h.source_type,h.source_reference,
              h.status,a.account_code,a.account_name,l.line_description,l.debit,l.credit,h.posted_at
       FROM tbl_journal_entries h
       JOIN tbl_journal_lines l ON l.journal_id=h.id
       JOIN tbl_chart_of_accounts a ON a.id=l.account_id
       ORDER BY h.journal_date DESC,h.journal_number DESC,l.id LIMIT 500`
    );
    res.json({status:'success',total_records:result.rowCount,ledger:result.rows});
  } catch(err) {
    console.error('[FINANCE LEDGER]',err.message);
    res.status(500).json({error:'Terjadi kesalahan pada server'});
  }
});
module.exports = router;
