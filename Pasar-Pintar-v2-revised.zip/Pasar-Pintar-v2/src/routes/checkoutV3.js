'use strict';

/**
 * Checkout V3 - satu keranjang, banyak lapak, satu pembayaran.
 *
 *  POST /api/v3/checkout/quote          hitung subtotal per lapak + ongkir (tanpa menyimpan)
 *  POST /api/v3/checkout                buat grup + order per lapak + tahan stok
 *  POST /api/v3/checkout/:id/pay        buat QRIS untuk seluruh grup
 *  GET  /api/v3/checkout/:id            status grup
 *  GET  /api/v3/shipping/zones          zona antar yang aktif
 */

const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, requireRole } = require('../middleware/auth');
const CommerceKernel = require('../kernel/EventKernel');
const GroupCheckoutService = require('../services/checkout/GroupCheckoutService');
const GroupPaymentService = require('../services/payments/GroupPaymentService');
const ShippingService = require('../services/shipping/ShippingService');

const { CheckoutError } = GroupCheckoutService;

async function resolveCustomerId(db, userId) {
    const r = await db.query(`SELECT id FROM tbl_customers WHERE user_id = $1 LIMIT 1`, [userId]);
    return r.rows[0]?.id || null;
}

function handleError(res, err, tag) {
    if (err instanceof CheckoutError || err instanceof ShippingService.ShippingError) {
        return res.status(err.httpStatus || 400).json({
            error: err.message,
            code: err.code,
            product_id: err.product_id,
            available: err.available,
            min_order: err.min_order
        });
    }
    console.error(`[${tag}]`, err.message);
    return res.status(500).json({ error: 'Terjadi kesalahan pada server' });
}

router.get('/v3/shipping/zones', verifyToken, requireRole(1, 4), async (req, res) => {
    try {
        const r = await pool.query(
            `SELECT id, name, base_fee, free_above, min_order, eta_minutes
             FROM tbl_delivery_zones WHERE active = TRUE ORDER BY id`
        );
        res.json({ status: 'success', data: r.rows });
    } catch (err) {
        handleError(res, err, 'ZONES');
    }
});

router.post('/v3/checkout/quote', verifyToken, requireRole(1), async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const customerId = await resolveCustomerId(client, req.user.id);
        if (!customerId) throw new CheckoutError('NO_CUSTOMER', 'Profil pelanggan belum lengkap', 400);
        // Simulasi di dalam transaksi yang selalu di-ROLLBACK: tidak ada yang tersimpan.
        const result = await GroupCheckoutService.createFromItems(client, {
            customerId,
            items: req.body.items,
            fulfillmentType: req.body.fulfillment_type,
            shippingAddress: req.body.shipping_address || 'simulasi',
            zoneId: req.body.zone_id || null,
            channel: 'WEB',
            promoCode: req.body.promo_code
        });
        await client.query('ROLLBACK');
        res.json({
            status: 'success',
            data: {
                subtotal: result.subtotal,
                shipping: result.shipping,
                discount_amount: result.discount_amount || 0,
                voucher_code: result.voucher_code || null,
                total_amount: result.total_amount,
                stores: result.orders.map((o) => ({
                    store_name: o.store_name,
                    subtotal: Number(o.total_amount),
                    lines: o.lines
                }))
            }
        });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        handleError(res, err, 'CHECKOUT QUOTE');
    } finally {
        client.release();
    }
});

router.post('/v3/checkout', verifyToken, requireRole(1), async (req, res) => {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const customerId = await resolveCustomerId(client, req.user.id);
        if (!customerId) throw new CheckoutError('NO_CUSTOMER', 'Profil pelanggan belum lengkap', 400);

        const result = await GroupCheckoutService.createFromItems(client, {
            customerId,
            items: req.body.items,
            fulfillmentType: req.body.fulfillment_type,
            shippingAddress: req.body.shipping_address,
            zoneId: req.body.zone_id || null,
            channel: 'WEB',
            promoCode: req.body.promo_code
        });
        await client.query('COMMIT');

        for (const order of result.orders) {
            CommerceKernel.emitEvent('ORDER_CREATED', 'ORDER', order.id, {
                id: order.id,
                customer_id: order.customer_id,
                merchant_id: order.merchant_id,
                status: order.status,
                total_amount: order.total_amount,
                checkout_group_id: result.group.id
            });
        }

        res.status(201).json({
            status: 'success',
            data: {
                group_id: result.group.id,
                subtotal: result.subtotal,
                shipping: result.shipping,
                discount_amount: result.discount_amount || 0,
                voucher_code: result.voucher_code || null,
                total_amount: result.total_amount,
                orders: result.orders.map((o) => ({
                    order_id: o.id,
                    store_name: o.store_name,
                    subtotal: Number(o.total_amount),
                    lines: o.lines
                })),
                next: `POST /api/v3/checkout/${result.group.id}/pay`
            }
        });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        handleError(res, err, 'CHECKOUT V3');
    } finally {
        client.release();
    }
});

router.post('/v3/checkout/:id/pay', verifyToken, requireRole(1), async (req, res) => {
    try {
        const customerId = await resolveCustomerId(pool, req.user.id);
        if (!customerId) return res.status(400).json({ error: 'Profil pelanggan belum lengkap' });

        const result = await GroupPaymentService.createIntent(pool, {
            groupId: req.params.id,
            customerId,
            paymentMethod: req.body.payment_method || 'QRIS'
        });

        const map = {
            group_not_found: [404, 'Pesanan tidak ditemukan'],
            forbidden: [403, 'Akses ditolak'],
            group_not_pending: [409, 'Pesanan sudah tidak menunggu pembayaran'],
            unsupported_method: [400, 'Metode pembayaran belum didukung']
        };
        if (map[result.status]) {
            return res.status(map[result.status][0]).json({ error: map[result.status][1] });
        }
        if (result.status === 'expired') {
            return res.status(410).json({ error: 'QRIS kedaluwarsa, silakan buat pesanan baru' });
        }

        const g = result.group;
        const gateway = g.gateway_response || {};
        res.status(result.status === 'created' ? 201 : 200).json({
            status: 'success',
            data: {
                group_id: g.id,
                total_amount: Number(g.total_amount),
                payment_method: g.payment_method,
                expires_at: g.payment_expires_at,
                qr_code_url: gateway.qr_code_url || null
            }
        });
    } catch (err) {
        handleError(res, err, 'CHECKOUT PAY');
    }
});

router.get('/v3/checkout/:id', verifyToken, requireRole(1, 4), async (req, res) => {
    try {
        const g = await pool.query(
            `SELECT g.*, c.user_id
             FROM tbl_checkout_groups g
             JOIN tbl_customers c ON c.id = g.customer_id
             WHERE g.id = $1`,
            [req.params.id]
        );
        if (!g.rowCount) return res.status(404).json({ error: 'Pesanan tidak ditemukan' });
        const group = g.rows[0];
        if (Number(req.user.role_id) === 1 && group.user_id !== req.user.id) {
            return res.status(403).json({ error: 'Akses ditolak' });
        }
        const orders = await pool.query(
            `SELECT o.id, o.merchant_id, m.store_name, o.status, o.total_amount
             FROM tbl_checkout_group_orders x
             JOIN tbl_orders_v2 o ON o.id = x.order_id
             JOIN tbl_merchants m ON m.id = o.merchant_id
             WHERE x.group_id = $1`,
            [group.id]
        );
        res.json({
            status: 'success',
            data: {
                group_id: group.id,
                status: group.status,
                subtotal: Number(group.subtotal),
                shipping_fee: Number(group.shipping_fee),
                discount_amount: Number(group.discount_amount || 0),
                voucher_code: group.voucher_code || null,
                total_amount: Number(group.total_amount),
                paid_at: group.paid_at,
                orders: orders.rows
            }
        });
    } catch (err) {
        handleError(res, err, 'CHECKOUT GET');
    }
});

module.exports = router;
