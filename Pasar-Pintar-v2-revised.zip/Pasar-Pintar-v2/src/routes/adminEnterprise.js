'use strict';
const express = require('express');
const os = require('os');
const { requireAdminPermission } = require('../middleware/adminAccess');
const { verifyToken, requireRole } = require('../middleware/auth');
const Vault = require('../services/SecretVault');
const router = express.Router();
const pool = require('../config/db');
const admin = (permission) => requireAdminPermission(pool, permission);
const money = (v) => Number(v || 0);
const allowedIntegrations = new Set(['MIDTRANS','XENDIT','WHATSAPP_EVOLUTION','GEMINI','FCM','SMTP','MAPS','STORAGE']);
const asyncRoute = (fn) => (req,res,next) => Promise.resolve(fn(req,res,next)).catch((e)=>{ console.error('[ADMIN ENTERPRISE]',e.message); res.status(500).json({error:'Terjadi kesalahan pada server'}); });
async function audit(db, req, action, type, id, metadata={}) {
  await db.query(`INSERT INTO tbl_admin_audit_events(actor_id,action,resource_type,resource_id,ip_address,user_agent,metadata) VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)`,
    [req.user.id,action,type,id || null,req.ip,req.get('user-agent') || null,JSON.stringify(metadata)]);
}

// Vouchers: administration. Redemption is applied atomically by GroupCheckoutService.
router.get('/admin/vouchers', ...admin('admin.vouchers.manage'), asyncRoute(async(req,res)=>{
  const r=await pool.query(`SELECT id,code,name,description,discount_type,discount_value,min_order_amount,max_discount_amount,usage_limit,per_user_limit,usage_count,starts_at,ends_at,is_active,created_at FROM tbl_vouchers ORDER BY created_at DESC LIMIT 200`);
  res.json({status:'success',data:r.rows});
}));
router.post('/admin/vouchers', ...admin('admin.vouchers.manage'), asyncRoute(async(req,res)=>{
  const b=req.body||{}; const code=String(b.code||'').trim().toUpperCase(); const name=String(b.name||'').trim();
  const type=String(b.discount_type||'').toUpperCase(); const value=money(b.discount_value); const min=money(b.min_order_amount);
  const starts=new Date(b.starts_at), ends=new Date(b.ends_at); const max=b.max_discount_amount==null?null:money(b.max_discount_amount);
  if(!/^[A-Z0-9_-]{3,40}$/.test(code)||!name||name.length>140) return res.status(400).json({error:'Kode/nama voucher tidak valid'});
  if(!['PERCENT','FIXED','FREE_SHIPPING'].includes(type)||!Number.isFinite(value)||value<0||!Number.isFinite(min)||min<0) return res.status(400).json({error:'Aturan diskon tidak valid'});
  if((type==='PERCENT'&&(value<=0||value>100))||(type==='FIXED'&&value<=0)||(type==='FREE_SHIPPING'&&value!==0)) return res.status(400).json({error:'Nilai diskon tidak sesuai jenis voucher'});
  if(max!==null&&(!Number.isFinite(max)||max<=0)) return res.status(400).json({error:'Batas diskon tidak valid'});
  if(!Number.isFinite(starts.getTime())||!Number.isFinite(ends.getTime())||ends<=starts) return res.status(400).json({error:'Periode voucher tidak valid'});
  const usage=b.usage_limit==null?null:Number(b.usage_limit), per=Number(b.per_user_limit||1);
  if((usage!==null&&(!Number.isInteger(usage)||usage<1))||!Number.isInteger(per)||per<1) return res.status(400).json({error:'Batas pemakaian tidak valid'});
  const c=await pool.connect(); try { await c.query('BEGIN');
    const r=await c.query(`INSERT INTO tbl_vouchers(code,name,description,discount_type,discount_value,min_order_amount,max_discount_amount,usage_limit,per_user_limit,starts_at,ends_at,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,[code,name,b.description||null,type,value,min,max,usage,per,starts,ends,req.user.id]);
    await audit(c,req,'VOUCHER_CREATED','VOUCHER',r.rows[0].id,{code,type}); await c.query('COMMIT'); res.status(201).json({status:'success',data:r.rows[0]});
  } catch(e){await c.query('ROLLBACK'); if(e.code==='23505') return res.status(409).json({error:'Kode voucher sudah digunakan'}); throw e;} finally{c.release();}
}));
router.patch('/admin/vouchers/:id/status', ...admin('admin.vouchers.manage'), asyncRoute(async(req,res)=>{
  if(typeof req.body?.is_active!=='boolean') return res.status(400).json({error:'is_active harus boolean'});
  const r=await pool.query(`UPDATE tbl_vouchers SET is_active=$1,updated_at=CURRENT_TIMESTAMP WHERE id=$2 RETURNING id,code,is_active`,[req.body.is_active,req.params.id]);
  if(!r.rowCount) return res.status(404).json({error:'Voucher tidak ditemukan'});
  await audit(pool,req,req.body.is_active?'VOUCHER_ENABLED':'VOUCHER_DISABLED','VOUCHER',req.params.id); res.json({status:'success',data:r.rows[0]});
}));

// Finance: posted, balanced double-entry journals only. No fake revenue is inferred from order totals.
router.get('/admin/finance/accounts', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT id,account_code,account_name,account_type,normal_balance,parent_id,is_cash_account,is_active FROM tbl_chart_of_accounts ORDER BY account_code`); res.json({status:'success',data:r.rows});
}));
router.post('/admin/finance/accounts', ...admin('admin.finance.post'), asyncRoute(async(req,res)=>{
 const b=req.body||{}; const code=String(b.account_code||'').trim(); const name=String(b.account_name||'').trim(); const type=String(b.account_type||'').toUpperCase(); const normal=String(b.normal_balance||'').toUpperCase();
 if(!/^[0-9A-Z.-]{3,20}$/.test(code)||!name||name.length>140||!['ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE'].includes(type)||!['DEBIT','CREDIT'].includes(normal)) return res.status(400).json({error:'Kode, nama, tipe, atau saldo normal akun tidak valid'});
 const expected={ASSET:'DEBIT',EXPENSE:'DEBIT',LIABILITY:'CREDIT',EQUITY:'CREDIT',REVENUE:'CREDIT'}[type]; if(normal!==expected) return res.status(400).json({error:'Saldo normal tidak sesuai tipe akun'});
 const r=await pool.query(`INSERT INTO tbl_chart_of_accounts(account_code,account_name,account_type,normal_balance,parent_id,is_cash_account) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[code,name,type,normal,b.parent_id||null,Boolean(b.is_cash_account)]);
 await audit(pool,req,'ACCOUNT_CREATED','ACCOUNT',r.rows[0].id,{code,type}); res.status(201).json({status:'success',data:r.rows[0]});
}));
router.post('/admin/finance/periods', ...admin('admin.finance.post'), asyncRoute(async(req,res)=>{
 const b=req.body||{}; const a=new Date(b.starts_on), z=new Date(b.ends_on);
 if(!b.period_name||!Number.isFinite(a.getTime())||!Number.isFinite(z.getTime())||z<a) return res.status(400).json({error:'Periode tidak valid'});
 const r=await pool.query(`INSERT INTO tbl_accounting_periods(period_name,starts_on,ends_on) VALUES($1,$2,$3) RETURNING *`,[String(b.period_name).slice(0,40),b.starts_on,b.ends_on]);
 await audit(pool,req,'ACCOUNTING_PERIOD_CREATED','ACCOUNTING_PERIOD',r.rows[0].id); res.status(201).json({status:'success',data:r.rows[0]});
}));
router.post('/admin/finance/journals', ...admin('admin.finance.post'), asyncRoute(async(req,res)=>{
 const b=req.body||{}, lines=b.lines;
 if(!/^\d{4}-\d{2}-\d{2}$/.test(String(b.journal_date||''))||!String(b.description||'').trim()||!Array.isArray(lines)||lines.length<2||lines.length>100) return res.status(400).json({error:'Tanggal, deskripsi, dan minimal dua baris jurnal wajib diisi'});
 let debit=0,credit=0; for(const l of lines){const d=money(l.debit),c=money(l.credit); if(!l.account_id||!Number.isFinite(d)||!Number.isFinite(c)||d<0||c<0||((d>0)===(c>0))) return res.status(400).json({error:'Setiap baris harus memiliki tepat satu nilai debit atau kredit positif'}); debit+=d;credit+=c;}
 if(debit<=0||Math.abs(debit-credit)>0.005) return res.status(400).json({error:'Jurnal tidak seimbang',total_debit:debit,total_credit:credit});
 const c=await pool.connect(); try{await c.query('BEGIN');
  const period=await c.query(`SELECT * FROM tbl_accounting_periods WHERE $1::date BETWEEN starts_on AND ends_on FOR UPDATE`,[b.journal_date]);
  if(!period.rowCount||period.rows[0].status!=='OPEN') throw Object.assign(new Error('Periode akuntansi belum dibuat atau sudah ditutup'),{http:409});
  const ids=[...new Set(lines.map(x=>x.account_id))]; const accounts=await c.query(`SELECT id FROM tbl_chart_of_accounts WHERE id=ANY($1::uuid[]) AND is_active=TRUE`,[ids]);
  if(accounts.rowCount!==ids.length) throw Object.assign(new Error('Akun tidak ditemukan atau tidak aktif'),{http:400});
  const h=await c.query(`INSERT INTO tbl_journal_entries(journal_date,period_id,description,source_type,source_reference,created_by) VALUES($1,$2,$3,'MANUAL',$4,$5) RETURNING *`,[b.journal_date,period.rows[0].id,String(b.description).trim(),b.source_reference||null,req.user.id]);
  for(const l of lines) await c.query(`INSERT INTO tbl_journal_lines(journal_id,account_id,line_description,debit,credit) VALUES($1,$2,$3,$4,$5)`,[h.rows[0].id,l.account_id,l.description||null,money(l.debit),money(l.credit)]);
  await audit(c,req,'JOURNAL_POSTED','JOURNAL',h.rows[0].id,{total:debit,lines:lines.length}); await c.query('COMMIT'); res.status(201).json({status:'success',data:{...h.rows[0],total_debit:debit,total_credit:credit}});
 }catch(e){await c.query('ROLLBACK'); if(e.http) return res.status(e.http).json({error:e.message}); throw e;}finally{c.release();}
}));
router.get('/admin/finance/journals', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const from=req.query.from||'1900-01-01',to=req.query.to||'2999-12-31'; const r=await pool.query(`SELECT h.id,h.journal_number,h.journal_date,h.description,h.source_type,h.source_reference,h.status,h.posted_at,COALESCE(SUM(l.debit),0) total_debit,COALESCE(SUM(l.credit),0) total_credit FROM tbl_journal_entries h LEFT JOIN tbl_journal_lines l ON l.journal_id=h.id WHERE h.journal_date BETWEEN $1::date AND $2::date GROUP BY h.id ORDER BY h.journal_date DESC,h.journal_number DESC LIMIT 500`,[from,to]); res.json({status:'success',data:r.rows});
}));
router.get('/admin/finance/trial-balance', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const asOf=req.query.as_of||new Date().toISOString().slice(0,10); const r=await pool.query(`SELECT a.account_code,a.account_name,a.account_type,a.normal_balance,COALESCE(SUM(CASE WHEN h.id IS NOT NULL THEN l.debit ELSE 0 END),0) debit,COALESCE(SUM(CASE WHEN h.id IS NOT NULL THEN l.credit ELSE 0 END),0) credit,CASE WHEN a.normal_balance='DEBIT' THEN COALESCE(SUM(CASE WHEN h.id IS NOT NULL THEN l.debit-l.credit ELSE 0 END),0) ELSE COALESCE(SUM(CASE WHEN h.id IS NOT NULL THEN l.credit-l.debit ELSE 0 END),0) END balance FROM tbl_chart_of_accounts a LEFT JOIN tbl_journal_lines l ON l.account_id=a.id LEFT JOIN tbl_journal_entries h ON h.id=l.journal_id AND h.status='POSTED' AND h.journal_date<=$1::date WHERE a.is_active=TRUE GROUP BY a.id ORDER BY a.account_code`,[asOf]); res.json({status:'success',as_of:asOf,data:r.rows,totals:{debit:r.rows.reduce((s,x)=>s+money(x.debit),0),credit:r.rows.reduce((s,x)=>s+money(x.credit),0)}});
}));
router.get('/admin/finance/income-statement', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const from=req.query.from||`${new Date().getUTCFullYear()}-01-01`,to=req.query.to||new Date().toISOString().slice(0,10); const r=await pool.query(`SELECT a.account_code,a.account_name,a.account_type,CASE WHEN a.account_type='REVENUE' THEN SUM(l.credit-l.debit) ELSE SUM(l.debit-l.credit) END amount FROM tbl_chart_of_accounts a JOIN tbl_journal_lines l ON l.account_id=a.id JOIN tbl_journal_entries h ON h.id=l.journal_id AND h.status='POSTED' WHERE a.account_type IN ('REVENUE','EXPENSE') AND h.journal_date BETWEEN $1::date AND $2::date GROUP BY a.id ORDER BY a.account_type,a.account_code`,[from,to]); const revenue=r.rows.filter(x=>x.account_type==='REVENUE').reduce((s,x)=>s+money(x.amount),0),expenses=r.rows.filter(x=>x.account_type==='EXPENSE').reduce((s,x)=>s+money(x.amount),0); res.json({status:'success',period:{from,to},data:r.rows,totals:{revenue,expenses,net_profit:revenue-expenses}});
}));
router.get('/admin/finance/balance-sheet', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const asOf=req.query.as_of||new Date().toISOString().slice(0,10); const r=await pool.query(`SELECT a.account_code,a.account_name,a.account_type,CASE WHEN a.normal_balance='DEBIT' THEN SUM(l.debit-l.credit) ELSE SUM(l.credit-l.debit) END balance FROM tbl_chart_of_accounts a JOIN tbl_journal_lines l ON l.account_id=a.id JOIN tbl_journal_entries h ON h.id=l.journal_id AND h.status='POSTED' AND h.journal_date<=$1::date WHERE a.account_type IN ('ASSET','LIABILITY','EQUITY') GROUP BY a.id ORDER BY a.account_code`,[asOf]); const sum=t=>r.rows.filter(x=>x.account_type===t).reduce((s,x)=>s+money(x.balance),0); res.json({status:'success',as_of:asOf,data:r.rows,totals:{assets:sum('ASSET'),liabilities:sum('LIABILITY'),equity:sum('EQUITY'),liabilities_and_equity:sum('LIABILITY')+sum('EQUITY')}});
}));
router.post('/admin/finance/journals/:id/reverse', ...admin('admin.finance.post'), asyncRoute(async(req,res)=>{
 const c=await pool.connect(); try{await c.query('BEGIN'); const h=await c.query(`SELECT * FROM tbl_journal_entries WHERE id=$1 FOR UPDATE`,[req.params.id]); if(!h.rowCount) throw Object.assign(new Error('Jurnal tidak ditemukan'),{http:404}); if(h.rows[0].status!=='POSTED') throw Object.assign(new Error('Jurnal tidak berstatus POSTED'),{http:409}); const p=await c.query(`SELECT status FROM tbl_accounting_periods WHERE id=$1 FOR UPDATE`,[h.rows[0].period_id]); if(p.rows[0]?.status!=='OPEN') throw Object.assign(new Error('Periode jurnal sudah ditutup'),{http:409}); const lines=await c.query(`SELECT account_id,line_description,debit,credit FROM tbl_journal_lines WHERE journal_id=$1`,[req.params.id]); const rev=await c.query(`INSERT INTO tbl_journal_entries(journal_date,period_id,description,source_type,source_reference,created_by,reversal_of) VALUES($6,$1,$2,'REVERSAL',$3,$4,$5) RETURNING *`,[h.rows[0].period_id,`Pembalikan jurnal #${h.rows[0].journal_number}`,String(h.rows[0].journal_number),req.user.id,h.rows[0].id,h.rows[0].journal_date]); for(const l of lines.rows) await c.query(`INSERT INTO tbl_journal_lines(journal_id,account_id,line_description,debit,credit) VALUES($1,$2,$3,$4,$5)`,[rev.rows[0].id, l.account_id,`Pembalikan: ${l.line_description||''}`,l.credit,l.debit]); await c.query(`UPDATE tbl_journal_entries SET status='REVERSED' WHERE id=$1`,[h.rows[0].id]); await audit(c,req,'JOURNAL_REVERSED','JOURNAL',h.rows[0].id,{reversal_id:rev.rows[0].id}); await c.query('COMMIT'); res.status(201).json({status:'success',data:rev.rows[0]}); }catch(e){await c.query('ROLLBACK'); if(e.http)return res.status(e.http).json({error:e.message}); throw e;}finally{c.release();}
}));

router.get('/admin/finance/general-ledger', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const {account_code,from='1900-01-01',to='2999-12-31'}=req.query;
 if(!account_code) return res.status(400).json({error:'account_code wajib diisi'});
 const r=await pool.query(`SELECT h.journal_number,h.journal_date,h.description,h.source_type,h.source_reference,l.line_description,l.debit,l.credit FROM tbl_journal_entries h JOIN tbl_journal_lines l ON l.journal_id=h.id JOIN tbl_chart_of_accounts a ON a.id=l.account_id WHERE a.account_code=$1 AND h.status='POSTED' AND h.journal_date BETWEEN $2::date AND $3::date ORDER BY h.journal_date,h.journal_number`,[account_code,from,to]);
 res.json({status:'success',account_code,period:{from,to},data:r.rows});
}));
router.get('/admin/finance/cash-movement', ...admin('admin.finance.read'), asyncRoute(async(req,res)=>{
 const from=req.query.from||`${new Date().getUTCFullYear()}-01-01`,to=req.query.to||new Date().toISOString().slice(0,10);
 const r=await pool.query(`SELECT a.account_code,a.account_name,COALESCE(SUM(l.debit),0) inflow,COALESCE(SUM(l.credit),0) outflow,COALESCE(SUM(l.debit-l.credit),0) net_movement FROM tbl_chart_of_accounts a JOIN tbl_journal_lines l ON l.account_id=a.id JOIN tbl_journal_entries h ON h.id=l.journal_id AND h.status='POSTED' WHERE a.is_cash_account=TRUE AND h.journal_date BETWEEN $1::date AND $2::date GROUP BY a.id ORDER BY a.account_code`,[from,to]);
 res.json({status:'success',period:{from,to},data:r.rows,totals:{inflow:r.rows.reduce((n,x)=>n+money(x.inflow),0),outflow:r.rows.reduce((n,x)=>n+money(x.outflow),0),net_movement:r.rows.reduce((n,x)=>n+money(x.net_movement),0)},note:'Ringkasan mutasi akun kas/bank; belum merupakan laporan arus kas metode langsung/tidak langsung.'});
}));
router.post('/admin/finance/periods/:id/close', ...admin('admin.finance.post'), asyncRoute(async(req,res)=>{
 const c=await pool.connect(); try{await c.query('BEGIN'); const p=await c.query(`SELECT * FROM tbl_accounting_periods WHERE id=$1 FOR UPDATE`,[req.params.id]); if(!p.rowCount) throw Object.assign(new Error('Periode tidak ditemukan'),{http:404}); if(p.rows[0].status!=='OPEN') throw Object.assign(new Error('Periode sudah ditutup'),{http:409});
 const check=await c.query(`SELECT COALESCE(SUM(l.debit),0) debit,COALESCE(SUM(l.credit),0) credit FROM tbl_journal_entries h JOIN tbl_journal_lines l ON l.journal_id=h.id WHERE h.period_id=$1 AND h.status='POSTED'`,[req.params.id]); if(Math.abs(money(check.rows[0].debit)-money(check.rows[0].credit))>0.005) throw Object.assign(new Error('Periode tidak seimbang; penutupan dibatalkan'),{http:409});
 await c.query(`UPDATE tbl_accounting_periods SET status='CLOSED',closed_by=$1,closed_at=CURRENT_TIMESTAMP WHERE id=$2`,[req.user.id,req.params.id]); await audit(c,req,'ACCOUNTING_PERIOD_CLOSED','ACCOUNTING_PERIOD',req.params.id,check.rows[0]); await c.query('COMMIT'); res.json({status:'success',message:'Periode ditutup',totals:check.rows[0]});
 }catch(e){await c.query('ROLLBACK');if(e.http)return res.status(e.http).json({error:e.message});throw e;}finally{c.release();}
}));

// Integration secrets are write-only: list endpoints return only presence/status metadata.
router.get('/admin/integrations', ...admin('admin.integrations.manage'), asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT integration_code,display_name,config,is_enabled,(secret_ciphertext IS NOT NULL) has_secret,last_test_at,last_test_status,last_test_message,updated_at FROM tbl_admin_integrations ORDER BY display_name`); res.json({status:'success',data:r.rows});
}));
router.put('/admin/integrations/:code', ...admin('admin.integrations.manage'), asyncRoute(async(req,res)=>{
 const code=String(req.params.code||'').toUpperCase(); if(!allowedIntegrations.has(code)) return res.status(400).json({error:'Jenis integrasi tidak didukung'});
 const display=String(req.body?.display_name||code).slice(0,120); const enabled=Boolean(req.body?.is_enabled); const config=req.body?.config||{}; if(typeof config!=='object'||Array.isArray(config)) return res.status(400).json({error:'config harus berupa objek'});
 const hasSecretField=(obj)=>Object.entries(obj).some(([k,v])=>/(secret|token|api.?key|password|credential|authorization)/i.test(k)||(v&&typeof v==='object'&&hasSecretField(v)));
 if(hasSecretField(config)) return res.status(400).json({error:'Jangan letakkan credential di config JSON. Gunakan field Secret agar terenkripsi.'});
 let secret=null; if(typeof req.body?.secret==='string'&&req.body.secret.trim()) { try{secret=Vault.encrypt(req.body.secret.trim());}catch(e){return res.status(503).json({error:e.message});} }
 const r=await pool.query(`INSERT INTO tbl_admin_integrations(integration_code,display_name,secret_ciphertext,secret_iv,secret_auth_tag,config,is_enabled,updated_by) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8) ON CONFLICT(integration_code) DO UPDATE SET display_name=EXCLUDED.display_name,secret_ciphertext=COALESCE(EXCLUDED.secret_ciphertext,tbl_admin_integrations.secret_ciphertext),secret_iv=COALESCE(EXCLUDED.secret_iv,tbl_admin_integrations.secret_iv),secret_auth_tag=COALESCE(EXCLUDED.secret_auth_tag,tbl_admin_integrations.secret_auth_tag),config=EXCLUDED.config,is_enabled=EXCLUDED.is_enabled,updated_by=EXCLUDED.updated_by,updated_at=CURRENT_TIMESTAMP RETURNING integration_code,display_name,config,is_enabled,(secret_ciphertext IS NOT NULL) has_secret,updated_at`,[code,display,secret?.ciphertext||null,secret?.iv||null,secret?.authTag||null,JSON.stringify(config),enabled,req.user.id]);
 await audit(pool,req,'INTEGRATION_UPDATED','INTEGRATION',code,{is_enabled:enabled,secret_updated:Boolean(secret)}); res.json({status:'success',data:r.rows[0]});
}));

// IT operations: safe operational telemetry; never expose environment variables or secrets.
router.get('/admin/system/health', ...admin('admin.security.read'), asyncRoute(async(req,res)=>{
 const started=Date.now(); await pool.query('SELECT 1'); const dbLatencyMs=Date.now()-started;
 const mem=process.memoryUsage(); const workers=await pool.query(`SELECT worker_name,status,last_started_at,last_completed_at,last_duration_ms,last_candidates,last_processed,last_sent,last_failed,last_skipped,last_error,updated_at FROM tbl_worker_heartbeats ORDER BY worker_name`);
 res.json({status:'success',server:{uptime_seconds:Math.floor(process.uptime()),node_version:process.version,platform:process.platform,load_average:os.loadavg(),memory:{rss_bytes:mem.rss,heap_used_bytes:mem.heapUsed,heap_total_bytes:mem.heapTotal,system_total_bytes:os.totalmem(),system_free_bytes:os.freemem()}},database:{status:'ok',latency_ms:dbLatencyMs},workers:workers.rows});
}));
router.get('/admin/audit', ...admin('admin.security.read'), asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT id,actor_id,action,resource_type,resource_id,ip_address,metadata,created_at FROM tbl_admin_audit_events ORDER BY created_at DESC LIMIT 200`); res.json({status:'success',data:r.rows});
}));

// Super Admin can grant/revoke explicit staff permissions. No implicit Finance/IT access.
router.post('/admin/access/staff-role', verifyToken, requireRole(4), asyncRoute(async(req,res)=>{
 const {user_id,role_name}=req.body||{}; const allowedRoles=new Set(['FINANCE','IT_ADMIN','OPERATIONS_ADMIN']);
 if(!user_id||!allowedRoles.has(role_name)) return res.status(400).json({error:'user_id atau role_name tidak valid'});
 const role=await pool.query(`SELECT id FROM tbl_roles WHERE role_name=$1`,[role_name]); if(!role.rowCount) return res.status(404).json({error:'Role staf belum tersedia; jalankan migrasi V3'});
 const updated=await pool.query(`UPDATE tbl_users SET role_id=$1,updated_at=CURRENT_TIMESTAMP WHERE id=$2 RETURNING id,username,role_id`,[role.rows[0].id,user_id]);
 if(!updated.rowCount) return res.status(404).json({error:'Pengguna tidak ditemukan'});
 await pool.query(`DELETE FROM tbl_admin_user_permissions WHERE user_id=$1`,[user_id]);
 await audit(pool,req,'STAFF_ROLE_ASSIGNED','USER',user_id,{role_name});
 res.json({status:'success',data:updated.rows[0],message:'Pengguna harus login ulang agar token memuat role baru'});
}));
router.get('/admin/access/permissions', ...admin('admin.access.manage'), asyncRoute(async(req,res)=>{
 const r=await pool.query(`SELECT p.user_id,u.username,p.permission_code,p.created_at FROM tbl_admin_user_permissions p JOIN tbl_users u ON u.id=p.user_id ORDER BY u.username,p.permission_code`); res.json({status:'success',data:r.rows});
}));
router.put('/admin/access/permissions', ...admin('admin.access.manage'), asyncRoute(async(req,res)=>{
 const {user_id,permission_code,granted}=req.body||{}; const allowed=new Set(['admin.vouchers.manage','admin.finance.read','admin.finance.post','admin.integrations.manage','admin.access.manage','admin.operations.manage','admin.security.read']); if(!user_id||!allowed.has(permission_code)||typeof granted!=='boolean') return res.status(400).json({error:'user_id, permission_code, granted tidak valid'});
 const target=await pool.query(`SELECT role.role_name FROM tbl_users u JOIN tbl_roles role ON role.id=u.role_id WHERE u.id=$1`,[user_id]);
 if(!target.rowCount) return res.status(404).json({error:'Pengguna tidak ditemukan'});
 if(!['FINANCE','IT_ADMIN','OPERATIONS_ADMIN'].includes(target.rows[0].role_name)) return res.status(400).json({error:'Hak akses admin hanya dapat diberikan kepada staf Finance, IT, atau Operasional'});
 if(granted) await pool.query(`INSERT INTO tbl_admin_user_permissions(user_id,permission_code,granted_by) VALUES($1,$2,$3) ON CONFLICT DO NOTHING`,[user_id,permission_code,req.user.id]); else await pool.query(`DELETE FROM tbl_admin_user_permissions WHERE user_id=$1 AND permission_code=$2`,[user_id,permission_code]);
 await audit(pool,req,granted?'PERMISSION_GRANTED':'PERMISSION_REVOKED','USER',user_id,{permission_code}); res.json({status:'success'});
}));
module.exports=router;
