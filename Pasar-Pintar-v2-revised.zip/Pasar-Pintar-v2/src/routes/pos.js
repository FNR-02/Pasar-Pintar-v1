'use strict';

/**
 * POS kasir offline-first - terintegrasi dengan satu sumber kebenaran:
 *   - stok     : tbl_inventory (lewat StockService, sama dengan online/WhatsApp)
 *   - harga    : tbl_product_prices (harga RETAIL terbaru)
 *   - katalog  : tbl_products + v_product_availability
 *
 * Perangkat kasir menyimpan penjualan di antrean lokal saat offline, lalu
 * mengirim lewat POST /api/pos/sync. Setiap penjualan membawa client_sale_id
 * (UUID dari perangkat) sehingga pengiriman ulang AMAN (idempoten).
 *
 * Aturan emas: penjualan fisik selalu menang. Jika stok sistem kurang, penjualan
 * tetap dicatat dan selisihnya masuk tbl_stock_discrepancies untuk ditinjau.
 */

const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, requireRole } = require('../middleware/auth');
const StockService = require('../services/inventory/StockService');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const PAYMENT_METHODS = ['CASH', 'QRIS', 'TRANSFER'];
const MAX_SYNC = 200;
const MAX_LINES = 60;

async function resolveMerchant(userId) {
    const r = await pool.query(
        `SELECT id, store_name FROM tbl_merchants
         WHERE user_id = $1 AND status = 'ACTIVE' LIMIT 1`,
        [userId]
    );
    return r.rows[0] || null;
}

async function withMerchant(req, res, next) {
    try {
        const merchant = await resolveMerchant(req.user.id);
        if (!merchant) return res.status(403).json({ error: 'Merchant aktif tidak ditemukan' });
        req.merchant = merchant;
        next();
    } catch (err) {
        console.error('[POS MERCHANT]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
}

const guard = [verifyToken, requireRole(2), withMerchant];

/* ------------------------------------------------------------------ katalog */
router.get('/pos/catalog', ...guard, async (req, res) => {
    try {
        const r = await pool.query(
            `SELECT p.id, p.sku, p.name, p.unit, p.unit_step, p.allow_decimal, p.stock_mode,
                    COALESCE(price.amount, 0) AS price,
                    a.available, a.on_hand
             FROM tbl_products p
             JOIN v_product_availability a ON a.product_id = p.id
             LEFT JOIN LATERAL (
                 SELECT pp.amount FROM tbl_product_prices pp
                 WHERE pp.product_id = p.id AND pp.price_type = 'RETAIL'
                 ORDER BY pp.effective_date DESC LIMIT 1
             ) price ON TRUE
             WHERE p.merchant_id = $1 AND p.status = 'ACTIVE'
             ORDER BY p.name`,
            [req.merchant.id]
        );
        res.json({
            status: 'success',
            server_time: new Date().toISOString(),
            merchant: req.merchant,
            data: r.rows.map((row) => ({
                ...row,
                price: Number(row.price),
                available: Number(row.available),
                on_hand: Number(row.on_hand),
                unit_step: Number(row.unit_step)
            }))
        });
    } catch (err) {
        console.error('[POS CATALOG]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

/* -------------------------------------------------------------------- shift */
router.get('/pos/shifts/current', ...guard, async (req, res) => {
    try {
        const r = await pool.query(
            `SELECT * FROM tbl_pos_shifts WHERE merchant_id = $1 AND status = 'OPEN' LIMIT 1`,
            [req.merchant.id]
        );
        res.json({ status: 'success', data: r.rows[0] || null });
    } catch (err) {
        console.error('[POS SHIFT]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

router.post('/pos/shifts/open', ...guard, async (req, res) => {
    const opening = Number(req.body?.opening_cash || 0);
    if (!Number.isFinite(opening) || opening < 0) {
        return res.status(400).json({ error: 'opening_cash tidak valid' });
    }
    try {
        const r = await pool.query(
            `INSERT INTO tbl_pos_shifts (merchant_id, opened_by, opening_cash)
             VALUES ($1, $2, $3)
             ON CONFLICT DO NOTHING
             RETURNING *`,
            [req.merchant.id, req.user.id, opening]
        );
        if (!r.rowCount) {
            return res.status(409).json({ error: 'Masih ada shift yang terbuka' });
        }
        res.status(201).json({ status: 'success', data: r.rows[0] });
    } catch (err) {
        console.error('[POS SHIFT OPEN]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

router.post('/pos/shifts/close', ...guard, async (req, res) => {
    const closing = Number(req.body?.closing_cash);
    if (!Number.isFinite(closing) || closing < 0) {
        return res.status(400).json({ error: 'closing_cash tidak valid' });
    }
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const shift = await client.query(
            `SELECT * FROM tbl_pos_shifts
             WHERE merchant_id = $1 AND status = 'OPEN' FOR UPDATE`,
            [req.merchant.id]
        );
        if (!shift.rowCount) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Tidak ada shift yang terbuka' });
        }
        const s = shift.rows[0];
        const cash = await client.query(
            `SELECT COALESCE(SUM(total_amount), 0) AS cash_total
             FROM tbl_pos_sales
             WHERE shift_id = $1 AND payment_method = 'CASH' AND voided_at IS NULL`,
            [s.id]
        );
        const expected = Number(s.opening_cash) + Number(cash.rows[0].cash_total);
        const closed = await client.query(
            `UPDATE tbl_pos_shifts
             SET status = 'CLOSED', closed_at = CURRENT_TIMESTAMP,
                 closing_cash = $2, expected_cash = $3
             WHERE id = $1 RETURNING *`,
            [s.id, closing, expected]
        );
        await client.query('COMMIT');
        res.json({
            status: 'success',
            data: closed.rows[0],
            cash_difference: closing - expected,
            note:
                'Penjualan offline yang belum tersinkron akan tetap masuk ke shift ini ' +
                'berdasarkan waktu transaksinya; selisih bisa berubah setelah sinkronisasi.'
        });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[POS SHIFT CLOSE]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    } finally {
        client.release();
    }
});

/* ------------------------------------------------------------------ penjualan */
function parseSoldAt(value) {
    const t = value ? new Date(value) : null;
    const now = Date.now();
    if (!t || Number.isNaN(t.getTime())) return { date: new Date(now), valid: false };
    // jam perangkat tidak boleh melompat ke masa depan lebih dari 5 menit
    if (t.getTime() > now + 5 * 60 * 1000) return { date: new Date(now), valid: false };
    return { date: t, valid: true };
}

async function processSale(merchant, userId, sale) {
    const clientSaleId = String(sale?.client_sale_id || '');
    if (!UUID_RE.test(clientSaleId)) {
        return { client_sale_id: clientSaleId, status: 'rejected', error: 'client_sale_id harus UUID' };
    }
    const method = String(sale.payment_method || '').toUpperCase();
    if (!PAYMENT_METHODS.includes(method)) {
        return { client_sale_id: clientSaleId, status: 'rejected', error: 'payment_method tidak valid' };
    }
    if (!Array.isArray(sale.items) || sale.items.length === 0 || sale.items.length > MAX_LINES) {
        return { client_sale_id: clientSaleId, status: 'rejected', error: 'Daftar item tidak valid' };
    }

    const client = await pool.connect();
    try {
        await client.query('BEGIN');

        // Idempotensi cepat
        const existing = await client.query(
            `SELECT id, total_amount FROM tbl_pos_sales WHERE client_sale_id = $1`,
            [clientSaleId]
        );
        if (existing.rowCount) {
            await client.query('ROLLBACK');
            return {
                client_sale_id: clientSaleId,
                status: 'duplicate',
                sale_id: existing.rows[0].id,
                total_amount: Number(existing.rows[0].total_amount)
            };
        }

        const ids = [...new Set(sale.items.map((i) => String(i.product_id || '')))];
        if (ids.some((id) => !UUID_RE.test(id))) {
            await client.query('ROLLBACK');
            return { client_sale_id: clientSaleId, status: 'rejected', error: 'product_id tidak valid' };
        }
        const prods = await client.query(
            `SELECT p.id, p.name, p.unit, p.unit_step, p.allow_decimal, p.stock_mode,
                    price.amount AS server_price
             FROM tbl_products p
             LEFT JOIN LATERAL (
                 SELECT pp.amount FROM tbl_product_prices pp
                 WHERE pp.product_id = p.id AND pp.price_type = 'RETAIL'
                 ORDER BY pp.effective_date DESC LIMIT 1
             ) price ON TRUE
             WHERE p.id = ANY($1::uuid[]) AND p.merchant_id = $2 AND p.status = 'ACTIVE'`,
            [ids, merchant.id]
        );
        const byId = new Map(prods.rows.map((p) => [p.id, p]));

        const lines = [];
        let total = 0;
        let priceMismatch = false;
        for (const item of sale.items) {
            const product = byId.get(String(item.product_id));
            if (!product) {
                await client.query('ROLLBACK');
                return {
                    client_sale_id: clientSaleId,
                    status: 'rejected',
                    error: 'Produk bukan milik lapak ini atau tidak aktif',
                    product_id: item.product_id
                };
            }
            let qty;
            try {
                qty = StockService.validateQuantity(product, item.quantity);
            } catch (e) {
                await client.query('ROLLBACK');
                return { client_sale_id: clientSaleId, status: 'rejected', error: e.message };
            }
            const serverPrice = Number(product.server_price || 0);
            // Penjualan offline memakai harga yang tampil di layar kasir saat itu.
            const price = Number(item.unit_price ?? serverPrice);
            if (!Number.isFinite(price) || price <= 0) {
                await client.query('ROLLBACK');
                return {
                    client_sale_id: clientSaleId,
                    status: 'rejected',
                    error: `Harga ${product.name} tidak valid`
                };
            }
            if (serverPrice > 0 && Math.round(price) !== Math.round(serverPrice)) priceMismatch = true;
            const lineTotal = Math.round(price * qty);
            total += lineTotal;
            lines.push({
                product_id: product.id,
                name: product.name,
                unit: product.unit,
                quantity: qty,
                unit_price: price,
                line_total: lineTotal,
                stock_mode: product.stock_mode
            });
        }

        const soldAt = parseSoldAt(sale.sold_at);
        const offline = Boolean(sale.offline) || Date.now() - soldAt.date.getTime() > 60 * 1000;

        let cashReceived = null;
        let change = null;
        if (method === 'CASH') {
            cashReceived = Number(sale.cash_received ?? total);
            if (!Number.isFinite(cashReceived) || cashReceived < total) {
                await client.query('ROLLBACK');
                return {
                    client_sale_id: clientSaleId,
                    status: 'rejected',
                    error: 'Uang diterima kurang dari total'
                };
            }
            change = cashReceived - total;
        }

        const shift = await client.query(
            `SELECT id FROM tbl_pos_shifts
             WHERE merchant_id = $1 AND opened_at <= $2
               AND (closed_at IS NULL OR closed_at >= $2)
             ORDER BY opened_at DESC LIMIT 1`,
            [merchant.id, soldAt.date.toISOString()]
        );

        const inserted = await client.query(
            `INSERT INTO tbl_pos_sales
               (client_sale_id, merchant_id, shift_id, payment_method, total_amount,
                cash_received, change_given, items, offline, sold_at, price_mismatch)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
             ON CONFLICT (client_sale_id) DO NOTHING
             RETURNING id`,
            [
                clientSaleId,
                merchant.id,
                shift.rows[0]?.id || null,
                method,
                total,
                cashReceived,
                change,
                JSON.stringify(lines),
                offline,
                soldAt.date.toISOString(),
                priceMismatch
            ]
        );
        if (!inserted.rowCount) {
            await client.query('ROLLBACK');
            return { client_sale_id: clientSaleId, status: 'duplicate' };
        }
        const saleId = inserted.rows[0].id;

        // Kurangi stok pada sumber kebenaran yang sama dengan penjualan online.
        const discrepancies = [];
        for (const line of [...lines].sort((a, b) => a.product_id.localeCompare(b.product_id))) {
            if (line.stock_mode === 'TOGGLE') continue;
            const result = await StockService.decrementForSale(client, {
                productId: line.product_id,
                quantity: line.quantity,
                refDoc: `POS-${saleId}`,
                merchantId: merchant.id,
                source: 'POS_SALE',
                refId: saleId,
                createdBy: userId
            });
            if (result.shortfall > 0) {
                discrepancies.push({
                    product_id: line.product_id,
                    name: line.name,
                    shortfall: result.shortfall
                });
            }
        }

        await client.query('COMMIT');
        return {
            client_sale_id: clientSaleId,
            status: 'created',
            sale_id: saleId,
            total_amount: total,
            change_given: change,
            price_mismatch: priceMismatch,
            stock_discrepancies: discrepancies
        };
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[POS SALE]', err.message);
        return { client_sale_id: clientSaleId, status: 'error', error: 'Gagal menyimpan, coba kirim ulang' };
    } finally {
        client.release();
    }
}

router.post('/pos/sync', ...guard, async (req, res) => {
    const sales = req.body?.sales;
    if (!Array.isArray(sales) || sales.length === 0) {
        return res.status(400).json({ error: 'sales wajib berupa array' });
    }
    if (sales.length > MAX_SYNC) {
        return res.status(413).json({ error: `Maksimal ${MAX_SYNC} penjualan per sinkronisasi` });
    }
    const results = [];
    // Berurutan agar urutan stok & shift konsisten.
    for (const sale of sales) {
        results.push(await processSale(req.merchant, req.user.id, sale));
    }
    res.json({
        status: 'success',
        server_time: new Date().toISOString(),
        accepted: results.filter((r) => r.status === 'created' || r.status === 'duplicate').length,
        results
    });
});

router.post('/pos/sales', ...guard, async (req, res) => {
    const result = await processSale(req.merchant, req.user.id, req.body || {});
    const code = result.status === 'created' ? 201 : result.status === 'duplicate' ? 200 : 400;
    res.status(result.status === 'error' ? 500 : code).json(result);
});

router.post('/pos/sales/:id/void', ...guard, async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const s = await client.query(
            `SELECT * FROM tbl_pos_sales WHERE id = $1 AND merchant_id = $2 FOR UPDATE`,
            [req.params.id, req.merchant.id]
        );
        if (!s.rowCount) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Penjualan tidak ditemukan' });
        }
        const sale = s.rows[0];
        if (sale.voided_at) {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'Penjualan sudah dibatalkan' });
        }
        if (Date.now() - new Date(sale.sold_at).getTime() > 24 * 60 * 60 * 1000) {
            await client.query('ROLLBACK');
            return res.status(409).json({ error: 'Pembatalan hanya bisa dalam 24 jam' });
        }

        // Kembalikan stok sesuai movement SALE yang tercatat untuk penjualan ini.
        const moves = await client.query(
            `SELECT product_id, warehouse_id, quantity
             FROM tbl_inventory_movements
             WHERE movement_type = 'SALE' AND reference_doc = $1`,
            [`POS-${sale.id}`]
        );
        for (const m of moves.rows) {
            await client.query(
                `UPDATE tbl_inventory
                 SET quantity_on_hand = quantity_on_hand + $1, updated_at = CURRENT_TIMESTAMP
                 WHERE product_id = $2 AND warehouse_id = $3`,
                [m.quantity, m.product_id, m.warehouse_id]
            );
            await client.query(
                `INSERT INTO tbl_inventory_movements
                   (product_id, warehouse_id, movement_type, quantity, reference_doc, created_by)
                 VALUES ($1, $2, 'SALE_VOID', $3, $4, $5)`,
                [m.product_id, m.warehouse_id, m.quantity, `POS-VOID-${sale.id}`, req.user.id]
            );
        }
        await client.query(`UPDATE tbl_pos_sales SET voided_at = CURRENT_TIMESTAMP WHERE id = $1`, [sale.id]);
        await client.query('COMMIT');
        res.json({ status: 'success', message: 'Penjualan dibatalkan dan stok dikembalikan' });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[POS VOID]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    } finally {
        client.release();
    }
});

/* ----------------------------------------------------------------- ringkasan */
router.get('/pos/summary', ...guard, async (req, res) => {
    const date = String(req.query.date || '').match(/^\d{4}-\d{2}-\d{2}$/)
        ? req.query.date
        : null;
    try {
        const day = date || (await pool.query(`SELECT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Jakarta')::date AS d`)).rows[0].d;
        const channels = await pool.query(
            `SELECT channel, COUNT(*)::int AS transaksi, COALESCE(SUM(total_amount), 0) AS total
             FROM v_sales_unified
             WHERE merchant_id = $1
               AND (sold_at AT TIME ZONE 'Asia/Jakarta')::date = $2::date
             GROUP BY channel ORDER BY channel`,
            [req.merchant.id, day]
        );
        const pay = await pool.query(
            `SELECT payment_method, COUNT(*)::int AS transaksi, COALESCE(SUM(total_amount), 0) AS total
             FROM tbl_pos_sales
             WHERE merchant_id = $1 AND voided_at IS NULL
               AND (sold_at AT TIME ZONE 'Asia/Jakarta')::date = $2::date
             GROUP BY payment_method`,
            [req.merchant.id, day]
        );
        const disc = await pool.query(
            `SELECT COUNT(*)::int AS open_count
             FROM tbl_stock_discrepancies WHERE merchant_id = $1 AND resolved = FALSE`,
            [req.merchant.id]
        );
        res.json({
            status: 'success',
            date: day,
            by_channel: channels.rows.map((r) => ({ ...r, total: Number(r.total) })),
            pos_by_payment_method: pay.rows.map((r) => ({ ...r, total: Number(r.total) })),
            open_stock_discrepancies: disc.rows[0].open_count
        });
    } catch (err) {
        console.error('[POS SUMMARY]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
});

module.exports = router;
