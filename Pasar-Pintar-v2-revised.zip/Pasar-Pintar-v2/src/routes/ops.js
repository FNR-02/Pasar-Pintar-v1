'use strict';

/**
 * Operasional harian pedagang & admin, semuanya memakai sumber kebenaran yang sama:
 *
 *  Pedagang (role 2)
 *    PATCH /api/merchant/stock/quick            tandai Ada/Habis (semua kanal ikut berubah)
 *    POST  /api/merchant/stock/set              opname: setel stok angka (+ menutup selisih)
 *    POST  /api/merchant/prices/quick           ubah harga banyak barang sekaligus (riwayat tersimpan)
 *    PATCH /api/merchant/products/:id/selling-unit   satuan jual (kg, ikat, ...), desimal, mode stok
 *  Publik
 *    GET   /api/public/price-board              "Harga hari ini" (tanpa login, dibatasi laju)
 *  Admin (role 4)
 *    GET   /api/admin/kpi/weekly                angka mingguan + status anggaran subsidi ongkir
 *    GET   /api/admin/stock-discrepancies       POST .../:id/resolve
 *    GET/POST/PATCH /api/admin/delivery-zones   zona antar, ongkir, minimum belanja
 *    POST  /api/admin/platform-revenue          catat pendapatan B2B/biaya layanan
 */

const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { verifyToken, requireRole } = require('../middleware/auth');
const { createRateLimiter } = require('../middleware/security');
const StockService = require('../services/inventory/StockService');
const ShippingService = require('../services/shipping/ShippingService');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const MAX_BATCH = 100;

async function withMerchant(req, res, next) {
    try {
        const r = await pool.query(
            `SELECT id FROM tbl_merchants WHERE user_id = $1 AND status = 'ACTIVE' LIMIT 1`,
            [req.user.id]
        );
        if (!r.rowCount) return res.status(403).json({ error: 'Merchant aktif tidak ditemukan' });
        req.merchantId = r.rows[0].id;
        next();
    } catch (err) {
        console.error('[OPS MERCHANT]', err.message);
        res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
}
const merchantOnly = [verifyToken, requireRole(2), withMerchant];
const adminOnly = [verifyToken, requireRole(4)];

function fail(res, tag, err) {
    console.error(`[${tag}]`, err.message);
    res.status(500).json({ error: 'Terjadi kesalahan pada server' });
}
function batchOf(body) {
    const items = body?.items;
    if (!Array.isArray(items) || items.length === 0 || items.length > MAX_BATCH) return null;
    return items;
}

/* ------------------------------------------------------------------ pedagang */
router.patch('/merchant/stock/quick', ...merchantOnly, async (req, res) => {
    const items = batchOf(req.body);
    if (!items) return res.status(400).json({ error: `items wajib berisi 1-${MAX_BATCH} barang` });
    if (items.some((i) => !UUID_RE.test(String(i.product_id)) || typeof i.available !== 'boolean')) {
        return res.status(400).json({ error: 'Setiap item butuh product_id (UUID) dan available (true/false)' });
    }
    try {
        let changed = 0;
        for (const i of items) {
            const r = await pool.query(
                `UPDATE tbl_products SET is_available = $1, updated_at = CURRENT_TIMESTAMP
                 WHERE id = $2 AND merchant_id = $3`,
                [i.available, i.product_id, req.merchantId]
            );
            changed += r.rowCount;
        }
        res.json({ status: 'success', changed });
    } catch (err) {
        fail(res, 'QUICK STOCK', err);
    }
});

router.post('/merchant/stock/set', ...merchantOnly, async (req, res) => {
    const items = batchOf(req.body);
    if (!items) return res.status(400).json({ error: `items wajib berisi 1-${MAX_BATCH} barang` });
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const results = [];
        for (const i of items) {
            if (!UUID_RE.test(String(i.product_id))) throw Object.assign(new Error('product_id tidak valid'), { biz: true });
            const own = await client.query(
                `SELECT id FROM tbl_products WHERE id = $1 AND merchant_id = $2 FOR UPDATE`,
                [i.product_id, req.merchantId]
            );
            if (!own.rowCount) throw Object.assign(new Error('Produk bukan milik lapak ini'), { biz: true });
            const r = await StockService.setOnHand(client, {
                productId: i.product_id,
                quantity: Number(i.quantity),
                userId: req.user.id,
                reason: 'OPNAME'
            });
            await client.query(
                `UPDATE tbl_stock_discrepancies SET resolved = TRUE
                 WHERE product_id = $1 AND merchant_id = $2 AND resolved = FALSE`,
                [i.product_id, req.merchantId]
            );
            results.push({ product_id: i.product_id, ...r });
        }
        await client.query('COMMIT');
        res.json({ status: 'success', data: results });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        if (err.biz || err instanceof StockService.StockError) {
            return res.status(400).json({ error: err.message });
        }
        fail(res, 'SET STOCK', err);
    } finally {
        client.release();
    }
});

router.post('/merchant/prices/quick', ...merchantOnly, async (req, res) => {
    const items = batchOf(req.body);
    if (!items) return res.status(400).json({ error: `items wajib berisi 1-${MAX_BATCH} barang` });
    for (const i of items) {
        const price = Number(i.price);
        if (!UUID_RE.test(String(i.product_id)) || !Number.isFinite(price) || price <= 0 || price > 100000000) {
            return res.status(400).json({ error: 'Setiap item butuh product_id (UUID) dan price > 0' });
        }
    }
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        let changed = 0;
        for (const i of items) {
            const own = await client.query(
                `SELECT id FROM tbl_products WHERE id = $1 AND merchant_id = $2`,
                [i.product_id, req.merchantId]
            );
            if (!own.rowCount) throw Object.assign(new Error('Produk bukan milik lapak ini'), { biz: true });
            const cur = await client.query(
                `SELECT amount FROM tbl_product_prices
                 WHERE product_id = $1 AND price_type = 'RETAIL'
                 ORDER BY effective_date DESC LIMIT 1`,
                [i.product_id]
            );
            if (cur.rowCount && Number(cur.rows[0].amount) === Number(i.price)) continue;
            await client.query(
                `INSERT INTO tbl_product_prices (product_id, price_type, amount)
                 VALUES ($1, 'RETAIL', $2)`,
                [i.product_id, Number(i.price)]
            );
            changed += 1;
        }
        await client.query('COMMIT');
        res.json({ status: 'success', changed });
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        if (err.biz) return res.status(400).json({ error: err.message });
        fail(res, 'QUICK PRICE', err);
    } finally {
        client.release();
    }
});

router.patch('/merchant/products/:id/selling-unit', ...merchantOnly, async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    const unit = String(req.body?.unit || '').trim().toLowerCase();
    const allowDecimal = Boolean(req.body?.allow_decimal);
    const step = Number(req.body?.unit_step ?? (allowDecimal ? 0.25 : 1));
    const mode = String(req.body?.stock_mode || 'COUNTED').toUpperCase();
    if (!/^[a-z0-9 ]{1,20}$/.test(unit)) return res.status(400).json({ error: 'Satuan tidak valid (mis. kg, ikat, pcs)' });
    if (!(step > 0) || step > 1000) return res.status(400).json({ error: 'unit_step tidak valid' });
    if (!['COUNTED', 'TOGGLE'].includes(mode)) return res.status(400).json({ error: 'stock_mode harus COUNTED atau TOGGLE' });
    try {
        const r = await pool.query(
            `UPDATE tbl_products
             SET unit = $1, unit_step = $2, allow_decimal = $3, stock_mode = $4,
                 updated_at = CURRENT_TIMESTAMP
             WHERE id = $5 AND merchant_id = $6
             RETURNING id, unit, unit_step, allow_decimal, stock_mode`,
            [unit, step, allowDecimal, mode, req.params.id, req.merchantId]
        );
        if (!r.rowCount) return res.status(404).json({ error: 'Produk tidak ditemukan' });
        res.json({ status: 'success', data: r.rows[0] });
    } catch (err) {
        fail(res, 'SELLING UNIT', err);
    }
});

/* -------------------------------------------------------------------- publik */
const boardLimiter = createRateLimiter({ windowMs: 60 * 1000, max: 60 });

router.get('/public/price-board', boardLimiter, async (req, res) => {
    const q = String(req.query.q || '').trim().slice(0, 60);
    try {
        const r = await pool.query(
            `SELECT p.id, p.name, p.unit, m.store_name,
                    price.amount AS price, price.effective_date AS price_updated_at,
                    a.available, a.stock_mode
             FROM tbl_products p
             JOIN tbl_merchants m ON m.id = p.merchant_id AND m.status = 'ACTIVE'
             JOIN v_product_availability a ON a.product_id = p.id
             JOIN LATERAL (
                 SELECT pp.amount, pp.effective_date FROM tbl_product_prices pp
                 WHERE pp.product_id = p.id AND pp.price_type = 'RETAIL'
                 ORDER BY pp.effective_date DESC LIMIT 1
             ) price ON TRUE
             WHERE p.status = 'ACTIVE' AND ($1 = '' OR p.name ILIKE '%' || $1 || '%')
             ORDER BY p.name, price.amount
             LIMIT 200`,
            [q]
        );
        res.setHeader('Cache-Control', 'public, max-age=30');
        res.json({
            status: 'success',
            generated_at: new Date().toISOString(),
            data: r.rows.map((x) => ({
                id: x.id,
                name: x.name,
                unit: x.unit,
                store_name: x.store_name,
                price: Number(x.price),
                price_updated_at: x.price_updated_at,
                availability:
                    Number(x.available) <= 0 ? 'HABIS'
                    : x.stock_mode === 'COUNTED' && Number(x.available) < 5 ? 'TERBATAS'
                    : 'ADA'
            }))
        });
    } catch (err) {
        fail(res, 'PRICE BOARD', err);
    }
});

/* --------------------------------------------------------------------- admin */
router.get('/admin/kpi/weekly', ...adminOnly, async (req, res) => {
    try {
        const orders = await pool.query(
            `SELECT (g.created_at AT TIME ZONE 'Asia/Jakarta')::date AS hari,
                    COUNT(*)::int AS pesanan,
                    COALESCE(AVG(g.shipping_fee), 0) AS rata_ongkir_pembeli,
                    COALESCE(AVG(g.shipping_subsidy), 0) AS rata_subsidi
             FROM tbl_checkout_groups g
             WHERE g.status = 'PAID' AND g.created_at >= CURRENT_TIMESTAMP - INTERVAL '7 days'
             GROUP BY 1 ORDER BY 1`
        );
        const byZone = await pool.query(
            `SELECT COALESCE(z.name, 'Ambil di pasar') AS zona, COUNT(*)::int AS pesanan
             FROM tbl_checkout_groups g
             LEFT JOIN tbl_delivery_zones z ON z.id = g.zone_id
             WHERE g.status = 'PAID' AND g.created_at >= CURRENT_TIMESTAMP - INTERVAL '7 days'
             GROUP BY 1 ORDER BY 2 DESC`
        );
        const merchants = await pool.query(
            `SELECT COUNT(DISTINCT merchant_id)::int AS lapak_aktif
             FROM v_sales_unified WHERE sold_at >= CURRENT_TIMESTAMP - INTERVAL '7 days'`
        );
        const channels = await pool.query(
            `SELECT channel, COUNT(*)::int AS transaksi, COALESCE(SUM(total_amount), 0) AS total
             FROM v_sales_unified WHERE sold_at >= CURRENT_TIMESTAMP - INTERVAL '7 days'
             GROUP BY channel ORDER BY channel`
        );
        const b2b = await pool.query(
            `SELECT source, COALESCE(SUM(amount), 0) AS total
             FROM tbl_platform_revenue WHERE created_at >= CURRENT_TIMESTAMP - INTERVAL '7 days'
             GROUP BY source`
        );
        const repeat = await pool.query(
            `WITH c AS (
                SELECT customer_id, COUNT(*) AS n FROM tbl_checkout_groups
                WHERE status = 'PAID' AND created_at >= CURRENT_TIMESTAMP - INTERVAL '30 days'
                GROUP BY customer_id)
             SELECT COUNT(*)::int AS pembeli, COUNT(*) FILTER (WHERE n >= 2)::int AS pesan_ulang FROM c`
        );
        const disc = await pool.query(
            `SELECT COUNT(*)::int AS terbuka FROM tbl_stock_discrepancies WHERE resolved = FALSE`
        );
        const subsidy = await ShippingService.subsidyStatus(pool);

        const totalOrders = orders.rows.reduce((s, r) => s + r.pesanan, 0);
        const rp = repeat.rows[0];
        res.json({
            status: 'success',
            period: '7 hari terakhir',
            lima_angka: {
                lapak_aktif: merchants.rows[0].lapak_aktif,
                pesanan_per_hari_rata2: Math.round((totalOrders / 7) * 10) / 10,
                ongkir_ditanggung_per_pesanan:
                    totalOrders
                        ? Math.round(orders.rows.reduce((s, r) => s + Number(r.rata_subsidi) * r.pesanan, 0) / totalOrders)
                        : 0,
                hasil_b2b_minggu_ini: b2b.rows.reduce((s, r) => s + Number(r.total), 0),
                pelanggan_pesan_ulang_30h_persen: rp.pembeli ? Math.round((rp.pesan_ulang / rp.pembeli) * 100) : 0
            },
            pesanan_per_hari: orders.rows,
            pesanan_per_zona: byZone.rows,
            penjualan_per_kanal: channels.rows.map((r) => ({ ...r, total: Number(r.total) })),
            pendapatan_platform: b2b.rows.map((r) => ({ ...r, total: Number(r.total) })),
            subsidi_ongkir: subsidy,
            selisih_stok_terbuka: disc.rows[0].terbuka
        });
    } catch (err) {
        fail(res, 'KPI', err);
    }
});

router.get('/admin/stock-discrepancies', ...adminOnly, async (req, res) => {
    try {
        const r = await pool.query(
            `SELECT d.*, p.name AS product_name, m.store_name
             FROM tbl_stock_discrepancies d
             JOIN tbl_products p ON p.id = d.product_id
             LEFT JOIN tbl_merchants m ON m.id = d.merchant_id
             WHERE d.resolved = FALSE
             ORDER BY d.created_at DESC LIMIT 200`
        );
        res.json({ status: 'success', count: r.rowCount, data: r.rows });
    } catch (err) {
        fail(res, 'DISCREPANCIES', err);
    }
});
router.post('/admin/stock-discrepancies/:id/resolve', ...adminOnly, async (req, res) => {
    if (!UUID_RE.test(req.params.id)) return res.status(400).json({ error: 'ID tidak valid' });
    try {
        const r = await pool.query(
            `UPDATE tbl_stock_discrepancies SET resolved = TRUE WHERE id = $1 RETURNING id`,
            [req.params.id]
        );
        if (!r.rowCount) return res.status(404).json({ error: 'Tidak ditemukan' });
        res.json({ status: 'success' });
    } catch (err) {
        fail(res, 'DISCREPANCY RESOLVE', err);
    }
});

router.get('/admin/delivery-zones', ...adminOnly, async (req, res) => {
    try {
        const r = await pool.query(`SELECT * FROM tbl_delivery_zones ORDER BY id`);
        res.json({ status: 'success', data: r.rows });
    } catch (err) {
        fail(res, 'ZONES', err);
    }
});
router.post('/admin/delivery-zones', ...adminOnly, async (req, res) => {
    const { name, base_fee, free_above = null, min_order = 0, eta_minutes = 60 } = req.body || {};
    if (!name || !(Number(base_fee) >= 0) || !(Number(min_order) >= 0) || !(Number(eta_minutes) > 0)) {
        return res.status(400).json({ error: 'name, base_fee, min_order, eta_minutes wajib valid' });
    }
    try {
        const r = await pool.query(
            `INSERT INTO tbl_delivery_zones (name, base_fee, free_above, min_order, eta_minutes)
             VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [String(name).slice(0, 120), Number(base_fee), free_above === null ? null : Number(free_above), Number(min_order), Number(eta_minutes)]
        );
        res.status(201).json({ status: 'success', data: r.rows[0] });
    } catch (err) {
        if (err.code === '23505') return res.status(409).json({ error: 'Nama zona sudah dipakai' });
        fail(res, 'ZONE CREATE', err);
    }
});
router.patch('/admin/delivery-zones/:id', ...adminOnly, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) return res.status(400).json({ error: 'ID tidak valid' });
    const allowed = ['name', 'base_fee', 'free_above', 'min_order', 'eta_minutes', 'active'];
    const sets = [];
    const vals = [];
    for (const key of allowed) {
        if (key in (req.body || {})) {
            vals.push(req.body[key]);
            sets.push(`${key} = $${vals.length}`);
        }
    }
    if (!sets.length) return res.status(400).json({ error: 'Tidak ada perubahan' });
    vals.push(id);
    try {
        const r = await pool.query(
            `UPDATE tbl_delivery_zones SET ${sets.join(', ')} WHERE id = $${vals.length} RETURNING *`,
            vals
        );
        if (!r.rowCount) return res.status(404).json({ error: 'Zona tidak ditemukan' });
        res.json({ status: 'success', data: r.rows[0] });
    } catch (err) {
        fail(res, 'ZONE UPDATE', err);
    }
});

router.post('/admin/platform-revenue', ...adminOnly, async (req, res) => {
    const { source, amount, note = null, ref_id = null } = req.body || {};
    const allowed = ['B2B_REBATE', 'B2B_SPREAD', 'SERVICE_FEE', 'PROMO', 'OTHER'];
    if (!allowed.includes(source) || !(Number(amount) > 0)) {
        return res.status(400).json({ error: `source harus salah satu dari ${allowed.join(', ')} dan amount > 0` });
    }
    if (ref_id !== null && !UUID_RE.test(String(ref_id))) return res.status(400).json({ error: 'ref_id tidak valid' });
    try {
        const r = await pool.query(
            `INSERT INTO tbl_platform_revenue (source, ref_id, amount, note)
             VALUES ($1, $2, $3, $4) RETURNING *`,
            [source, ref_id, Number(amount), note ? String(note).slice(0, 300) : null]
        );
        res.status(201).json({ status: 'success', data: r.rows[0] });
    } catch (err) {
        fail(res, 'PLATFORM REVENUE', err);
    }
});

module.exports = router;
