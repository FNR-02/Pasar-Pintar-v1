const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const CommerceKernel = require('../kernel/EventKernel');
const { verifyToken, requireRole } = require('../middleware/auth');
const CreditObligationService =
    require('../services/credit/CreditObligationService');
const SupplierPayableService =
    require('../services/credit/SupplierPayableService');

router.post('/purchase-orders/:id/receive', verifyToken, requireRole(4), async (req, res) => {
    const client = await pool.connect();

    try {
        const { id } = req.params;

        await client.query('BEGIN');

        const poRes = await client.query(
            `SELECT
                id,
                status,
                merchant_id,
                supplier_id,
                warehouse_id,
                total_amount,
                payment_mode,
                credit_account_id,
                tempo_due_at
             FROM tbl_purchase_orders
             WHERE id = $1
             FOR UPDATE`,
            [id]
        );

        if (!poRes.rowCount) {
            await client.query('ROLLBACK');
            return res.status(404).json({
                status: 'error',
                error: 'Purchase Order tidak ditemukan'
            });
        }

        const po = poRes.rows[0];

        if (po.status === 'RECEIVED') {
            await client.query('ROLLBACK');
            return res.status(409).json({
                status: 'error',
                error: 'Purchase Order sudah berstatus RECEIVED. Receiving tidak boleh diproses ulang.'
            });
        }

        if (po.status !== 'APPROVED') {
            await client.query('ROLLBACK');
            return res.status(400).json({
                status: 'error',
                error: `PO harus berstatus APPROVED. Status saat ini: ${po.status}`
            });
        }

        const itemsRes = await client.query(
              `SELECT product_id, SUM(quantity) AS quantity FROM tbl_purchase_order_items WHERE purchase_order_id = $1 GROUP BY product_id`,
            [id]
        );

        if (!itemsRes.rowCount) {
            await client.query('ROLLBACK');
            return res.status(400).json({
                status: 'error',
                error: 'PO tidak memiliki item'
            });
        }

        for (const item of itemsRes.rows) {
            const invRes = await client.query(
                `UPDATE tbl_inventory
                 SET quantity_on_hand = COALESCE(quantity_on_hand, 0) + $1,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE warehouse_id = $2
                   AND product_id = $3
                 RETURNING id, quantity_on_hand`,
                [item.quantity, po.warehouse_id, item.product_id]
            );
            if (!invRes.rowCount) {
                await client.query(
                    `INSERT INTO tbl_inventory
                     (warehouse_id, product_id, quantity_on_hand)
                     VALUES ($1, $2, $3)`,
                    [po.warehouse_id, item.product_id, item.quantity]
                );
            }
        }


          for (const item of itemsRes.rows) {
              await client.query(
                  `INSERT INTO tbl_inventory_movements
                   (product_id, warehouse_id, movement_type,
                    quantity, reference_doc)
                   VALUES ($1, $2, 'PURCHASE_RECEIPT', $3, $4)`,
                  [
                      item.product_id,
                      po.warehouse_id,
                      item.quantity,
                      `PO-${id}`
                  ]
              );
          }

        /*
         * ====================================================
         * TEMPO ATOMIC BOUNDARY
         *
         * Jika PO menggunakan TEMPO, kewajiban Supplier
         * harus berhasil dibuka dalam transaksi PostgreSQL
         * yang SAMA dengan receiving inventory.
         *
         * Jika validasi limit / account / obligation gagal,
         * transaction akan ROLLBACK termasuk perubahan stok.
         * ====================================================
         */

        let creditObligation = null;

        if (
            String(
                po.payment_mode || 'CASH'
            ).toUpperCase() === 'TEMPO'
        ) {
            const creditService =
                new CreditObligationService(
                    client
                );

            const obligationResult =
                await creditService
                    .openPurchaseOrderObligation({
                        purchaseOrderId:
                            po.id
                    });

            if (
                !obligationResult ||
                !obligationResult.obligation
            ) {
                throw new Error(
                    'PO TEMPO gagal membentuk kewajiban Supplier'
                );
            }

            creditObligation =
                obligationResult.obligation;

            /*
             * Finance untuk PO TEMPO berada di transaction
             * PostgreSQL yang sama dengan inventory +
             * obligation.
             */
            const payableService =
                new SupplierPayableService(
                    client
                );

            await payableService
                .recordTempoPurchaseReceipt({
                    purchaseOrderId:
                        po.id
                });
        }

        const updatePo = await client.query(
            `UPDATE tbl_purchase_orders
             SET status = 'RECEIVED'
             WHERE id = $1
             RETURNING
                id,
                status,
                merchant_id,
                supplier_id,
                warehouse_id,
                total_amount,
                payment_mode,
                credit_account_id,
                tempo_due_at`,
            [id]
        );

        await client.query('COMMIT');

        const receivedPo = updatePo.rows[0];

        CommerceKernel.emitEvent(
            'PURCHASE_ORDER_RECEIVED',
            'PURCHASE_ORDER',
            receivedPo.id,
            receivedPo
        );
        return res.json({
            status: 'success',
            message: 'Purchase Order berhasil diterima dan stok diperbarui',
            purchase_order: receivedPo,
            credit_obligation:
                creditObligation
        });

    } catch (err) {
        await client.query('ROLLBACK');

        console.error('[PO RECEIVING ERROR]', err.message);

        return res.status(500).json({
            status: 'error',
            error: 'Terjadi kesalahan pada server'
        });

    } finally {
        client.release();
    }
});

module.exports = router;
