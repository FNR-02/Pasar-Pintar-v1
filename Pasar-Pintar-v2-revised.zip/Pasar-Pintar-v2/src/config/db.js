require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: Number(process.env.DB_PORT || 5432),
});

pool.on('error', (err) => {
    console.error(
        '[DATABASE] Unexpected PostgreSQL pool error:',
        err.message
    );
});

module.exports = pool;
