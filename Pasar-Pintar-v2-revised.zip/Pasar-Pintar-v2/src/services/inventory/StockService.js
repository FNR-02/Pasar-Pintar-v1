'use strict';

/**
 * StockService - SATU-SATUNYA tempat yang boleh mengubah / menahan stok.
 *
 * Alur stok online:
 *   checkout  -> reserve()      (tahan stok, TTL singkat, dalam transaksi yang sama dengan order)
 *   dibayar   -> commitOrder()  (kurangi stok nyata, tulis movement SALE)
 *   batal/exp -> releaseOrder() (lepas tahanan)
 * Alur kasir (POS): decrementForSale() langsung, penjualan fisik selalu menang.
 *
 * Ketersediaan yang dibaca semua kanal = view v_product_availability.
 */

const HOLD_TTL_MINUTES = Number(process.env.STOCK_HOLD_TTL_MINUTES || 30);

class StockError extends Error {
    constructor(code, message, extra = {}) {
        super(message);
        this.name = 'StockError';
        this.code = code;
        Object.assign(this, extra);
    }
}

const round3 = (n) => Math.round(Number(n) * 1000) / 1000;

function validateQuantity(product, quantity) {
    const q = Number(quantity);
    if (!Number.isFinite(q) || q <= 0) {
        throw new StockError('INVALID_QUANTITY', 'Jumlah harus lebih dari 0', {
            product_id: product.id
        });
    }
    if (q > 10000) {
        throw new StockError('INVALID_QUANTITY', 'Jumlah terlalu besar', {
            product_id: product.id
        });
    }
    if (!product.allow_decimal) {
        if (!Number.isInteger(q)) {
            throw new StockError(
                'INVALID_QUANTITY',
                `${product.name} hanya bisa dibeli dalam jumlah bulat`,
                { product_id: product.id }
            );
        }
        return q;
    }
    const step = Number(product.unit_step || 1);
    const ratio = q / step;
    if (Math.abs(ratio - Math.round(ratio)) > 1e-6) {
        throw new StockError(
            'INVALID_QUANTITY',
            `${product.name} dijual per kelipatan ${step} ${product.unit}`,
            { product_id: product.id }
        );
    }
    return round3(q);
}

/** Tahan stok untuk satu order. Harus dipanggil di dalam transaksi (client sudah BEGIN). */
async function reserve(client, orderId, items, ttlMinutes = HOLD_TTL_MINUTES) {
    const sorted = [...items].sort((a, b) =>
        String(a.product_id).localeCompare(String(b.product_id))
    );
    const results = [];

    for (const item of sorted) {
        // Kunci baris produk: reservasi produk yang sama diproses berurutan.
        const productResult = await client.query(
            `SELECT id, name, merchant_id, unit, unit_step, allow_decimal,
                    stock_mode, is_available
             FROM tbl_products
             WHERE id = $1
             FOR UPDATE`,
            [item.product_id]
        );
        if (!productResult.rowCount) {
            throw new StockError('PRODUCT_NOT_FOUND', 'Produk tidak ditemukan', {
                product_id: item.product_id
            });
        }
        const product = productResult.rows[0];
        const qty = validateQuantity(product, item.quantity);

        if (!product.is_available) {
            throw new StockError('OUT_OF_STOCK', `${product.name} sedang habis`, {
                product_id: product.id,
                available: 0
            });
        }
        if (product.stock_mode === 'TOGGLE') {
            results.push({ product_id: product.id, quantity: qty, held: false });
            continue;
        }

        const availResult = await client.query(
            `SELECT available FROM v_product_availability WHERE product_id = $1`,
            [product.id]
        );
        const available = Number(availResult.rows[0]?.available || 0);
        if (available + 1e-9 < qty) {
            throw new StockError(
                'OUT_OF_STOCK',
                `Stok ${product.name} tidak mencukupi (tersisa ${round3(available)} ${product.unit})`,
                { product_id: product.id, available: round3(available) }
            );
        }

        await client.query(
            `INSERT INTO tbl_stock_holds (order_id, product_id, quantity, expires_at)
             VALUES ($1, $2, $3, CURRENT_TIMESTAMP + ($4 || ' minutes')::interval)
             ON CONFLICT (order_id, product_id) DO NOTHING`,
            [orderId, product.id, qty, String(ttlMinutes)]
        );
        results.push({ product_id: product.id, quantity: qty, held: true });
    }
    return results;
}

/** Kurangi stok nyata untuk satu penjualan. Idempoten per (produk, refDoc). */
async function decrementForSale(client, opts) {
    const { productId, quantity, refDoc, merchantId = null, source, refId = null, createdBy = null } = opts;
    const qty = round3(quantity);

    const existing = await client.query(
        `SELECT 1 FROM tbl_inventory_movements
         WHERE product_id = $1 AND movement_type = 'SALE' AND reference_doc = $2
         LIMIT 1`,
        [productId, refDoc]
    );
    if (existing.rowCount) return { skipped: true, applied: 0, shortfall: 0 };

    const rows = await client.query(
        `SELECT id, warehouse_id, quantity_on_hand
         FROM tbl_inventory
         WHERE product_id = $1 AND COALESCE(quantity_on_hand, 0) > 0
         ORDER BY quantity_on_hand DESC
         FOR UPDATE`,
        [productId]
    );

    let remaining = qty;
    let primaryWarehouse = null;
    for (const row of rows.rows) {
        if (remaining <= 0) break;
        const take = Math.min(remaining, Number(row.quantity_on_hand));
        await client.query(
            `UPDATE tbl_inventory
             SET quantity_on_hand = quantity_on_hand - $1, updated_at = CURRENT_TIMESTAMP
             WHERE id = $2`,
            [take, row.id]
        );
        if (!primaryWarehouse) primaryWarehouse = row.warehouse_id;
        remaining = round3(remaining - take);
    }

    const applied = round3(qty - remaining);
    if (applied > 0) {
        await client.query(
            `INSERT INTO tbl_inventory_movements
               (product_id, warehouse_id, movement_type, quantity, reference_doc, created_by)
             VALUES ($1, $2, 'SALE', $3, $4, $5)`,
            [productId, primaryWarehouse, applied, refDoc, createdBy]
        );
    }
    if (remaining > 0) {
        await client.query(
            `INSERT INTO tbl_stock_discrepancies
               (product_id, merchant_id, source, ref_id, requested, applied)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [productId, merchantId, source, refId, qty, applied]
        );
    }
    return { skipped: false, applied, shortfall: remaining };
}

/** Komit semua item order setelah dibayar. Aman dipanggil berulang. */
async function commitOrder(client, orderId) {
    const items = await client.query(
        `SELECT oi.product_id, oi.quantity, p.merchant_id, p.stock_mode
         FROM tbl_order_items oi
         JOIN tbl_products p ON p.id = oi.product_id
         WHERE oi.order_id = $1
         ORDER BY oi.product_id`,
        [orderId]
    );
    if (!items.rowCount) {
        throw new StockError('ORDER_EMPTY', `Order ${orderId} tidak memiliki item`);
    }

    const summary = { committed: 0, skipped: 0, shortfalls: [] };
    for (const item of items.rows) {
        if (item.stock_mode === 'TOGGLE') {
            summary.skipped += 1;
            continue;
        }
        const hold = await client.query(
            `SELECT id, status, quantity FROM tbl_stock_holds
             WHERE order_id = $1 AND product_id = $2
             FOR UPDATE`,
            [orderId, item.product_id]
        );
        if (hold.rowCount && hold.rows[0].status === 'COMMITTED') {
            summary.skipped += 1;
            continue;
        }
        const result = await decrementForSale(client, {
            productId: item.product_id,
            quantity: hold.rowCount ? hold.rows[0].quantity : item.quantity,
            refDoc: `ORD-${orderId}`,
            merchantId: item.merchant_id,
            source: 'ONLINE_COMMIT',
            refId: orderId
        });
        if (hold.rowCount) {
            await client.query(
                `UPDATE tbl_stock_holds
                 SET status = 'COMMITTED', committed_at = CURRENT_TIMESTAMP
                 WHERE id = $1 AND status = 'HELD'`,
                [hold.rows[0].id]
            );
        }
        if (result.skipped) summary.skipped += 1;
        else summary.committed += 1;
        if (result.shortfall > 0) {
            summary.shortfalls.push({ product_id: item.product_id, shortfall: result.shortfall });
        }
    }
    return summary;
}

/** Lepas tahanan stok (order batal / kedaluwarsa). */
async function releaseOrder(client, orderId) {
    const res = await client.query(
        `UPDATE tbl_stock_holds
         SET status = 'RELEASED', released_at = CURRENT_TIMESTAMP
         WHERE order_id = $1 AND status = 'HELD'`,
        [orderId]
    );
    return res.rowCount;
}

/** Setel stok (opname). Mencatat movement ADJUSTMENT agar bisa ditelusuri. */
async function setOnHand(client, { productId, quantity, userId = null, reason = 'OPNAME' }) {
    const target = round3(quantity);
    if (!Number.isFinite(target) || target < 0) {
        throw new StockError('INVALID_QUANTITY', 'Stok tidak boleh negatif');
    }
    const rows = await client.query(
        `SELECT id, warehouse_id, quantity_on_hand
         FROM tbl_inventory
         WHERE product_id = $1
         ORDER BY quantity_on_hand DESC
         FOR UPDATE`,
        [productId]
    );

    let warehouseId;
    let current = 0;
    if (rows.rowCount) {
        current = rows.rows.reduce((s, r) => s + Number(r.quantity_on_hand || 0), 0);
        const primary = rows.rows[0];
        warehouseId = primary.warehouse_id;
        const othersTotal = round3(current - Number(primary.quantity_on_hand || 0));
        const primaryTarget = Math.max(round3(target - othersTotal), 0);
        await client.query(
            `UPDATE tbl_inventory
             SET quantity_on_hand = $1, updated_at = CURRENT_TIMESTAMP
             WHERE id = $2`,
            [primaryTarget, primary.id]
        );
    } else {
        const wh = await client.query(
            `SELECT id FROM tbl_warehouses ORDER BY created_at ASC LIMIT 1`
        );
        if (!wh.rowCount) {
            throw new StockError('NO_WAREHOUSE', 'Belum ada gudang/lokasi stok terdaftar');
        }
        warehouseId = wh.rows[0].id;
        await client.query(
            `INSERT INTO tbl_inventory (warehouse_id, product_id, quantity_on_hand)
             VALUES ($1, $2, $3)`,
            [warehouseId, productId, target]
        );
    }

    const delta = round3(target - current);
    if (delta !== 0) {
        await client.query(
            `INSERT INTO tbl_inventory_movements
               (product_id, warehouse_id, movement_type, quantity, reference_doc, created_by)
             VALUES ($1, $2, 'ADJUSTMENT', $3, $4, $5)`,
            [productId, warehouseId, Math.abs(delta), `${reason}:${delta > 0 ? '+' : '-'}`, userId]
        );
    }
    return { previous: round3(current), current: target, delta };
}

/**
 * Pekerjaan berkala:
 *  1) lepas tahanan kedaluwarsa & batalkan order PENDING yang tidak dibayar
 *  2) komit tahanan untuk order yang sudah dibayar tapi event-nya terlewat (mis. server restart)
 *  3) lepas tahanan milik order yang sudah dibatalkan/refund
 */
async function reconcile(pool) {
    const stats = { expired_orders: 0, committed_orders: 0, released_orders: 0 };

    // 1) kedaluwarsa
    const expired = await pool.query(
        `SELECT DISTINCT h.order_id
         FROM tbl_stock_holds h
         LEFT JOIN tbl_orders_v2 o ON o.id = h.order_id
         WHERE h.status = 'HELD'
           AND h.expires_at < CURRENT_TIMESTAMP
           AND (o.id IS NULL OR o.status = 'PENDING')
           AND NOT EXISTS (
                SELECT 1 FROM tbl_payments p
                WHERE p.order_id = h.order_id
                  AND (p.payment_status = 'PAID'
                       OR (p.payment_status = 'UNPAID'
                           AND p.expires_at IS NOT NULL
                           AND p.expires_at > CURRENT_TIMESTAMP))
           )
         LIMIT 200`
    );
    for (const row of expired.rows) {
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            await client.query(
                `UPDATE tbl_orders_v2 SET status = 'CANCELLED'
                 WHERE id = $1 AND status = 'PENDING'`,
                [row.order_id]
            );
            await releaseOrder(client, row.order_id);
            await client.query(
                `WITH expired_groups AS (
                   UPDATE tbl_checkout_groups g SET status='EXPIRED'
                   WHERE g.status='PENDING'
                     AND EXISTS (SELECT 1 FROM tbl_checkout_group_orders x WHERE x.group_id=g.id AND x.order_id=$1)
                     AND NOT EXISTS (SELECT 1 FROM tbl_checkout_group_orders x JOIN tbl_orders_v2 o ON o.id=x.order_id WHERE x.group_id=g.id AND o.status<>'CANCELLED')
                   RETURNING g.id
                 ), released AS (
                   UPDATE tbl_voucher_redemptions vr SET status='RELEASED'
                   WHERE vr.checkout_group_id IN (SELECT id FROM expired_groups) AND vr.status='PENDING'
                   RETURNING vr.voucher_id
                 )
                 UPDATE tbl_vouchers v SET usage_count=GREATEST(v.usage_count-1,0),updated_at=CURRENT_TIMESTAMP
                 WHERE v.id IN (SELECT voucher_id FROM released)`,
                [row.order_id]
            );
            await client.query('COMMIT');
            stats.expired_orders += 1;
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {});
            console.error('[STOCK RECONCILE] gagal melepas order', row.order_id, err.message);
        } finally {
            client.release();
        }
    }

    // 2) dibayar tapi tahanan belum dikomit
    const paid = await pool.query(
        `SELECT DISTINCT h.order_id
         FROM tbl_stock_holds h
         JOIN tbl_orders_v2 o ON o.id = h.order_id
         WHERE h.status = 'HELD'
           AND o.status IN ('PAID','PACKING','DISPATCHED','DELIVERED','CLOSED')
         LIMIT 200`
    );
    for (const row of paid.rows) {
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            await commitOrder(client, row.order_id);
            await client.query('COMMIT');
            stats.committed_orders += 1;
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {});
            console.error('[STOCK RECONCILE] gagal komit order', row.order_id, err.message);
        } finally {
            client.release();
        }
    }

    // 3) order batal/refund yang masih menahan stok
    const dead = await pool.query(
        `SELECT DISTINCT h.order_id
         FROM tbl_stock_holds h
         JOIN tbl_orders_v2 o ON o.id = h.order_id
         WHERE h.status = 'HELD' AND o.status IN ('CANCELLED','REFUNDED')
         LIMIT 200`
    );
    for (const row of dead.rows) {
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            await releaseOrder(client, row.order_id);
            await client.query('COMMIT');
            stats.released_orders += 1;
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {});
        } finally {
            client.release();
        }
    }
    return stats;
}

function startReconciler(pool, intervalMs = 60 * 1000) {
    const timer = setInterval(() => {
        reconcile(pool)
            .then((s) => {
                if (s.expired_orders || s.committed_orders || s.released_orders) {
                    console.log('[STOCK RECONCILE]', JSON.stringify(s));
                }
            })
            .catch((err) => console.error('[STOCK RECONCILE ERROR]', err.message));
    }, intervalMs);
    timer.unref();
    return timer;
}

module.exports = {
    StockError,
    validateQuantity,
    HOLD_TTL_MINUTES,
    reserve,
    commitOrder,
    releaseOrder,
    decrementForSale,
    setOnHand,
    reconcile,
    startReconciler,
    round3
};
