'use strict';

/**
 * GroupPaymentService - satu pembayaran untuk satu keranjang multi-lapak.
 *
 * order_id yang dikirim ke Midtrans = id tbl_checkout_groups.
 * Webhook Midtrans (paymentV2.js) menyerahkan notifikasi ke handleNotification()
 * bila order_id itu adalah id sebuah grup.
 *
 * Saat dibayar, DALAM SATU TRANSAKSI database:
 *   - semua order anak -> PAID,
 *   - payment anak ditandai PAID,
 *   - stok yang ditahan langsung dikomit (tidak bergantung pada event memori).
 */

const PaymentGateway = require('./PaymentGateway');
const OrderFSM = require('../../kernel/OrderFSM');
const StockService = require('../inventory/StockService');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function isGroupId(db, id) {
    if (!UUID_RE.test(String(id || ''))) return false;
    const r = await db.query(`SELECT 1 FROM tbl_checkout_groups WHERE id = $1`, [id]);
    return r.rowCount > 0;
}

async function createIntent(pool, { groupId, customerId, paymentMethod = 'QRIS', channel = null }) {
    const method = String(paymentMethod).toUpperCase();
    if (method !== 'QRIS') {
        return { status: 'unsupported_method' };
    }
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const g = await client.query(
            `SELECT * FROM tbl_checkout_groups WHERE id = $1 FOR UPDATE`,
            [groupId]
        );
        if (!g.rowCount) {
            await client.query('ROLLBACK');
            return { status: 'group_not_found' };
        }
        const group = g.rows[0];
        if (group.customer_id !== customerId) {
            await client.query('ROLLBACK');
            return { status: 'forbidden' };
        }
        if (group.status !== 'PENDING') {
            await client.query('ROLLBACK');
            return { status: 'group_not_pending', currentStatus: group.status };
        }

        if (group.external_transaction_id) {
            const exp = group.payment_expires_at ? new Date(group.payment_expires_at) : null;
            const active = !exp || exp.getTime() > Date.now();
            await client.query('COMMIT');
            return active
                ? { status: 'existing', group }
                : { status: 'expired', group };
        }

        const intent = await PaymentGateway.createPaymentIntent({
            provider: 'MIDTRANS',
            payment_method: method,
            channel: null,
            amount: Number(group.total_amount),
            order_id: group.id
        });

        const updated = await client.query(
            `UPDATE tbl_checkout_groups
             SET provider = $2, payment_method = $3, channel = $4,
                 external_transaction_id = $5, payment_expires_at = $6,
                 gateway_response = $7
             WHERE id = $1
             RETURNING *`,
            [
                group.id,
                intent.provider,
                intent.payment_method,
                intent.channel,
                intent.external_transaction_id,
                intent.expires_at,
                intent.gateway_response
            ]
        );

        // Baris payment anak (UNPAID) agar laporan & penjaga kedaluwarsa stok tetap konsisten.
        const children = await client.query(
            `SELECT o.id, o.total_amount
             FROM tbl_checkout_group_orders x
             JOIN tbl_orders_v2 o ON o.id = x.order_id
             WHERE x.group_id = $1`,
            [group.id]
        );
        for (const child of children.rows) {
            const exists = await client.query(
                `SELECT id FROM tbl_payments
                 WHERE order_id = $1 AND payment_status = 'UNPAID' LIMIT 1`,
                [child.id]
            );
            if (exists.rowCount) {
                await client.query(
                    `UPDATE tbl_payments SET expires_at = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $1`,
                    [exists.rows[0].id, intent.expires_at]
                );
            } else {
                await client.query(
                    `INSERT INTO tbl_payments
                       (order_id, provider, payment_method, channel, payment_status,
                        amount, expires_at, gateway_response)
                     VALUES ($1, $2, $3, $4, 'UNPAID', $5, $6, $7)`,
                    [
                        child.id,
                        intent.provider,
                        intent.payment_method,
                        intent.channel,
                        child.total_amount,
                        intent.expires_at,
                        JSON.stringify({ checkout_group_id: group.id })
                    ]
                );
            }
        }

        await client.query('COMMIT');
        return { status: 'created', group: updated.rows[0] };
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        throw err;
    } finally {
        client.release();
    }
}

/**
 * Dipanggil dari webhook Midtrans SETELAH signature terverifikasi.
 * Mengembalikan { httpStatus, body }.
 */
async function handleNotification(pool, notification, CommerceKernel) {
    const { order_id, transaction_id, transaction_status, fraud_status, status_code, gross_amount } =
        notification;
    const client = await pool.connect();
    const paidChildren = [];
    try {
        await client.query('BEGIN');
        const g = await client.query(
            `SELECT * FROM tbl_checkout_groups WHERE id = $1 FOR UPDATE`,
            [order_id]
        );
        if (!g.rowCount) {
            await client.query('ROLLBACK');
            return { httpStatus: 404, body: { error: 'Grup pembayaran tidak ditemukan' } };
        }
        const group = g.rows[0];

        if (Number(gross_amount) !== Number(group.total_amount)) {
            await client.query('ROLLBACK');
            console.error(`[GROUP PAYMENT] Nominal tidak cocok untuk grup ${group.id}`);
            return { httpStatus: 400, body: { error: 'Nominal pembayaran tidak sesuai' } };
        }

        const isSuccess =
            ['settlement', 'capture'].includes(transaction_status) &&
            String(status_code) === '200' &&
            (!fraud_status || fraud_status === 'accept');
        const isTerminalFail = ['expire', 'cancel'].includes(transaction_status);
        const isDenied = ['deny', 'failure'].includes(transaction_status);

        const children = await client.query(
            `SELECT o.*
             FROM tbl_checkout_group_orders x
             JOIN tbl_orders_v2 o ON o.id = x.order_id
             WHERE x.group_id = $1
             ORDER BY o.id
             FOR UPDATE OF o`,
            [group.id]
        );

        if (isSuccess) {
            if (group.status === 'PAID') {
                await client.query('COMMIT');
                return { httpStatus: 200, body: { status: 'success', message: 'Webhook sudah pernah diproses' } };
            }
            const anomalies = [];
            for (const child of children.rows) {
                if (child.status !== 'PENDING') {
                    anomalies.push({ order_id: child.id, status: child.status });
                    continue;
                }
                OrderFSM.assertTransition(child.status, 'PAID');
                await client.query(`UPDATE tbl_orders_v2 SET status = 'PAID' WHERE id = $1`, [child.id]);

                const upd = await client.query(
                    `UPDATE tbl_payments
                     SET payment_status = 'PAID',
                         external_transaction_id = COALESCE($2, external_transaction_id),
                         gateway_response = COALESCE(gateway_response, '{}'::jsonb) || $3::jsonb,
                         updated_at = CURRENT_TIMESTAMP
                     WHERE order_id = $1 AND payment_status = 'UNPAID'
                     RETURNING id, payment_method, amount`,
                    [child.id, transaction_id || null, JSON.stringify({ ...notification, checkout_group_id: group.id })]
                );
                let paymentRow = upd.rows[0];
                if (!paymentRow) {
                    const ins = await client.query(
                        `INSERT INTO tbl_payments
                           (order_id, provider, payment_method, payment_status, amount,
                            external_transaction_id, gateway_response)
                         VALUES ($1, 'MIDTRANS', $2, 'PAID', $3, $4, $5)
                         RETURNING id, payment_method, amount`,
                        [
                            child.id,
                            group.payment_method || 'QRIS',
                            child.total_amount,
                            transaction_id || null,
                            JSON.stringify({ ...notification, checkout_group_id: group.id })
                        ]
                    );
                    paymentRow = ins.rows[0];
                }

                // Komit stok di transaksi yang sama (stok sudah ditahan saat checkout).
                await StockService.commitOrder(client, child.id);

                paidChildren.push({ child, paymentRow });
            }

            await client.query(
                `UPDATE tbl_voucher_redemptions SET status='REDEEMED'
                 WHERE checkout_group_id=$1 AND status='PENDING'`,
                [group.id]
            );

            await client.query(
                `UPDATE tbl_checkout_groups
                 SET status = 'PAID', paid_at = CURRENT_TIMESTAMP,
                     external_transaction_id = COALESCE($2, external_transaction_id),
                     gateway_response = COALESCE(gateway_response, '{}'::jsonb) || $3::jsonb
                 WHERE id = $1`,
                [group.id, transaction_id || null, JSON.stringify(notification)]
            );
            await client.query('COMMIT');

            for (const { child, paymentRow } of paidChildren) {
                CommerceKernel.emitEvent('ORDER_PAID', 'ORDER', child.id, {
                    version: 'v2',
                    ...child,
                    status: 'PAID',
                    orderId: child.id,
                    order_reference: child.id,
                    payment_id: paymentRow.id,
                    payment_method: paymentRow.payment_method,
                    payment_status: 'PAID',
                    amount: paymentRow.amount,
                    checkout_group_id: group.id
                });
            }
            CommerceKernel.emitEvent('CHECKOUT_GROUP_PAID', 'CHECKOUT_GROUP', group.id, {
                group_id: group.id,
                total_amount: group.total_amount,
                shipping_fee: group.shipping_fee,
                shipping_subsidy: group.shipping_subsidy,
                orders: paidChildren.map((p) => p.child.id)
            });
            if (anomalies.length) {
                console.error(
                    `[GROUP PAYMENT] Pembayaran masuk tetapi sebagian order tidak PENDING (perlu cek/refund):`,
                    JSON.stringify(anomalies)
                );
                CommerceKernel.emitEvent('GROUP_PAYMENT_ANOMALY', 'CHECKOUT_GROUP', group.id, { anomalies });
            }
            return { httpStatus: 200, body: { status: 'success', message: 'Pembayaran grup dikonfirmasi PAID' } };
        }

        if (isTerminalFail || isDenied) {
            await client.query(
                `UPDATE tbl_payments
                 SET payment_status = 'FAILED',
                     gateway_response = COALESCE(gateway_response, '{}'::jsonb) || $2::jsonb,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE payment_status = 'UNPAID'
                   AND order_id IN (SELECT order_id FROM tbl_checkout_group_orders WHERE group_id = $1)`,
                [group.id, JSON.stringify(notification)]
            );
            if (isTerminalFail && group.status === 'PENDING') {
                for (const child of children.rows) {
                    if (child.status === 'PENDING') {
                        await client.query(`UPDATE tbl_orders_v2 SET status = 'CANCELLED' WHERE id = $1`, [child.id]);
                        await StockService.releaseOrder(client, child.id);
                    }
                }
                await client.query(
                    `UPDATE tbl_checkout_groups SET status = $2 WHERE id = $1`,
                    [group.id, transaction_status === 'cancel' ? 'CANCELLED' : 'EXPIRED']
                );
                await client.query(
                    `WITH released AS (
                       UPDATE tbl_voucher_redemptions SET status='RELEASED'
                       WHERE checkout_group_id=$1 AND status='PENDING'
                       RETURNING voucher_id
                     )
                     UPDATE tbl_vouchers v SET usage_count=GREATEST(v.usage_count-1,0),updated_at=CURRENT_TIMESTAMP
                     WHERE v.id IN (SELECT voucher_id FROM released)`,
                    [group.id]
                );
            }
            await client.query('COMMIT');
            return { httpStatus: 200, body: { status: 'success', message: 'Status pembayaran grup diperbarui' } };
        }

        await client.query(
            `UPDATE tbl_checkout_groups
             SET gateway_response = COALESCE(gateway_response, '{}'::jsonb) || $2::jsonb
             WHERE id = $1`,
            [group.id, JSON.stringify(notification)]
        );
        await client.query('COMMIT');
        return { httpStatus: 200, body: { status: 'success', message: 'Webhook diterima', transaction_status } };
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error('[GROUP PAYMENT ERROR]', err.message);
        return { httpStatus: 500, body: { error: 'Gagal memproses notifikasi pembayaran' } };
    } finally {
        client.release();
    }
}

module.exports = { createIntent, handleNotification, isGroupId };
