'use strict';

/**
 * Pembaca daftar belanja berbahasa sehari-hari (deterministik, tanpa AI).
 * Contoh yang dipahami:
 *   "cabe rawit 1/4 kg"      "bawang merah sekilo"     "telur 2 kg"
 *   "tomat setengah kilo"    "daun bumbu 3 ikat"       "beras 250 gram"
 * Pemisah: baris baru, koma, titik koma, atau kata "dan".
 *
 * AI (Gemini) hanya OPSIONAL membantu membaca teks; pencocokan ke katalog, harga,
 * stok, dan pembuatan pesanan SELALU dilakukan kode ini dengan data database.
 */

const WORD_NUM = {
    satu: 1, dua: 2, tiga: 3, empat: 4, lima: 5, enam: 6, tujuh: 7,
    delapan: 8, sembilan: 9, sepuluh: 10
};
const UNIT_MAP = {
    kg: 'kg', kilo: 'kg', kilogram: 'kg', ons: 'ons', gram: 'g', gr: 'g', g: 'g',
    liter: 'l', lt: 'l', l: 'l', ikat: 'ikat', butir: 'butir', buah: 'pcs', biji: 'pcs',
    pcs: 'pcs', bungkus: 'bungkus', bks: 'bungkus', pack: 'pack', sisir: 'sisir',
    botol: 'botol', papan: 'papan', potong: 'potong', ekor: 'ekor', lembar: 'lembar',
    sachet: 'sachet', dus: 'dus', karton: 'dus', pak: 'pack'
};
const UNIT_RE = Object.keys(UNIT_MAP).sort((a, b) => b.length - a.length).join('|');
const FILLER_RE = /\b(beli|pesan|order|mau|minta|tolong|dong|ya|yaa|saya|aku|kak|bu|pak|mbak|mas|aja|saja|nya)\b/g;

function canonicalUnit(text) {
    if (!text) return null;
    return UNIT_MAP[String(text).toLowerCase().trim()] || null;
}

function normalizeNumbers(text) {
    // koma desimal "1,5" -> "1.5" (supaya tidak dianggap pemisah daftar)
    return text.replace(/(\d),(\d)/g, '$1.$2');
}

function splitSegments(text) {
    const cleaned = normalizeNumbers(String(text || '').toLowerCase());
    return cleaned
        .split(/\r?\n|;|,|\bdan\b|\+/)
        .map((s) => s.replace(/^[\s\-•*\d]+[.)]\s+/, '').replace(/^[\s\-•*]+/, '').trim())
        .filter(Boolean);
}

/** Satu potongan teks -> { name, quantity, unit } atau null. */
function parseSegment(segment) {
    let s = ` ${segment} `.replace(FILLER_RE, ' ').replace(/\s+/g, ' ');
    let quantity = null;
    let unit = null;
    let m;

    const take = (match) => { s = s.replace(match[0], ' '); };

    // pecahan: "1/4 kg", "1 1/2 kg"
    if ((m = s.match(new RegExp(`(?:(\\d+)\\s+)?(\\d+)\\s*/\\s*(\\d+)\\s*(${UNIT_RE})?\\b`)))) {
        const whole = m[1] ? Number(m[1]) : 0;
        if (Number(m[3]) > 0) {
            quantity = whole + Number(m[2]) / Number(m[3]);
            unit = canonicalUnit(m[4]);
            take(m);
        }
    }
    // angka + satuan: "2kg", "250 gram", "1.5 kg"
    if (quantity === null && (m = s.match(new RegExp(`(\\d+(?:\\.\\d+)?)\\s*(${UNIT_RE})\\b`)))) {
        quantity = Number(m[1]);
        unit = canonicalUnit(m[2]);
        take(m);
    }
    // kata gabungan: "sekilo", "seikat", "sebungkus"
    if (quantity === null && (m = s.match(new RegExp(`\\bse(${UNIT_RE})\\b`)))) {
        quantity = 1;
        unit = canonicalUnit(m[1]);
        take(m);
    }
    // "setengah (kilo)", "seperempat (kilo)", "tiga perempat (kilo)"
    if (quantity === null && (m = s.match(new RegExp(`\\b(setengah|seperempat|tiga perempat)\\s*(${UNIT_RE})?\\b`)))) {
        quantity = m[1] === 'setengah' ? 0.5 : m[1] === 'seperempat' ? 0.25 : 0.75;
        unit = canonicalUnit(m[2]);
        take(m);
    }
    // "dua kilo", "tiga ikat"
    if (quantity === null && (m = s.match(new RegExp(`\\b(${Object.keys(WORD_NUM).join('|')})\\s*(${UNIT_RE})?\\b`)))) {
        quantity = WORD_NUM[m[1]];
        unit = canonicalUnit(m[2]);
        take(m);
    }
    // angka polos di awal/akhir: "tomat 3"
    if (quantity === null && (m = s.match(/(?:^|\s)(\d+(?:\.\d+)?)(?=\s|$)/))) {
        quantity = Number(m[1]);
        take(m);
    }

    const name = s
        .replace(/\b(yang|bagus|segar|fresh|banyak|sedikit)\b/g, ' ')
        .replace(/[^a-z0-9\u00C0-\u024F\s-]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    if (!name || name.length < 2) return null;
    if (quantity !== null && (!Number.isFinite(quantity) || quantity <= 0 || quantity > 1000)) return null;
    return { name, quantity, unit };
}

function parseShoppingList(text) {
    const items = [];
    for (const seg of splitSegments(text)) {
        const parsed = parseSegment(seg);
        if (parsed) items.push({ ...parsed, raw: seg });
    }
    return items.slice(0, 40);
}

const QTY_HINT = new RegExp(
    `(\\d+\\s*/\\s*\\d+)|(\\d+(?:[.,]\\d+)?\\s*(${UNIT_RE})\\b)|\\bse(${UNIT_RE})\\b|\\b(setengah|seperempat)\\b|\\b(${Object.keys(WORD_NUM).join('|')})\\s+(${UNIT_RE})\\b`
);

/** Apakah pesan ini terlihat seperti daftar belanja (bukan satu perintah biasa)? */
function looksLikeShoppingList(text) {
    const raw = String(text || '').toLowerCase();
    const lines = raw.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const segments = lines.length > 1 ? lines : splitSegments(raw);
    if (segments.length < 2) return false;
    if (segments.some((l) => l.length > 80)) return false;
    const withQty = segments.filter((l) => QTY_HINT.test(normalizeNumbers(l)) || /\s\d+\s*$/.test(l)).length;
    return withQty >= 2 && withQty >= Math.ceil(segments.length * 0.6);
}

/** Ubah jumlah dari teks pembeli ke satuan produk. Mengembalikan { quantity } atau { error }. */
function toProductQuantity(parsed, product) {
    const pUnit = canonicalUnit(product.unit) || String(product.unit || '').toLowerCase();
    let q = parsed.quantity === null ? 1 : parsed.quantity;
    const u = parsed.unit;

    if (u && u !== pUnit) {
        if (pUnit === 'kg' && u === 'ons') q = q * 0.1;
        else if (pUnit === 'kg' && u === 'g') q = q / 1000;
        else if (pUnit === 'g' && u === 'kg') q = q * 1000;
        else if (pUnit === 'g' && u === 'ons') q = q * 100;
        else if (pUnit === 'ons' && u === 'kg') q = q * 10;
        else if (pUnit === 'pcs' && ['butir', 'buah', 'biji'].includes(u)) { /* setara */ }
        else if (pUnit === 'butir' && u === 'pcs') { /* setara */ }
        else {
            return { error: `${product.name} dijual per ${product.unit}, bukan per ${u}` };
        }
    }

    if (product.allow_decimal) {
        const step = Number(product.unit_step || 0.25);
        q = Math.max(step, Math.round(q / step) * step);
        q = Math.round(q * 1000) / 1000;
    } else {
        q = Math.max(1, Math.round(q));
    }
    if (q > 1000) return { error: 'Jumlah terlalu besar' };
    return { quantity: q };
}

module.exports = {
    parseShoppingList,
    parseSegment,
    looksLikeShoppingList,
    toProductQuantity,
    canonicalUnit,
    UNIT_MAP
};
