class WhatsAppIntentRouter {
    route({ intent, text, customer }) {
        const normalizedIntent =
            String(intent || 'UNKNOWN')
                .trim()
                .toUpperCase();

        const context = {
            text: String(text || '').trim(),
            customer: customer || null
        };

        switch (normalizedIntent) {
            case 'MULTI_COMMAND':
                return {
                    handler: 'MULTI_COMMAND_HANDLER',
                    action: 'RESPOND_ONLY',
                    context
                };
            case 'ORDER_CONFIRMATION':
                return {
                    handler: 'ORDER_CONFIRMATION_HANDLER',
                    action: 'VALIDATE_DRAFT_CONFIRMATION',
                    context
                };

            case 'ORDER_CANCEL':
                return {
                    handler: 'ORDER_CANCEL_HANDLER',
                    action: 'CANCEL_DRAFT',
                    context
                };

            case 'PAYMENT_REQUEST':
                return {
                    handler: 'PAYMENT_REQUEST_HANDLER',
                    action: 'CREATE_PAYMENT_INTENT',
                    context
                };

            case 'GREETING':
                return {
                    handler: 'GREETING_HANDLER',
                    action: 'RESPOND_ONLY',
                    context
                };

            case 'SHOPPING_LIST':
                return {
                    handler: 'SHOPPING_LIST_HANDLER',
                    action: 'CREATE_CART_DRAFT',
                    context
                };
            case 'CART_PICKUP':
                return {
                    handler: 'SHOPPING_LIST_HANDLER',
                    action: 'SET_PICKUP',
                    context
                };
            case 'PRODUCT_INQUIRY':
                return {
                    handler: 'PRODUCT_INQUIRY_HANDLER',
                    action: 'READ_CATALOG',
                    context
                };

            case 'PRODUCT_ORDER':
                return {
                    handler: 'PRODUCT_ORDER_DRAFT_HANDLER',
                    action: 'CREATE_DRAFT_ONLY',
                    context
                };

            case 'ORDER_STATUS':
                return {
                    handler: 'ORDER_STATUS_HANDLER',
                    action: 'READ_CUSTOMER_ORDERS',
                    context
                };

            case 'ADDRESS_UPDATE':
                return {
                    handler: 'ADDRESS_UPDATE_HANDLER',
                    action: 'REQUIRE_CONFIRMATION',
                    context
                };

            case 'EMPTY_MESSAGE':
                return {
                    handler: 'EMPTY_MESSAGE_HANDLER',
                    action: 'RESPOND_ONLY',
                    context
                };

            default:
                return {
                    handler: 'FALLBACK_HANDLER',
                    action: 'RESPOND_ONLY',
                    context
                };
        }
    }
}

module.exports = WhatsAppIntentRouter;
