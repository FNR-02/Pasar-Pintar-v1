'use strict';

/**
 * ShoppingListHandler - daftar belanja WhatsApp lintas lapak.
 *
 * Pembeli kirim beberapa baris barang -> bot mencocokkan ke katalog (harga & stok dari
 * v_product_availability, satu sumber kebenaran) -> ringkasan per lapak + ongkir ->
 * KONFIRMASI membuat pesanan multi-lapak (GroupCheckoutService, stok ditahan) ->
 * BAYAR membuat satu QRIS untuk seluruh keranjang (GroupPaymentService).
 */

const { parseShoppingList, toProductQuantity } = require('./ShoppingListParser');
const { parseWithGemini } = require('./GeminiListParser');
const GroupCheckoutService = require('../checkout/GroupCheckoutService');
const GroupPaymentService = require('../payments/GroupPaymentService');
const ShippingService = require('../shipping/ShippingService');
const CommerceKernel = require('../../kernel/EventKernel');

const rp = (n) => 'Rp' + Math.round(Number(n) || 0).toLocaleString('id-ID');
const fq = (q) => Number(q).toLocaleString('id-ID', { maximumFractionDigits: 3 });

class ShoppingListHandler {
    constructor(pool) {
        this.pool = pool;
    }

    /* ---------- pencocokan ke katalog ---------- */
    async findProduct(name) {
        const tokens = name.split(' ').filter((t) => t.length >= 2).slice(0, 5);
        if (!tokens.length) return { status: 'none' };
        const patterns = tokens.map((t) => `%${t.replace(/[%_\\]/g, '')}%`);
        const r = await this.pool.query(
            `SELECT p.id, p.name, p.unit, p.unit_step, p.allow_decimal, p.stock_mode,
                    m.store_name, price.amount AS price, a.available
             FROM tbl_products p
             JOIN tbl_merchants m ON m.id = p.merchant_id AND m.status = 'ACTIVE'
             JOIN v_product_availability a ON a.product_id = p.id
             JOIN LATERAL (
                 SELECT pp.amount FROM tbl_product_prices pp
                 WHERE pp.product_id = p.id AND pp.price_type = 'RETAIL'
                 ORDER BY pp.effective_date DESC LIMIT 1
             ) price ON TRUE
             WHERE p.status = 'ACTIVE' AND p.name ILIKE ALL($1::text[])
             ORDER BY (LOWER(p.name) = $2) DESC, (a.available > 0) DESC, price.amount ASC
             LIMIT 8`,
            [patterns, name]
        );
        if (!r.rowCount) return { status: 'none' };
        const exact = r.rows.filter((x) => x.name.toLowerCase() === name);
        const pool = exact.length ? exact : r.rows;
        const distinctNames = [...new Set(pool.map((x) => x.name.toLowerCase()))];
        if (distinctNames.length > 1) {
            return { status: 'ambiguous', options: distinctNames.slice(0, 4) };
        }
        const available = pool.filter((x) => Number(x.available) > 0);
        if (!available.length) return { status: 'soldout', product: pool[0] };
        return { status: 'ok', product: available[0] };
    }

    async buildDraftItems(parsedItems) {
        const items = [];
        const unmatched = [];
        const seen = new Map();
        for (const parsed of parsedItems) {
            const found = await this.findProduct(parsed.name);
            if (found.status === 'none') {
                unmatched.push({ name: parsed.name, reason: 'tidak ditemukan' });
                continue;
            }
            if (found.status === 'ambiguous') {
                unmatched.push({ name: parsed.name, reason: `pilih salah satu: ${found.options.join(' / ')}` });
                continue;
            }
            if (found.status === 'soldout') {
                unmatched.push({ name: parsed.name, reason: `${found.product.name} sedang habis` });
                continue;
            }
            const p = found.product;
            const q = toProductQuantity(parsed, p);
            if (q.error) {
                unmatched.push({ name: parsed.name, reason: q.error });
                continue;
            }
            if (q.quantity > Number(p.available)) {
                unmatched.push({
                    name: parsed.name,
                    reason: `stok ${p.name} tersisa ${fq(p.available)} ${p.unit}`
                });
                continue;
            }
            if (seen.has(p.id)) {
                const prev = items[seen.get(p.id)];
                prev.quantity = Math.round((prev.quantity + q.quantity) * 1000) / 1000;
                continue;
            }
            seen.set(p.id, items.length);
            items.push({
                product_id: p.id,
                name: p.name,
                unit: p.unit,
                quantity: q.quantity,
                unit_price: Number(p.price),
                store_name: p.store_name
            });
        }
        return { items, unmatched };
    }

    summarize(draft, shipping) {
        const byStore = new Map();
        for (const it of draft.items) {
            if (!byStore.has(it.store_name)) byStore.set(it.store_name, []);
            byStore.get(it.store_name).push(it);
        }
        const lines = ['Daftar belanja Anda:', ''];
        for (const [store, list] of byStore) {
            lines.push(store);
            for (const it of list) {
                lines.push(`- ${it.name} ${fq(it.quantity)} ${it.unit} x ${rp(it.unit_price)} = ${rp(it.unit_price * it.quantity)}`);
            }
            lines.push('');
        }
        const subtotal = draft.items.reduce((s, i) => s + Math.round(i.unit_price * i.quantity), 0);
        lines.push(`Subtotal: ${rp(subtotal)}`);
        if (draft.fulfillment_type === 'PICKUP') {
            lines.push('Ambil sendiri di pasar (tanpa ongkir)');
        } else if (shipping) {
            lines.push(shipping.customer_fee === 0 ? 'Ongkir: gratis' : `Ongkir: ${rp(shipping.customer_fee)}`);
            lines.push(`Total: ${rp(subtotal + shipping.customer_fee)}`);
            if (shipping.note && shipping.customer_fee > 0) lines.push(shipping.note);
        }
        if (draft.unmatched.length) {
            lines.push('', 'Belum bisa diproses:');
            for (const u of draft.unmatched) lines.push(`- ${u.name} (${u.reason})`);
        }
        lines.push('');
        if (draft.fulfillment_type === 'DELIVERY') {
            lines.push(
                draft.shipping_address
                    ? `Alamat: ${draft.shipping_address}`
                    : 'Kirim alamat dengan "antar ke <alamat lengkap>", atau balas AMBIL untuk ambil sendiri.'
            );
        }
        lines.push('Balas KONFIRMASI untuk membuat pesanan, atau BATAL untuk membatalkan.');
        return lines.join('\n');
    }

    async quoteFor(draft) {
        const subtotal = draft.items.reduce((s, i) => s + Math.round(i.unit_price * i.quantity), 0);
        try {
            return await ShippingService.quote(this.pool, {
                fulfillmentType: draft.fulfillment_type,
                subtotal
            });
        } catch (err) {
            if (err instanceof ShippingService.ShippingError) return { customer_fee: 0, note: err.message, blocked: err.message };
            throw err;
        }
    }

    /* ---------- pesan daftar baru ---------- */
    async handle({ text, customer }) {
        const customerId = customer?.customer_id;
        if (!customerId) {
            return { cart: true, status: 'customer_missing', responseText: 'Data pelanggan tidak ditemukan. Silakan daftar atau verifikasi nomor Anda dulu.' };
        }
        let parsed = null;
        let usedAi = false;
        const ai = await parseWithGemini(text);
        if (ai) {
            parsed = ai;
            usedAi = true;
        } else {
            parsed = parseShoppingList(text);
        }
        if (!parsed.length) {
            return {
                cart: true,
                status: 'cart_empty',
                responseText: 'Saya belum menemukan barang di pesan itu. Contoh: "cabe rawit 1/4 kg, bawang merah 1 kg, telur 2 kg".'
            };
        }

        const { items, unmatched } = await this.buildDraftItems(parsed);
        if (!items.length) {
            return {
                cart: true,
                status: 'cart_nothing_matched',
                responseText:
                    'Belum ada barang yang cocok dengan katalog:\n' +
                    unmatched.map((u) => `- ${u.name} (${u.reason})`).join('\n') +
                    '\n\nKetik "katalog" untuk melihat barang yang tersedia.'
            };
        }

        const subtotal = items.reduce((s, i) => s + Math.round(i.unit_price * i.quantity), 0);
        const client = await this.pool.connect();
        let draftRow;
        try {
            await client.query('BEGIN');
            await client.query(
                `UPDATE tbl_whatsapp_cart_drafts SET status = 'CANCELLED'
                 WHERE customer_id = $1 AND status = 'PENDING_CONFIRMATION'`,
                [customerId]
            );
            const ins = await client.query(
                `INSERT INTO tbl_whatsapp_cart_drafts
                   (customer_id, items, unmatched, subtotal, source_text)
                 VALUES ($1, $2, $3, $4, $5)
                 RETURNING *`,
                [customerId, JSON.stringify(items), JSON.stringify(unmatched), subtotal, String(text).slice(0, 1500)]
            );
            draftRow = ins.rows[0];
            await client.query('COMMIT');
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {});
            throw err;
        } finally {
            client.release();
        }

        const draft = { ...draftRow, items, unmatched };
        const shipping = await this.quoteFor(draft);
        return {
            cart: true,
            status: 'cart_draft_ready',
            usedAi,
            responseText: this.summarize(draft, shipping)
        };
    }

    async latestCart(customerId) {
        const r = await this.pool.query(
            `SELECT * FROM tbl_whatsapp_cart_drafts
             WHERE customer_id = $1 AND status = 'PENDING_CONFIRMATION' AND expires_at > CURRENT_TIMESTAMP
             ORDER BY created_at DESC LIMIT 1`,
            [customerId]
        );
        return r.rows[0] || null;
    }

    /* ---------- perintah lanjutan: konfirmasi / batal / bayar / alamat / ambil ---------- */
    async handleControl({ intent, text, customer }) {
        const customerId = customer?.customer_id;
        if (!customerId) return null;

        if (intent === 'PAYMENT_REQUEST') return this.pay(customerId);

        const cart = await this.latestCart(customerId);
        if (!cart) return null;

        // Bila ada draf produk tunggal yang lebih baru, biarkan alur lama menanganinya.
        const single = await this.pool.query(
            `SELECT created_at FROM tbl_whatsapp_order_drafts
             WHERE customer_id = $1 AND status = 'PENDING_CONFIRMATION' AND expires_at > CURRENT_TIMESTAMP
             ORDER BY created_at DESC LIMIT 1`,
            [customerId]
        );
        if (single.rowCount && new Date(single.rows[0].created_at) > new Date(cart.created_at)) return null;

        if (intent === 'ORDER_CANCEL') {
            await this.pool.query(`UPDATE tbl_whatsapp_cart_drafts SET status = 'CANCELLED' WHERE id = $1`, [cart.id]);
            return { cart: true, status: 'cart_cancelled', responseText: 'Daftar belanja dibatalkan.' };
        }
        if (intent === 'ADDRESS_UPDATE') {
            const address = String(text || '')
                .replace(/^(alamat|kirim ke|antar ke|lokasi)\s*[:\-]?\s*/i, '')
                .trim()
                .slice(0, 300);
            if (address.length < 8) {
                return { cart: true, status: 'address_missing', responseText: 'Kirim alamat lengkap, contoh: "antar ke Jl. Merdeka No. 10 Bandung".' };
            }
            await this.pool.query(
                `UPDATE tbl_whatsapp_cart_drafts SET shipping_address = $2, fulfillment_type = 'DELIVERY' WHERE id = $1`,
                [cart.id, address]
            );
            const draft = { ...cart, shipping_address: address, fulfillment_type: 'DELIVERY' };
            return { cart: true, status: 'address_updated', responseText: this.summarize(draft, await this.quoteFor(draft)) };
        }
        if (intent === 'CART_PICKUP') {
            await this.pool.query(
                `UPDATE tbl_whatsapp_cart_drafts SET fulfillment_type = 'PICKUP', shipping_address = NULL WHERE id = $1`,
                [cart.id]
            );
            const draft = { ...cart, fulfillment_type: 'PICKUP', shipping_address: null };
            return { cart: true, status: 'pickup_selected', responseText: this.summarize(draft, null) };
        }
        if (intent === 'ORDER_CONFIRMATION') return this.confirm(customerId, cart);
        return null;
    }

    async confirm(customerId, cart) {
        if (cart.fulfillment_type === 'DELIVERY' && !String(cart.shipping_address || '').trim()) {
            return {
                cart: true,
                status: 'shipping_address_required',
                responseText: 'Alamat belum ada. Kirim "antar ke <alamat lengkap>", atau balas AMBIL untuk ambil sendiri.'
            };
        }
        const items = cart.items;
        const client = await this.pool.connect();
        try {
            await client.query('BEGIN');
            const locked = await client.query(
                `SELECT * FROM tbl_whatsapp_cart_drafts WHERE id = $1 AND status = 'PENDING_CONFIRMATION' FOR UPDATE`,
                [cart.id]
            );
            if (!locked.rowCount) {
                await client.query('ROLLBACK');
                return { cart: true, status: 'cart_gone', responseText: 'Daftar belanja sudah tidak aktif. Kirim daftar baru ya.' };
            }

            const result = await GroupCheckoutService.createFromItems(client, {
                customerId,
                items: items.map((i) => ({ product_id: i.product_id, quantity: i.quantity })),
                fulfillmentType: cart.fulfillment_type,
                shippingAddress: cart.shipping_address,
                channel: 'WHATSAPP'
            });

            // Harga berubah sejak ringkasan ditampilkan -> minta konfirmasi ulang dengan angka baru.
            if (Math.round(result.subtotal) !== Math.round(Number(cart.subtotal))) {
                await client.query('ROLLBACK');
                const refreshed = await this.buildDraftItems(
                    items.map((i) => ({ name: i.name.toLowerCase(), quantity: i.quantity, unit: null }))
                );
                if (refreshed.items.length) {
                    const sub = refreshed.items.reduce((s, i) => s + Math.round(i.unit_price * i.quantity), 0);
                    await this.pool.query(
                        `UPDATE tbl_whatsapp_cart_drafts SET items = $2, subtotal = $3 WHERE id = $1`,
                        [cart.id, JSON.stringify(refreshed.items), sub]
                    );
                    const draft = { ...cart, items: refreshed.items, unmatched: refreshed.unmatched, subtotal: sub };
                    return {
                        cart: true,
                        status: 'cart_repriced',
                        responseText: 'Harga atau stok berubah sejak tadi.\n\n' + this.summarize(draft, await this.quoteFor(draft))
                    };
                }
                return { cart: true, status: 'cart_unavailable', responseText: 'Barang di daftar ini sudah tidak tersedia. Kirim daftar baru ya.' };
            }

            await client.query(
                `UPDATE tbl_whatsapp_cart_drafts SET status = 'CONFIRMED', group_id = $2 WHERE id = $1`,
                [cart.id, result.group.id]
            );
            await client.query('COMMIT');

            for (const order of result.orders) {
                CommerceKernel.emitEvent('ORDER_CREATED', 'ORDER', order.id, {
                    id: order.id,
                    customer_id: order.customer_id,
                    merchant_id: order.merchant_id,
                    status: order.status,
                    total_amount: order.total_amount,
                    checkout_group_id: result.group.id
                });
            }
            return {
                cart: true,
                status: 'cart_confirmed',
                groupId: result.group.id,
                responseText:
                    'Pesanan dibuat.\n\n' +
                    `Total: ${rp(result.total_amount)}` +
                    (result.shipping.customer_fee ? ` (termasuk ongkir ${rp(result.shipping.customer_fee)})` : '') +
                    `\nLapak: ${result.orders.map((o) => o.store_name).join(', ')}\n\n` +
                    'Balas BAYAR untuk mendapatkan QRIS. Stok Anda ditahan sebentar sampai pembayaran masuk.'
            };
        } catch (err) {
            await client.query('ROLLBACK').catch(() => {});
            if (err instanceof GroupCheckoutService.CheckoutError || err instanceof ShippingService.ShippingError) {
                return { cart: true, status: 'cart_rejected', responseText: `Pesanan belum bisa dibuat: ${err.message}` };
            }
            console.error('[WA CART CONFIRM]', err.message);
            return { cart: true, status: 'cart_error', responseText: 'Maaf, terjadi gangguan. Coba balas KONFIRMASI lagi sebentar lagi.' };
        } finally {
            client.release();
        }
    }

    async pay(customerId) {
        // Hanya ambil alih jika grup PENDING terbaru lebih baru daripada order tunggal PENDING.
        const g = await this.pool.query(
            `SELECT id, created_at FROM tbl_checkout_groups
             WHERE customer_id = $1 AND status = 'PENDING'
             ORDER BY created_at DESC LIMIT 1`,
            [customerId]
        );
        if (!g.rowCount) return null;
        const single = await this.pool.query(
            `SELECT created_at FROM tbl_orders_v2
             WHERE customer_id = $1 AND status = 'PENDING' AND checkout_group_id IS NULL
             ORDER BY created_at DESC LIMIT 1`,
            [customerId]
        );
        if (single.rowCount && new Date(single.rows[0].created_at) > new Date(g.rows[0].created_at)) return null;

        const result = await GroupPaymentService.createIntent(this.pool, { groupId: g.rows[0].id, customerId });
        if (result.status === 'expired') {
            return { cart: true, status: 'payment_expired', responseText: 'QRIS sudah kedaluwarsa. Kirim daftar belanja baru ya.' };
        }
        if (!['created', 'existing'].includes(result.status)) {
            return { cart: true, status: result.status, responseText: 'Pembayaran belum dapat dibuat. Coba lagi sebentar lagi.' };
        }
        const grp = result.group;
        const gateway = grp.gateway_response || {};
        const lines = ['Pembayaran QRIS Pasar Pintar', '', `Total: ${rp(grp.total_amount)}`];
        if (grp.payment_expires_at) {
            lines.push(`Berlaku sampai: ${new Date(grp.payment_expires_at).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`);
        }
        if (gateway.qr_code_url) lines.push('', `QRIS: ${gateway.qr_code_url}`);
        return { cart: true, status: 'cart_payment_ready', responseText: lines.join('\n') };
    }
}

module.exports = ShoppingListHandler;
