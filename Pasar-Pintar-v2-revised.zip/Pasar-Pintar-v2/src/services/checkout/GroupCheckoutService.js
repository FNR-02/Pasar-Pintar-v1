'use strict';

/**
 * GroupCheckoutService - satu keranjang berisi barang dari banyak lapak.
 *
 * Hasil: 1 baris tbl_checkout_groups (yang dibayar pembeli, termasuk ongkir)
 *        + N baris tbl_orders_v2 (satu per lapak, total = subtotal barang saja).
 * Jadi seluruh alur merchant/kurir/laporan yang sudah ada tetap bekerja per
 * lapak, sementara pembeli cukup membayar satu kali.
 *
 * Dipakai oleh: POST /api/v3/checkout (web/app) dan alur daftar belanja WhatsApp.
 */

const StockService = require('../inventory/StockService');
const ShippingService = require('../shipping/ShippingService');

class CheckoutError extends Error {
    constructor(code, message, httpStatus = 400, extra = {}) {
        super(message);
        this.name = 'CheckoutError';
        this.code = code;
        this.httpStatus = httpStatus;
        Object.assign(this, extra);
    }
}

const MAX_LINES = 60;

function normalizeItems(items) {
    if (!Array.isArray(items) || items.length === 0) {
        throw new CheckoutError('EMPTY_CART', 'Keranjang kosong');
    }
    const merged = new Map();
    for (const raw of items) {
        const productId = String(raw?.product_id || '').trim();
        if (!productId) throw new CheckoutError('INVALID_ITEM', 'product_id wajib diisi');
        const qty = Number(raw.quantity);
        if (!Number.isFinite(qty) || qty <= 0) {
            throw new CheckoutError('INVALID_QUANTITY', 'Jumlah tidak valid', 400, {
                product_id: productId
            });
        }
        merged.set(productId, StockService.round3((merged.get(productId) || 0) + qty));
    }
    if (merged.size > MAX_LINES) {
        throw new CheckoutError('TOO_MANY_ITEMS', `Maksimal ${MAX_LINES} jenis barang per pesanan`);
    }
    return [...merged.entries()].map(([product_id, quantity]) => ({ product_id, quantity }));
}

async function loadProducts(client, productIds) {
    const result = await client.query(
        `SELECT p.id, p.merchant_id, p.sku, p.name, p.unit, p.unit_step,
                p.allow_decimal, p.stock_mode, p.is_available,
                m.store_name, m.address AS merchant_address,
                price.amount AS price
         FROM tbl_products p
         JOIN tbl_merchants m ON m.id = p.merchant_id AND m.status = 'ACTIVE'
         LEFT JOIN LATERAL (
             SELECT pp.amount FROM tbl_product_prices pp
             WHERE pp.product_id = p.id AND pp.price_type = 'RETAIL'
             ORDER BY pp.effective_date DESC LIMIT 1
         ) price ON TRUE
         WHERE p.id = ANY($1::uuid[]) AND p.status = 'ACTIVE'`,
        [productIds]
    );
    return new Map(result.rows.map((r) => [r.id, r]));
}

/**
 * @param client  pg client yang SUDAH BEGIN (transaksi dikelola pemanggil)
 */
async function createFromItems(client, opts) {
    const {
        customerId,
        fulfillmentType = 'DELIVERY',
        shippingAddress = null,
        zoneId = null,
        channel = 'WEB'
    } = opts;

    const fulfillment = String(fulfillmentType).toUpperCase();
    if (!['DELIVERY', 'PICKUP'].includes(fulfillment)) {
        throw new CheckoutError('INVALID_FULFILLMENT', 'fulfillment_type harus DELIVERY atau PICKUP');
    }
    if (fulfillment === 'DELIVERY' && !String(shippingAddress || '').trim()) {
        throw new CheckoutError('ADDRESS_REQUIRED', 'Alamat pengiriman wajib diisi untuk DELIVERY');
    }

    const items = normalizeItems(opts.items);
    const products = await loadProducts(client, items.map((i) => i.product_id));

    // Validasi + hitung per lapak
    const byMerchant = new Map();
    for (const item of items) {
        const product = products.get(item.product_id);
        if (!product) {
            throw new CheckoutError('PRODUCT_NOT_FOUND', 'Produk tidak ditemukan atau lapak tidak aktif', 404, {
                product_id: item.product_id
            });
        }
        const qty = StockService.validateQuantity(
            { ...product, id: product.id },
            item.quantity
        );
        const unitPrice = Number(product.price);
        if (!Number.isFinite(unitPrice) || unitPrice <= 0) {
            throw new CheckoutError('PRICE_MISSING', `Harga ${product.name} belum tersedia`, 400, {
                product_id: product.id
            });
        }
        const lineTotal = Math.round(unitPrice * qty);
        if (!byMerchant.has(product.merchant_id)) {
            byMerchant.set(product.merchant_id, {
                merchant_id: product.merchant_id,
                store_name: product.store_name,
                merchant_address: product.merchant_address,
                lines: [],
                subtotal: 0
            });
        }
        const bucket = byMerchant.get(product.merchant_id);
        bucket.lines.push({
            product_id: product.id,
            name: product.name,
            unit: product.unit,
            quantity: qty,
            unit_price: unitPrice,
            line_total: lineTotal
        });
        bucket.subtotal += lineTotal;
    }

    const subtotal = [...byMerchant.values()].reduce((s, b) => s + b.subtotal, 0);
    const shipping = await ShippingService.quote(client, {
        fulfillmentType: fulfillment,
        zoneId,
        subtotal
    });

    // Voucher is locked and redeemed inside the same checkout transaction.
    // This prevents concurrent customers from exceeding the campaign quota.
    let voucher = null;
    let discountAmount = 0;
    const voucherCode = String(opts.promoCode || '').trim().toUpperCase();
    if (voucherCode) {
        const vr = await client.query(
            `SELECT * FROM tbl_vouchers WHERE code = $1 FOR UPDATE`,
            [voucherCode]
        );
        if (!vr.rowCount) throw new CheckoutError('VOUCHER_INVALID', 'Kode voucher tidak ditemukan');
        voucher = vr.rows[0];
        const now = new Date();
        if (!voucher.is_active || now < new Date(voucher.starts_at) || now > new Date(voucher.ends_at)) {
            throw new CheckoutError('VOUCHER_INACTIVE', 'Voucher belum berlaku atau sudah berakhir');
        }
        if (voucher.usage_limit !== null && Number(voucher.usage_count) >= Number(voucher.usage_limit)) {
            throw new CheckoutError('VOUCHER_EXHAUSTED', 'Kuota voucher sudah habis');
        }
        if (subtotal < Number(voucher.min_order_amount)) {
            throw new CheckoutError('VOUCHER_MINIMUM', 'Belanja belum memenuhi minimum penggunaan voucher');
        }
        const used = await client.query(
            `SELECT COUNT(*)::int AS total FROM tbl_voucher_redemptions WHERE voucher_id=$1 AND customer_id=$2`,
            [voucher.id, customerId]
        );
        if (Number(used.rows[0].total) >= Number(voucher.per_user_limit)) {
            throw new CheckoutError('VOUCHER_USER_LIMIT', 'Batas penggunaan voucher untuk akun ini sudah tercapai');
        }
        if (voucher.discount_type === 'FREE_SHIPPING') {
            if (fulfillment !== 'DELIVERY') throw new CheckoutError('VOUCHER_FULFILLMENT', 'Voucher gratis ongkir hanya berlaku untuk pengiriman');
            discountAmount = Number(shipping.customer_fee);
        } else if (voucher.discount_type === 'PERCENT') {
            discountAmount = Math.round(subtotal * Number(voucher.discount_value) / 100);
        } else {
            discountAmount = Number(voucher.discount_value);
        }
        if (voucher.max_discount_amount !== null) discountAmount = Math.min(discountAmount, Number(voucher.max_discount_amount));
        discountAmount = Math.max(0, Math.min(Math.round(discountAmount), subtotal + Number(shipping.customer_fee)));
    }
    const totalAmount = subtotal + shipping.customer_fee - discountAmount;
    if (totalAmount <= 0) {
        throw new CheckoutError('VOUCHER_ZERO_TOTAL', 'Voucher tidak boleh menghapus seluruh nilai pesanan');
    }

    const groupResult = await client.query(
        `INSERT INTO tbl_checkout_groups
           (customer_id, fulfillment_type, shipping_address, zone_id,
            subtotal, shipping_fee, shipping_subsidy, total_amount, discount_amount, voucher_id, voucher_code)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
         RETURNING *`,
        [
            customerId,
            fulfillment,
            fulfillment === 'DELIVERY' ? String(shippingAddress).trim() : null,
            shipping.zone_id,
            subtotal,
            shipping.customer_fee,
            shipping.subsidy,
            totalAmount,
            discountAmount,
            voucher?.id || null,
            voucher?.code || null
        ]
    );
    const group = groupResult.rows[0];
    if (voucher) {
        await client.query(
            `INSERT INTO tbl_voucher_redemptions(voucher_id,customer_id,checkout_group_id,discount_amount) VALUES($1,$2,$3,$4)`,
            [voucher.id, customerId, group.id, discountAmount]
        );
        await client.query(
            `UPDATE tbl_vouchers SET usage_count=usage_count+1,updated_at=CURRENT_TIMESTAMP WHERE id=$1`,
            [voucher.id]
        );
    }

    const orders = [];
    for (const bucket of byMerchant.values()) {
        const orderResult = await client.query(
            `INSERT INTO tbl_orders_v2
               (customer_id, merchant_id, status, shipping_address, total_amount,
                fulfillment_type, pickup_location_snapshot, channel, checkout_group_id)
             VALUES ($1, $2, 'PENDING', $3, $4, $5, $6, $7, $8)
             RETURNING *`,
            [
                customerId,
                bucket.merchant_id,
                fulfillment === 'DELIVERY' ? String(shippingAddress).trim() : null,
                bucket.subtotal,
                fulfillment,
                fulfillment === 'PICKUP' ? bucket.merchant_address || null : null,
                channel,
                group.id
            ]
        );
        const order = orderResult.rows[0];

        for (const line of bucket.lines) {
            await client.query(
                `INSERT INTO tbl_order_items (order_id, product_id, quantity, unit_price)
                 VALUES ($1, $2, $3, $4)`,
                [order.id, line.product_id, line.quantity, line.unit_price]
            );
        }
        await client.query(
            `INSERT INTO tbl_checkout_group_orders (group_id, order_id) VALUES ($1, $2)`,
            [group.id, order.id]
        );

        try {
            await StockService.reserve(
                client,
                order.id,
                bucket.lines.map((l) => ({ product_id: l.product_id, quantity: l.quantity }))
            );
        } catch (err) {
            if (err instanceof StockService.StockError) {
                throw new CheckoutError(err.code, err.message, 409, {
                    product_id: err.product_id,
                    available: err.available
                });
            }
            throw err;
        }

        orders.push({
            ...order,
            store_name: bucket.store_name,
            lines: bucket.lines
        });
    }

    return { group, orders, shipping, subtotal, discount_amount: discountAmount, voucher_code: voucher?.code || null, total_amount: totalAmount };
}

module.exports = { createFromItems, CheckoutError, normalizeItems };
