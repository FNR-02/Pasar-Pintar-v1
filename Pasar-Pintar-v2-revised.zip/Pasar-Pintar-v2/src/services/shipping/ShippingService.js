'use strict';

/**
 * ShippingService
 *
 * Prinsip: pedagang TIDAK dibebani ongkir. Biaya kurir ditanggung pembeli, kecuali
 * belanja memenuhi syarat gratis ongkir, dan itu disubsidi Pasar Pintar dari
 * pendapatan B2B. Agar subsidi tidak menggerus keuangan, ada pagar otomatis:
 *
 *   anggaran subsidi bulan ini = max(SUBSIDY_BOOTSTRAP_BUDGET,
 *                                    SUBSIDY_CAP_PCT x pendapatan B2B bulan ini)
 *
 * Jika anggaran habis, gratis ongkir otomatis nonaktif sampai bulan berikutnya
 * atau sampai pendapatan B2B naik.
 */

const SUBSIDY_CAP_PCT = Number(process.env.SUBSIDY_CAP_PCT || 0.5);
const SUBSIDY_BOOTSTRAP_BUDGET = Number(process.env.SUBSIDY_BOOTSTRAP_BUDGET || 300000);

class ShippingError extends Error {
    constructor(code, message, extra = {}) {
        super(message);
        this.name = 'ShippingError';
        this.code = code;
        Object.assign(this, extra);
    }
}

async function subsidyStatus(db) {
    const rev = await db.query(
        `SELECT COALESCE(SUM(amount), 0) AS total
         FROM tbl_platform_revenue
         WHERE source IN ('B2B_REBATE','B2B_SPREAD','PROMO')
           AND created_at >= date_trunc('month', CURRENT_TIMESTAMP)`
    );
    const used = await db.query(
        `SELECT COALESCE(SUM(shipping_subsidy), 0) AS total
         FROM tbl_checkout_groups
         WHERE status IN ('PENDING','PAID')
           AND created_at >= date_trunc('month', CURRENT_TIMESTAMP)`
    );
    const b2bRevenue = Number(rev.rows[0].total);
    const subsidyUsed = Number(used.rows[0].total);
    const budget = Math.max(SUBSIDY_BOOTSTRAP_BUDGET, SUBSIDY_CAP_PCT * b2bRevenue);
    return {
        b2b_revenue_month: b2bRevenue,
        subsidy_used_month: subsidyUsed,
        subsidy_budget_month: Math.round(budget),
        subsidy_remaining: Math.max(Math.round(budget - subsidyUsed), 0),
        free_shipping_enabled: subsidyUsed < budget
    };
}

async function pickZone(db, zoneId) {
    if (zoneId) {
        const r = await db.query(
            `SELECT * FROM tbl_delivery_zones WHERE id = $1 AND active = TRUE`,
            [zoneId]
        );
        if (!r.rowCount) throw new ShippingError('ZONE_NOT_FOUND', 'Zona antar tidak tersedia');
        return r.rows[0];
    }
    const r = await db.query(
        `SELECT * FROM tbl_delivery_zones WHERE active = TRUE ORDER BY id ASC LIMIT 1`
    );
    if (!r.rowCount) {
        throw new ShippingError('ZONE_NOT_CONFIGURED', 'Zona antar belum diatur oleh admin');
    }
    return r.rows[0];
}

async function quote(db, { fulfillmentType, zoneId = null, subtotal }) {
    const sub = Number(subtotal);
    if (fulfillmentType === 'PICKUP') {
        return {
            zone_id: null,
            courier_cost: 0,
            customer_fee: 0,
            subsidy: 0,
            free_shipping_applied: false,
            note: 'Ambil di pasar, tanpa ongkir'
        };
    }

    const zone = await pickZone(db, zoneId);
    if (sub < Number(zone.min_order)) {
        throw new ShippingError(
            'MIN_ORDER',
            `Minimal belanja untuk diantar Rp${Number(zone.min_order).toLocaleString('id-ID')}`,
            { min_order: Number(zone.min_order) }
        );
    }

    const courierCost = Number(zone.base_fee);
    const qualifies = zone.free_above !== null && sub >= Number(zone.free_above);
    let customerFee = courierCost;
    let subsidy = 0;
    let note = null;

    if (qualifies) {
        const status = await subsidyStatus(db);
        if (status.free_shipping_enabled && status.subsidy_remaining >= courierCost) {
            customerFee = 0;
            subsidy = courierCost;
            note = 'Gratis ongkir';
        } else {
            note = 'Kuota gratis ongkir bulan ini sudah habis';
        }
    } else if (zone.free_above !== null) {
        const gap = Number(zone.free_above) - sub;
        note = `Tambah belanja Rp${Math.ceil(gap).toLocaleString('id-ID')} untuk gratis ongkir`;
    }

    return {
        zone_id: zone.id,
        eta_minutes: zone.eta_minutes,
        courier_cost: courierCost,
        customer_fee: customerFee,
        subsidy,
        free_shipping_applied: subsidy > 0,
        note
    };
}

module.exports = { quote, subsidyStatus, ShippingError, SUBSIDY_CAP_PCT, SUBSIDY_BOOTSTRAP_BUDGET };
