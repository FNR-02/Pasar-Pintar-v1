'use strict';
const crypto = require('crypto');
function key() {
  const raw = String(process.env.INTEGRATION_ENCRYPTION_KEY || '').trim();
  if (!/^[a-f0-9]{64}$/i.test(raw)) throw new Error('INTEGRATION_ENCRYPTION_KEY harus 64 karakter hex (32 byte)');
  return Buffer.from(raw, 'hex');
}
function encrypt(value) {
  if (typeof value !== 'string' || !value.trim()) throw new Error('Secret wajib diisi');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const ciphertext = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return { ciphertext: ciphertext.toString('base64'), iv: iv.toString('base64'), authTag: cipher.getAuthTag().toString('base64') };
}
function decrypt(record) {
  const decipher = crypto.createDecipheriv('aes-256-gcm', key(), Buffer.from(record.secret_iv, 'base64'));
  decipher.setAuthTag(Buffer.from(record.secret_auth_tag, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(record.secret_ciphertext, 'base64')), decipher.final()]).toString('utf8');
}
module.exports = { encrypt, decrypt };
