'use strict';

/** Logika harga bertingkat kulakan bersama (murni, tanpa database). */

function normalizeTiers(raw) {
    if (!Array.isArray(raw) || raw.length === 0 || raw.length > 10) return null;
    const tiers = raw.map((t) => ({ min_qty: Number(t.min_qty), unit_price: Number(t.unit_price) }));
    if (tiers.some((t) => !(t.min_qty > 0) || !(t.unit_price > 0))) return null;
    tiers.sort((a, b) => a.min_qty - b.min_qty);
    for (let i = 1; i < tiers.length; i += 1) {
        if (tiers[i].unit_price > tiers[i - 1].unit_price) return null; // makin banyak, makin murah
    }
    return tiers;
}

/** Tier terbaik yang tercapai oleh total jumlah, atau null. */
function tierFor(tiers, total) {
    let best = null;
    for (const t of tiers) if (total >= Number(t.min_qty)) best = t;
    return best;
}

function nextTier(tiers, total) {
    return tiers.find((t) => total < Number(t.min_qty)) || null;
}

module.exports = { normalizeTiers, tierFor, nextTier };
