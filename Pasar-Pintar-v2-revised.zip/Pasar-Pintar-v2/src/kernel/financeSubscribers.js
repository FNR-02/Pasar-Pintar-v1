'use strict';
/**
 * Legacy automatic posting intentionally disabled.
 *
 * The old implementation wrote debit and credit in separate queries and
 * treated the full order value as platform revenue. That is not safe for a
 * multi-merchant marketplace. Finance V3 now uses balanced journal entries;
 * automatic posting must be re-enabled only after settlement, commission,
 * merchant payable, voucher/shipping subsidy, gateway fee and tax mappings
 * have been verified end-to-end.
 */
module.exports = {};
