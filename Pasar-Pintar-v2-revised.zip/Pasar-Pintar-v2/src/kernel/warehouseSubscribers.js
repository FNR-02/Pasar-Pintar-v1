const CommerceKernel = require('./EventKernel');
const pool = require('../config/db');
const StockService = require('../services/inventory/StockService');

/**
 * ORDER_PAID -> komit stok yang ditahan saat checkout.
 * Seluruh logika stok ada di StockService (idempoten). Jika event ini terlewat
 * (mis. server restart), StockService.reconcile() menyelesaikannya otomatis.
 */
CommerceKernel.on('ORDER_PAID', async (packet) => {
    const order = packet.payload || {};
    const orderId = order.orderId || order.id;

    if (!orderId) {
        console.error('[WAREHOUSE] Order ID tidak ditemukan');
        return;
    }

    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const summary = await StockService.commitOrder(client, orderId);
        await client.query('COMMIT');
        console.log(
            `[WAREHOUSE] Order ${orderId}: komit=${summary.committed} lewati=${summary.skipped}` +
            (summary.shortfalls.length ? ` KURANG=${JSON.stringify(summary.shortfalls)}` : '')
        );
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.error(`[WAREHOUSE ERROR] ${err.message}`);
    } finally {
        client.release();
    }
});
