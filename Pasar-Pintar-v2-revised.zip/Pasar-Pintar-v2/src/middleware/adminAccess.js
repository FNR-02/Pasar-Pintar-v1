'use strict';
const { verifyToken } = require('./auth');
function requireAdminPermission(pool, permission) {
  return [verifyToken, async (req, res, next) => {
    try {
      // Existing role 4 remains the unrestricted Super Admin.
      if (Number(req.user.role_id) === 4) return next();
      // Customer, merchant and courier roles must never gain admin access by a stray grant.
      const r = await pool.query(
        `SELECT 1
         FROM tbl_admin_user_permissions p
         JOIN tbl_users u ON u.id=p.user_id
         JOIN tbl_roles role ON role.id=u.role_id
         WHERE p.user_id=$1 AND p.permission_code=$2
           AND role.role_name IN ('FINANCE','IT_ADMIN','OPERATIONS_ADMIN')
         LIMIT 1`,
        [req.user.id, permission]
      );
      if (!r.rowCount) return res.status(403).json({ error: 'Akses ditolak', required_permission: permission });
      next();
    } catch (err) {
      console.error('[ADMIN PERMISSION]', err.message);
      res.status(500).json({ error: 'Terjadi kesalahan pada server' });
    }
  }];
}
module.exports = { requireAdminPermission };
