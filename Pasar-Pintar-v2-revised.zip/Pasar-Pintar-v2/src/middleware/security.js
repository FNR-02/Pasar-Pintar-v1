'use strict';

const crypto = require('crypto');

/** Header keamanan dasar (tanpa dependensi tambahan). */
function securityHeaders(req, res, next) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=()');
    res.setHeader(
        'Content-Security-Policy',
        "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; " +
        "img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'"
    );
    if (process.env.NODE_ENV === 'production') {
        res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
    }
    res.removeHeader('X-Powered-By');
    next();
}

function requestId(req, res, next) {
    req.id = req.headers['x-request-id'] || crypto.randomUUID();
    res.setHeader('X-Request-Id', req.id);
    next();
}

/**
 * Pembatas laju sederhana (jendela geser, di memori).
 * Catatan: per-proses. Jika dijalankan multi-instance, ganti dengan penyimpanan bersama (Redis).
 */
function createRateLimiter({ windowMs, max, keyFn, message }) {
    const hits = new Map();
    const timer = setInterval(() => {
        const cutoff = Date.now() - windowMs;
        for (const [key, list] of hits) {
            const fresh = list.filter((t) => t > cutoff);
            if (fresh.length) hits.set(key, fresh);
            else hits.delete(key);
        }
    }, Math.min(windowMs, 60 * 1000));
    timer.unref();

    return function rateLimiter(req, res, next) {
        const key = keyFn ? keyFn(req) : req.ip;
        const now = Date.now();
        const list = (hits.get(key) || []).filter((t) => t > now - windowMs);
        if (list.length >= max) {
            const retry = Math.ceil((list[0] + windowMs - now) / 1000);
            res.setHeader('Retry-After', String(Math.max(retry, 1)));
            return res.status(429).json({
                error: message || 'Terlalu banyak permintaan, coba lagi sebentar lagi'
            });
        }
        list.push(now);
        hits.set(key, list);
        next();
    };
}

function notFoundHandler(req, res, next) {
    if (req.path.startsWith('/api/')) {
        return res.status(404).json({ error: 'Endpoint tidak ditemukan' });
    }
    next();
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
    if (err && err.type === 'entity.parse.failed') {
        return res.status(400).json({ error: 'Format JSON tidak valid' });
    }
    if (err && err.type === 'entity.too.large') {
        return res.status(413).json({ error: 'Data terlalu besar' });
    }
    console.error(`[ERROR] ${req.id || '-'} ${req.method} ${req.originalUrl}:`, err && err.message);
    res.status(500).json({ error: 'Terjadi kesalahan pada server', request_id: req.id });
}

/** Validasi konfigurasi wajib saat start; gagal cepat dengan pesan jelas. */
function validateEnv() {
    const problems = [];
    const required = ['DB_USER', 'DB_HOST', 'DB_NAME', 'DB_PASSWORD', 'JWT_SECRET'];
    for (const key of required) {
        if (!process.env[key]) problems.push(`${key} belum diisi`);
    }
    if (process.env.JWT_SECRET && process.env.JWT_SECRET.length < 32) {
        problems.push('JWT_SECRET minimal 32 karakter (gunakan: openssl rand -hex 32)');
    }
    if (process.env.NODE_ENV === 'production') {
        if (!process.env.MIDTRANS_SERVER_KEY) problems.push('MIDTRANS_SERVER_KEY belum diisi');
        if (!process.env.EVOLUTION_WEBHOOK_SECRET) problems.push('EVOLUTION_WEBHOOK_SECRET belum diisi');
    }
    if (problems.length) {
        console.error('[KONFIGURASI] Server tidak dapat dijalankan:\n - ' + problems.join('\n - '));
        process.exit(1);
    }
}

module.exports = {
    securityHeaders,
    requestId,
    createRateLimiter,
    notFoundHandler,
    errorHandler,
    validateEnv
};
