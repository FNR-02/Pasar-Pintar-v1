-- ============================================================
-- Pasar Pintar V2 - migrasi tambahan (idempoten, aman dijalankan ulang)
-- JALANKAN DI SALINAN/STAGING DULU. Skema produksi tidak ada di repo
-- (enterprise_schema.sql tidak membuat tbl_orders_v2, tbl_event_store, dll),
-- jadi migrasi ini hanya MENAMBAH objek dan memeriksa tipe kolom lebih dulu.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1) Satuan & mode stok pada produk ------------------------------------------
ALTER TABLE tbl_products ADD COLUMN IF NOT EXISTS unit VARCHAR(20) NOT NULL DEFAULT 'pcs';
ALTER TABLE tbl_products ADD COLUMN IF NOT EXISTS unit_step NUMERIC(8,3) NOT NULL DEFAULT 1;
ALTER TABLE tbl_products ADD COLUMN IF NOT EXISTS allow_decimal BOOLEAN NOT NULL DEFAULT FALSE;
-- COUNTED = stok dihitung angka; TOGGLE = cukup "ada/habis" (cocok untuk sayur/ikan segar)
ALTER TABLE tbl_products ADD COLUMN IF NOT EXISTS stock_mode VARCHAR(10) NOT NULL DEFAULT 'COUNTED';
ALTER TABLE tbl_products ADD COLUMN IF NOT EXISTS is_available BOOLEAN NOT NULL DEFAULT TRUE;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'tbl_products_stock_mode_check') THEN
    ALTER TABLE tbl_products ADD CONSTRAINT tbl_products_stock_mode_check
      CHECK (stock_mode IN ('COUNTED','TOGGLE'));
  END IF;
END $$;

-- 2) Kuantitas desimal (kg, ons, ikat) ---------------------------------------
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN SELECT * FROM (VALUES
      ('tbl_inventory','quantity_on_hand'),
      ('tbl_inventory','min_stock_level'),
      ('tbl_inventory','max_stock_level'),
      ('tbl_order_items','quantity'),
      ('tbl_inventory_movements','quantity')
  ) AS t(tbl, col) LOOP
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = r.tbl
        AND column_name = r.col AND data_type IN ('integer','smallint','bigint')
    ) THEN
      EXECUTE format('ALTER TABLE %I ALTER COLUMN %I TYPE NUMERIC(12,3)', r.tbl, r.col);
    END IF;
  END LOOP;
END $$;

-- 3) Penahanan stok (reservasi) ----------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_stock_holds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL,
  product_id UUID NOT NULL REFERENCES tbl_products(id),
  quantity NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  status VARCHAR(12) NOT NULL DEFAULT 'HELD'
    CHECK (status IN ('HELD','COMMITTED','RELEASED')),
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  committed_at TIMESTAMPTZ,
  released_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_stock_holds_order_product ON tbl_stock_holds (order_id, product_id);
CREATE INDEX IF NOT EXISTS idx_stock_holds_status_exp ON tbl_stock_holds (status, expires_at);
CREATE INDEX IF NOT EXISTS idx_stock_holds_product ON tbl_stock_holds (product_id) WHERE status = 'HELD';

-- Satu sumber kebenaran ketersediaan: katalog, WhatsApp, POS, dan checkout
-- semuanya membaca view ini.
CREATE OR REPLACE VIEW v_product_availability AS
SELECT
  p.id AS product_id,
  p.merchant_id,
  p.stock_mode,
  p.is_available,
  COALESCE(inv.on_hand, 0) AS on_hand,
  COALESCE(h.held, 0) AS held,
  CASE
    WHEN p.is_available = FALSE THEN 0
    WHEN p.stock_mode = 'TOGGLE' THEN 999999
    ELSE GREATEST(COALESCE(inv.on_hand, 0) - COALESCE(h.held, 0), 0)
  END AS available
FROM tbl_products p
LEFT JOIN (
  SELECT product_id, SUM(quantity_on_hand) AS on_hand
  FROM tbl_inventory GROUP BY product_id
) inv ON inv.product_id = p.id
LEFT JOIN (
  SELECT product_id, SUM(quantity) AS held
  FROM tbl_stock_holds WHERE status = 'HELD' GROUP BY product_id
) h ON h.product_id = p.id;

-- 4) Checkout multi-lapak (satu keranjang, satu pembayaran) ---------------------
CREATE TABLE IF NOT EXISTS tbl_delivery_zones (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  base_fee NUMERIC(12,2) NOT NULL DEFAULT 0,
  free_above NUMERIC(12,2),
  min_order NUMERIC(12,2) NOT NULL DEFAULT 0,
  eta_minutes INT NOT NULL DEFAULT 60,
  active BOOLEAN NOT NULL DEFAULT TRUE
);
-- Nilai contoh. SESUAIKAN dengan biaya kurir nyata.
INSERT INTO tbl_delivery_zones (name, base_fee, free_above, min_order, eta_minutes)
VALUES ('Sekitar Pasar (contoh)', 8000, 100000, 20000, 60)
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS tbl_checkout_groups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'PENDING'
    CHECK (status IN ('PENDING','PAID','EXPIRED','CANCELLED')),
  fulfillment_type VARCHAR(20) NOT NULL DEFAULT 'DELIVERY',
  shipping_address TEXT,
  zone_id INT REFERENCES tbl_delivery_zones(id),
  subtotal NUMERIC(14,2) NOT NULL,
  shipping_fee NUMERIC(14,2) NOT NULL DEFAULT 0,      -- dibayar pembeli
  shipping_subsidy NUMERIC(14,2) NOT NULL DEFAULT 0,  -- ditanggung Pasar Pintar
  total_amount NUMERIC(14,2) NOT NULL,                -- subtotal + shipping_fee
  provider VARCHAR(20),
  payment_method VARCHAR(30),
  channel VARCHAR(30),
  external_transaction_id TEXT,
  payment_expires_at TIMESTAMPTZ,
  gateway_response JSONB,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_checkout_groups_customer ON tbl_checkout_groups (customer_id, created_at DESC);

CREATE TABLE IF NOT EXISTS tbl_checkout_group_orders (
  group_id UUID NOT NULL REFERENCES tbl_checkout_groups(id) ON DELETE CASCADE,
  order_id UUID NOT NULL,
  PRIMARY KEY (group_id, order_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_checkout_group_order ON tbl_checkout_group_orders (order_id);

ALTER TABLE tbl_orders_v2 ADD COLUMN IF NOT EXISTS channel VARCHAR(12) NOT NULL DEFAULT 'WEB';
ALTER TABLE tbl_orders_v2 ADD COLUMN IF NOT EXISTS checkout_group_id UUID;

-- 5) Pendapatan platform (jalur B2B) -------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_platform_revenue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source VARCHAR(20) NOT NULL
    CHECK (source IN ('B2B_REBATE','B2B_SPREAD','SERVICE_FEE','PROMO','OTHER')),
  ref_type VARCHAR(30),
  ref_id UUID,
  amount NUMERIC(14,2) NOT NULL,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_platform_revenue_created ON tbl_platform_revenue (created_at);

-- 6) Kulakan bersama (pembelian gabungan banyak lapak) -------------------------
CREATE TABLE IF NOT EXISTS tbl_group_buys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(200) NOT NULL,
  item_name VARCHAR(200) NOT NULL,
  unit VARCHAR(20) NOT NULL DEFAULT 'kg',
  principal_name VARCHAR(200),
  baseline_price NUMERIC(12,2) NOT NULL,          -- harga kulakan biasa (pembanding)
  tiers JSONB NOT NULL DEFAULT '[]'::jsonb,       -- [{"min_qty":50,"unit_price":9000}, ...]
  min_total_qty NUMERIC(12,3) NOT NULL DEFAULT 0,
  platform_share_per_unit NUMERIC(12,2) NOT NULL DEFAULT 0,
  status VARCHAR(12) NOT NULL DEFAULT 'OPEN'
    CHECK (status IN ('OPEN','CLOSED','FAILED','DELIVERED','CANCELLED')),
  closes_at TIMESTAMPTZ NOT NULL,
  final_unit_price NUMERIC(12,2),
  total_qty NUMERIC(12,3),
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tbl_group_buy_commitments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  group_buy_id UUID NOT NULL REFERENCES tbl_group_buys(id) ON DELETE CASCADE,
  merchant_id UUID NOT NULL REFERENCES tbl_merchants(id),
  quantity NUMERIC(12,3) NOT NULL CHECK (quantity > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (group_buy_id, merchant_id)
);

-- 7) POS kasir offline ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS tbl_pos_shifts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  merchant_id UUID NOT NULL REFERENCES tbl_merchants(id),
  opened_by UUID,
  opening_cash NUMERIC(14,2) NOT NULL DEFAULT 0,
  closing_cash NUMERIC(14,2),
  expected_cash NUMERIC(14,2),
  status VARCHAR(8) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','CLOSED')),
  opened_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  closed_at TIMESTAMPTZ
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_pos_shift_open_per_merchant
  ON tbl_pos_shifts (merchant_id) WHERE status = 'OPEN';

CREATE TABLE IF NOT EXISTS tbl_pos_sales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_sale_id UUID NOT NULL UNIQUE,           -- kunci idempotensi dari perangkat
  merchant_id UUID NOT NULL REFERENCES tbl_merchants(id),
  shift_id UUID REFERENCES tbl_pos_shifts(id),
  payment_method VARCHAR(12) NOT NULL CHECK (payment_method IN ('CASH','QRIS','TRANSFER')),
  total_amount NUMERIC(14,2) NOT NULL,
  cash_received NUMERIC(14,2),
  change_given NUMERIC(14,2),
  items JSONB NOT NULL,
  offline BOOLEAN NOT NULL DEFAULT FALSE,
  sold_at TIMESTAMPTZ NOT NULL,                  -- waktu transaksi di perangkat
  synced_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  price_mismatch BOOLEAN NOT NULL DEFAULT FALSE,
  voided_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_pos_sales_merchant_time ON tbl_pos_sales (merchant_id, sold_at DESC);

-- Penjualan fisik selalu menang: bila stok sistem kurang, penjualan tetap dicatat
-- dan selisihnya masuk daftar ini untuk dicek.
CREATE TABLE IF NOT EXISTS tbl_stock_discrepancies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID NOT NULL REFERENCES tbl_products(id),
  merchant_id UUID,
  source VARCHAR(20) NOT NULL,                   -- POS_SALE, ONLINE_COMMIT
  ref_id UUID,
  requested NUMERIC(12,3) NOT NULL,
  applied NUMERIC(12,3) NOT NULL,
  resolved BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_stock_disc_open ON tbl_stock_discrepancies (resolved, created_at DESC);

-- 8) Penjualan terpadu (online + kasir) untuk satu laporan --------------------------
CREATE OR REPLACE VIEW v_sales_unified AS
SELECT 'POS'::text AS channel, s.id, s.merchant_id, s.total_amount, s.sold_at AS sold_at
FROM tbl_pos_sales s WHERE s.voided_at IS NULL
UNION ALL
SELECT COALESCE(o.channel, 'WEB')::text, o.id, o.merchant_id, o.total_amount, o.created_at
FROM tbl_orders_v2 o
WHERE o.status IN ('PAID','PACKING','DISPATCHED','DELIVERED','CLOSED');

-- 9) Draf keranjang WhatsApp (daftar belanja lintas lapak) -----------------------
CREATE TABLE IF NOT EXISTS tbl_whatsapp_cart_drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL,
  status VARCHAR(24) NOT NULL DEFAULT 'PENDING_CONFIRMATION'
    CHECK (status IN ('PENDING_CONFIRMATION','CONFIRMED','CANCELLED','EXPIRED')),
  items JSONB NOT NULL,            -- [{product_id, name, unit, quantity, unit_price, store_name}]
  unmatched JSONB NOT NULL DEFAULT '[]'::jsonb,
  fulfillment_type VARCHAR(20) NOT NULL DEFAULT 'DELIVERY',
  shipping_address TEXT,
  subtotal NUMERIC(14,2) NOT NULL DEFAULT 0,
  source_text TEXT,
  group_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (CURRENT_TIMESTAMP + INTERVAL '30 minutes')
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_wa_cart_pending_per_customer
  ON tbl_whatsapp_cart_drafts (customer_id) WHERE status = 'PENDING_CONFIRMATION';
