-- =========================================================================
-- FASE 2: ENTERPRISE FOUNDATION - EPIC 2: ENTERPRISE DATA MODEL
-- =========================================================================

-- 1. DOM-001 & DOM-002: Identity & Authentication Domain
CREATE TABLE tbl_roles (
    id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_permissions (
    id SERIAL PRIMARY KEY,
    permission_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
);

CREATE TABLE tbl_role_permissions (
    role_id INT REFERENCES tbl_roles(id) ON DELETE CASCADE,
    permission_id INT REFERENCES tbl_permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE tbl_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role_id INT REFERENCES tbl_roles(id),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. DOM-003, DOM-004, DOM-005: Merchant, Product, & Inventory Domain
CREATE TABLE tbl_merchants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES tbl_users(id),
    store_name VARCHAR(150) NOT NULL,
    address TEXT,
    status VARCHAR(30) DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_product_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    parent_id INT REFERENCES tbl_product_categories(id)
);

CREATE TABLE tbl_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    merchant_id UUID REFERENCES tbl_merchants(id),
    category_id INT REFERENCES tbl_product_categories(id),
    sku VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_product_prices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES tbl_products(id) ON DELETE CASCADE,
    price_type VARCHAR(30) DEFAULT 'RETAIL', -- RETAIL, WHOLESOME, TIER_1
    amount NUMERIC(12, 2) NOT NULL,
    effective_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_warehouses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_name VARCHAR(150) NOT NULL,
    location TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_inventory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_id UUID REFERENCES tbl_warehouses(id),
    product_id UUID REFERENCES tbl_products(id),
    quantity_on_hand INT DEFAULT 0,
    min_stock_level INT DEFAULT 5,
    max_stock_level INT DEFAULT 100,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_inventory_movements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id UUID REFERENCES tbl_products(id),
    warehouse_id UUID REFERENCES tbl_warehouses(id),
    movement_type VARCHAR(30) NOT NULL, -- IN, OUT, TRANSFER, ADJUSTMENT
    quantity INT NOT NULL,
    reference_doc VARCHAR(100),
    created_by UUID REFERENCES tbl_users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. DOM-007 & DOM-008: Supplier & Purchase Domain
CREATE TABLE tbl_suppliers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    supplier_name VARCHAR(150) NOT NULL,
    contact_person VARCHAR(100),
    phone VARCHAR(30),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_purchase_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    supplier_id UUID REFERENCES tbl_suppliers(id),
    warehouse_id UUID REFERENCES tbl_warehouses(id),
    status VARCHAR(30) DEFAULT 'DRAFT', -- DRAFT, APPROVED, COMPLETED, CANCELLED
    total_amount NUMERIC(14, 2) DEFAULT 0.00,
    created_by UUID REFERENCES tbl_users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_purchase_order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    purchase_order_id UUID REFERENCES tbl_purchase_orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES tbl_products(id),
    quantity INT NOT NULL,
    unit_cost NUMERIC(12, 2) NOT NULL
);

-- 4. DOM-009, DOM-010, DOM-011: Sales, Customer, & CRM Domain
CREATE TABLE tbl_customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES tbl_users(id),
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(30),
    phone_verified_at TIMESTAMP WITH TIME ZONE,
    tier_status VARCHAR(30) DEFAULT 'STANDARD', -- STANDARD, SILVER, GOLD, PLATINUM
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX uq_tbl_customers_phone_nonempty
ON tbl_customers (phone)
WHERE phone IS NOT NULL
  AND BTRIM(phone) <> '';


CREATE TABLE tbl_phone_verification_challenges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID NOT NULL UNIQUE
        REFERENCES tbl_customers(id) ON DELETE CASCADE,
    phone VARCHAR(30) NOT NULL,
    code_hash TEXT NOT NULL,
    attempts INT NOT NULL DEFAULT 0,
    requested_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    consumed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_phone_verification_expires_at
ON tbl_phone_verification_challenges (expires_at);


CREATE TABLE tbl_loyalty_points (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES tbl_customers(id) ON DELETE CASCADE,
    points INT DEFAULT 0,
    transaction_type VARCHAR(30), -- EARNED, REDEEMED
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    customer_id UUID REFERENCES tbl_customers(id),
    merchant_id UUID REFERENCES tbl_merchants(id),
    status VARCHAR(30) DEFAULT 'PENDING', -- PENDING, PAID, PROCESSING, SHIPPED, COMPLETED, CANCELLED
    shipping_address TEXT,
    total_amount NUMERIC(14, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES tbl_orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES tbl_products(id),
    quantity INT NOT NULL,
    unit_price NUMERIC(12, 2) NOT NULL
);

-- 5. DOM-012: Finance Domain
CREATE TABLE tbl_payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES tbl_orders(id),
    payment_method VARCHAR(50) NOT NULL, -- QRIS, BANK_TRANSFER, COD, WALLET
    payment_status VARCHAR(30) DEFAULT 'UNPAID', -- UNPAID, PAID, FAILED, REFUNDED
    amount NUMERIC(14, 2) NOT NULL,
    gateway_response JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. DOM-013: Courier & Logistics Domain
CREATE TABLE tbl_shipments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES tbl_orders(id),
    courier_id UUID REFERENCES tbl_users(id),
    tracking_number VARCHAR(100) UNIQUE,
    shipping_status VARCHAR(30) DEFAULT 'ASSIGNED', -- ASSIGNED, PICKED_UP, ON_THE_WAY, DELIVERED
    notes TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. DOM-014: AI Engine Domain
CREATE TABLE tbl_ai_predictions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_type VARCHAR(50), -- PRODUCT, INVENTORY, SALES_FORECAST
    entity_id UUID,
    prediction_data JSONB,
    confidence_score NUMERIC(5, 2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 8. DOM-015: Reporting, Audit, & Events (Kernel Core)
CREATE TABLE tbl_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type VARCHAR(100),
    actor_id UUID,
    ip_address VARCHAR(45),
    payload JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_name VARCHAR(100) NOT NULL,
    aggregate_id UUID,
    payload JSONB,
    processed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES tbl_users(id),
    title VARCHAR(150),
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- WhatsApp Customer Order Drafts
-- Draft sementara sebelum Customer melakukan konfirmasi eksplisit.
-- Tidak merepresentasikan order nyata.
-- ============================================================

CREATE TABLE IF NOT EXISTS tbl_whatsapp_order_drafts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    customer_id UUID NOT NULL
        REFERENCES tbl_customers(id)
        ON DELETE CASCADE,

    product_id UUID NOT NULL
        REFERENCES tbl_products(id),

    quantity INTEGER NOT NULL
        CHECK (quantity > 0 AND quantity <= 100),

    unit_price NUMERIC(14,2) NOT NULL
        CHECK (unit_price >= 0),

    subtotal NUMERIC(14,2) NOT NULL
        CHECK (subtotal >= 0),

    available_stock_snapshot INTEGER NOT NULL
        CHECK (available_stock_snapshot >= 0),

    source_message_id VARCHAR(128) NOT NULL,

    status VARCHAR(32) NOT NULL
        DEFAULT 'PENDING_CONFIRMATION'
        CHECK (
            status IN (
                'PENDING_CONFIRMATION',
                'CONFIRMED',
                'CANCELLED',
                'EXPIRED'
            )
        ),

    created_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    expires_at TIMESTAMPTZ NOT NULL
        DEFAULT (CURRENT_TIMESTAMP + INTERVAL '15 minutes'),

    confirmed_at TIMESTAMPTZ,

    cancelled_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS
uq_whatsapp_order_drafts_source_message
ON tbl_whatsapp_order_drafts(source_message_id);

CREATE UNIQUE INDEX IF NOT EXISTS
uq_whatsapp_order_drafts_one_pending_per_customer
ON tbl_whatsapp_order_drafts(customer_id)
WHERE status = 'PENDING_CONFIRMATION';

CREATE INDEX IF NOT EXISTS
idx_whatsapp_order_drafts_customer_created
ON tbl_whatsapp_order_drafts(customer_id, created_at DESC);

CREATE INDEX IF NOT EXISTS
idx_whatsapp_order_drafts_expires
ON tbl_whatsapp_order_drafts(expires_at)
WHERE status = 'PENDING_CONFIRMATION';

-- Link WhatsApp draft ke order hasil konfirmasi.
ALTER TABLE tbl_whatsapp_order_drafts
ADD COLUMN IF NOT EXISTS confirmed_order_id UUID;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'tbl_whatsapp_order_drafts_confirmed_order_id_fkey'
    ) THEN
        ALTER TABLE tbl_whatsapp_order_drafts
        ADD CONSTRAINT tbl_whatsapp_order_drafts_confirmed_order_id_fkey
        FOREIGN KEY (confirmed_order_id)
        REFERENCES tbl_orders_v2(id);
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS
uq_whatsapp_order_drafts_confirmed_order
ON tbl_whatsapp_order_drafts(confirmed_order_id)
WHERE confirmed_order_id IS NOT NULL;

-- ============================================================
-- WhatsApp Notification Delivery Ledger
-- Idempotency + delivery state untuk subscriber event WhatsApp.
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_whatsapp_notification_deliveries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_key VARCHAR(180) NOT NULL,
    notification_type VARCHAR(64) NOT NULL,
    order_id UUID
        REFERENCES tbl_orders_v2(id)
        ON DELETE CASCADE,
    customer_id UUID
        REFERENCES tbl_customers(id)
        ON DELETE CASCADE,
    phone VARCHAR(32),
    status VARCHAR(24) NOT NULL
        DEFAULT 'PENDING'
        CHECK (
            status IN (
                'PENDING',
                'SENT',
                'FAILED'
            )
        ),
    outbound_message_id VARCHAR(180),
    attempts INTEGER NOT NULL
        DEFAULT 1
        CHECK (attempts >= 1),
    last_error TEXT,
    created_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,
    sent_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS
uq_whatsapp_notification_delivery_event
ON tbl_whatsapp_notification_deliveries(event_key);

CREATE INDEX IF NOT EXISTS
idx_whatsapp_notification_delivery_order
ON tbl_whatsapp_notification_deliveries(order_id);

CREATE INDEX IF NOT EXISTS
idx_whatsapp_notification_delivery_status
ON tbl_whatsapp_notification_deliveries(status, updated_at);

-- ============================================================
-- Event Store Timestamp Contract
-- EventKernel mengirim ISO-8601 UTC melalui Date#toISOString().
-- Nilai historis timestamp tanpa timezone ditafsirkan sebagai UTC.
-- ============================================================
ALTER TABLE tbl_event_store
ALTER COLUMN created_at
TYPE TIMESTAMPTZ
USING created_at AT TIME ZONE 'UTC';

ALTER TABLE tbl_event_store
ALTER COLUMN created_at
SET DEFAULT CURRENT_TIMESTAMP;

-- ============================================================
-- WhatsApp Inbound Message Ledger
-- Boundary idempotency untuk webhook Evolution.
-- Satu WhatsApp message_id hanya boleh diproses satu kali.
-- FAILED / PROCESSING stale dapat diklaim ulang secara aman.
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_whatsapp_inbound_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    message_id VARCHAR(180) NOT NULL,

    phone VARCHAR(32),

    status VARCHAR(24) NOT NULL
        DEFAULT 'PROCESSING'
        CHECK (
            status IN (
                'PROCESSING',
                'PROCESSED',
                'FAILED'
            )
        ),

    attempts INTEGER NOT NULL
        DEFAULT 1
        CHECK (attempts >= 1),

    last_error TEXT,

    created_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    processed_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS
uq_whatsapp_inbound_message_id
ON tbl_whatsapp_inbound_messages(message_id);

CREATE INDEX IF NOT EXISTS
idx_whatsapp_inbound_status_updated
ON tbl_whatsapp_inbound_messages(status, updated_at);

-- ============================================================
-- WhatsApp Notification Immutable Payload
-- AUTO_REPLY menyimpan final responseText yang benar-benar
-- hendak dikirim. Retry delivery tidak menjalankan ulang
-- orchestrator dan tidak merekonstruksi response dari event.
-- ============================================================
ALTER TABLE tbl_whatsapp_notification_deliveries
ADD COLUMN IF NOT EXISTS payload_text TEXT;

-- ============================================================
-- Background Worker Heartbeats
-- Operational observability tanpa mengekspos payload pelanggan.
-- ============================================================
CREATE TABLE IF NOT EXISTS tbl_worker_heartbeats (
    worker_name VARCHAR(100) PRIMARY KEY,
    status VARCHAR(24) NOT NULL
        CHECK (
            status IN (
                'RUNNING',
                'HEALTHY',
                'DEGRADED'
            )
        ),
    last_started_at TIMESTAMPTZ,
    last_completed_at TIMESTAMPTZ,
    last_duration_ms INTEGER,
    last_candidates INTEGER NOT NULL DEFAULT 0,
    last_processed INTEGER NOT NULL DEFAULT 0,
    last_sent INTEGER NOT NULL DEFAULT 0,
    last_failed INTEGER NOT NULL DEFAULT 0,
    last_skipped INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    updated_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- WhatsApp Durable Inbound Payload
-- Payload pertama disimpan immutable untuk kebutuhan recovery.
-- Retry tidak boleh menimpa payload_json, event_name, sender_jid.
-- ============================================================
ALTER TABLE tbl_whatsapp_inbound_messages
ADD COLUMN IF NOT EXISTS payload_json JSONB;

ALTER TABLE tbl_whatsapp_inbound_messages
ADD COLUMN IF NOT EXISTS event_name VARCHAR(64);

ALTER TABLE tbl_whatsapp_inbound_messages
ADD COLUMN IF NOT EXISTS sender_jid TEXT;

-- ============================================================
-- WhatsApp Order Draft Shipping Address
-- Snapshot alamat sebelum canonical order dibuat.
-- ============================================================
ALTER TABLE tbl_whatsapp_order_drafts
ADD COLUMN IF NOT EXISTS shipping_address TEXT;

-- ============================================================
-- Order Fulfillment Domain
--
-- DELIVERY:
--   barang dikirim ke shipping_address.
--
-- PICKUP:
--   pelanggan mengambil sendiri di merchant/outlet.
--   pickup_location_snapshot menyimpan lokasi pada saat order
--   agar histori tidak berubah jika alamat merchant berubah.
-- ============================================================

ALTER TABLE tbl_orders_v2
ADD COLUMN IF NOT EXISTS
    fulfillment_type VARCHAR(20);

UPDATE tbl_orders_v2
SET fulfillment_type = 'DELIVERY'
WHERE fulfillment_type IS NULL;

ALTER TABLE tbl_orders_v2
ALTER COLUMN fulfillment_type
SET DEFAULT 'DELIVERY';

ALTER TABLE tbl_orders_v2
ALTER COLUMN fulfillment_type
SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_orders_v2_fulfillment_type_check'
    ) THEN
        ALTER TABLE tbl_orders_v2
        ADD CONSTRAINT
            tbl_orders_v2_fulfillment_type_check
        CHECK (
            fulfillment_type IN (
                'DELIVERY',
                'PICKUP'
            )
        );
    END IF;
END
$$;

ALTER TABLE tbl_orders_v2
ADD COLUMN IF NOT EXISTS
    pickup_location_snapshot TEXT;

-- ============================================================
-- Tempo Engine V1
-- ============================================================

CREATE TABLE IF NOT EXISTS tbl_credit_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_type VARCHAR(30) NOT NULL,
    customer_id UUID NULL
        REFERENCES tbl_customers(id),
    merchant_id UUID NOT NULL
        REFERENCES tbl_merchants(id),
    supplier_id UUID NULL
        REFERENCES tbl_suppliers(id),
    credit_limit NUMERIC(18,2) NOT NULL DEFAULT 0,
    default_term_days INTEGER NOT NULL DEFAULT 0,
    same_day_due_time TIME NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    notes TEXT NULL,
    approved_by UUID NULL
        REFERENCES tbl_users(id),
    approved_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT tbl_credit_accounts_type_check
        CHECK (
            account_type IN (
                'CUSTOMER',
                'SUPPLIER'
            )
        ),

    CONSTRAINT tbl_credit_accounts_status_check
        CHECK (
            status IN (
                'ACTIVE',
                'SUSPENDED',
                'CLOSED'
            )
        ),

    CONSTRAINT tbl_credit_accounts_limit_check
        CHECK (credit_limit >= 0),

    CONSTRAINT tbl_credit_accounts_term_check
        CHECK (
            default_term_days >= 0
            AND default_term_days <= 365
        ),

    CONSTRAINT tbl_credit_accounts_party_check
        CHECK (
            (
                account_type='CUSTOMER'
                AND customer_id IS NOT NULL
                AND supplier_id IS NULL
            )
            OR
            (
                account_type='SUPPLIER'
                AND supplier_id IS NOT NULL
                AND customer_id IS NULL
            )
        )
);

CREATE UNIQUE INDEX IF NOT EXISTS
    uq_credit_account_customer_merchant
ON tbl_credit_accounts (
    customer_id,
    merchant_id
)
WHERE account_type='CUSTOMER';

CREATE UNIQUE INDEX IF NOT EXISTS
    uq_credit_account_supplier_merchant
ON tbl_credit_accounts (
    supplier_id,
    merchant_id
)
WHERE account_type='SUPPLIER';

CREATE INDEX IF NOT EXISTS
    idx_credit_accounts_merchant_status
ON tbl_credit_accounts (
    merchant_id,
    status
);


CREATE TABLE IF NOT EXISTS tbl_credit_obligations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    credit_account_id UUID NOT NULL
        REFERENCES tbl_credit_accounts(id),

    source_type VARCHAR(30) NOT NULL,

    source_id UUID NOT NULL,

    principal_amount NUMERIC(18,2) NOT NULL,

    paid_amount NUMERIC(18,2) NOT NULL DEFAULT 0,

    due_at TIMESTAMPTZ NOT NULL,

    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',

    description TEXT NULL,

    opened_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    paid_at TIMESTAMPTZ NULL,

    created_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT tbl_credit_obligations_source_check
        CHECK (
            source_type IN (
                'ORDER',
                'PURCHASE_ORDER'
            )
        ),

    CONSTRAINT tbl_credit_obligations_status_check
        CHECK (
            status IN (
                'OPEN',
                'PARTIAL',
                'PAID',
                'OVERDUE',
                'CANCELLED'
            )
        ),

    CONSTRAINT tbl_credit_obligations_amount_check
        CHECK (
            principal_amount > 0
            AND paid_amount >= 0
            AND paid_amount <= principal_amount
        )
);

CREATE UNIQUE INDEX IF NOT EXISTS
    uq_credit_obligation_source
ON tbl_credit_obligations (
    source_type,
    source_id
);

CREATE INDEX IF NOT EXISTS
    idx_credit_obligations_account_status
ON tbl_credit_obligations (
    credit_account_id,
    status
);

CREATE INDEX IF NOT EXISTS
    idx_credit_obligations_due
ON tbl_credit_obligations (
    due_at
)
WHERE status IN (
    'OPEN',
    'PARTIAL',
    'OVERDUE'
);


CREATE TABLE IF NOT EXISTS tbl_credit_settlements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    obligation_id UUID NOT NULL
        REFERENCES tbl_credit_obligations(id),

    amount NUMERIC(18,2) NOT NULL,

    payment_method VARCHAR(30) NOT NULL,

    reference_number VARCHAR(150) NULL,

    notes TEXT NULL,

    received_by UUID NULL
        REFERENCES tbl_users(id),

    settled_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    created_at TIMESTAMPTZ NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT tbl_credit_settlements_amount_check
        CHECK (amount > 0),

    CONSTRAINT tbl_credit_settlements_method_check
        CHECK (
            payment_method IN (
                'CASH',
                'BANK_TRANSFER',
                'QRIS',
                'OTHER'
            )
        )
);

CREATE INDEX IF NOT EXISTS
    idx_credit_settlements_obligation
ON tbl_credit_settlements (
    obligation_id,
    settled_at
);


-- ============================================================
-- Purchase Order Merchant Ownership V1
--
-- Merchant adalah pemilik bisnis Purchase Order.
-- Warehouse hanya lokasi penyimpanan / receiving.
--
-- Historis dapat ditentukan melalui:
-- Purchase Order -> Item -> Product -> Merchant.
-- ============================================================

ALTER TABLE tbl_purchase_orders
ADD COLUMN IF NOT EXISTS
    merchant_id UUID;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_purchase_orders_merchant_id_fkey'
    ) THEN
        ALTER TABLE tbl_purchase_orders
        ADD CONSTRAINT
            tbl_purchase_orders_merchant_id_fkey
        FOREIGN KEY (merchant_id)
        REFERENCES tbl_merchants(id);
    END IF;
END
$$;

CREATE INDEX IF NOT EXISTS
    idx_purchase_orders_merchant_status
ON tbl_purchase_orders (
    merchant_id,
    status,
    created_at DESC
);


-- ============================================================
-- Purchase Order Merchant Ownership V1 — Final Lock
--
-- Semua writer Purchase Order wajib mengisi merchant_id.
-- Warehouse bukan pemilik PO.
-- ============================================================

ALTER TABLE tbl_purchase_orders
ALTER COLUMN merchant_id
SET NOT NULL;


-- ============================================================
-- Purchase Order Payment Mode V1
--
-- CASH:
--   pembayaran supplier tidak menggunakan Tempo Engine.
--
-- TEMPO:
--   PO terikat pada SUPPLIER credit account dan mempunyai
--   due date snapshot sendiri.
--
-- Historical PO diklasifikasikan CASH.
-- ============================================================

ALTER TABLE tbl_purchase_orders
ADD COLUMN IF NOT EXISTS
    payment_mode VARCHAR(20);

ALTER TABLE tbl_purchase_orders
ADD COLUMN IF NOT EXISTS
    credit_account_id UUID;

ALTER TABLE tbl_purchase_orders
ADD COLUMN IF NOT EXISTS
    tempo_due_at TIMESTAMPTZ;

UPDATE tbl_purchase_orders
SET payment_mode = 'CASH'
WHERE payment_mode IS NULL;

ALTER TABLE tbl_purchase_orders
ALTER COLUMN payment_mode
SET DEFAULT 'CASH';

ALTER TABLE tbl_purchase_orders
ALTER COLUMN payment_mode
SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_purchase_orders_payment_mode_check'
    ) THEN
        ALTER TABLE tbl_purchase_orders
        ADD CONSTRAINT
            tbl_purchase_orders_payment_mode_check
        CHECK (
            payment_mode IN (
                'CASH',
                'TEMPO'
            )
        );
    END IF;
END
$$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_purchase_orders_credit_account_id_fkey'
    ) THEN
        ALTER TABLE tbl_purchase_orders
        ADD CONSTRAINT
            tbl_purchase_orders_credit_account_id_fkey
        FOREIGN KEY (credit_account_id)
        REFERENCES tbl_credit_accounts(id);
    END IF;
END
$$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_purchase_orders_payment_contract_check'
    ) THEN
        ALTER TABLE tbl_purchase_orders
        ADD CONSTRAINT
            tbl_purchase_orders_payment_contract_check
        CHECK (
            (
                payment_mode = 'CASH'
                AND credit_account_id IS NULL
                AND tempo_due_at IS NULL
            )
            OR
            (
                payment_mode = 'TEMPO'
                AND credit_account_id IS NOT NULL
                AND tempo_due_at IS NOT NULL
            )
        );
    END IF;
END
$$;

CREATE INDEX IF NOT EXISTS
    idx_purchase_orders_credit_account
ON tbl_purchase_orders (
    credit_account_id,
    status,
    tempo_due_at
)
WHERE credit_account_id IS NOT NULL;



-- ============================================================
-- Credit Settlement Idempotency V1
--
-- Satu obligation + idempotency key hanya boleh menghasilkan
-- satu settlement.
-- ============================================================

ALTER TABLE tbl_credit_settlements
ADD COLUMN IF NOT EXISTS
    idempotency_key VARCHAR(120);

CREATE UNIQUE INDEX IF NOT EXISTS
    uq_credit_settlement_obligation_idempotency
ON tbl_credit_settlements (
    obligation_id,
    idempotency_key
)
WHERE idempotency_key IS NOT NULL;


-- ============================================================
-- CUSTOMER TEMPO ORDER FOUNDATION V1
--
-- DIRECT = pembayaran langsung.
-- TEMPO  = fasilitas kredit Customer -> Merchant.
--
-- TEMPO bukan PAYMENT PAID dan tidak menerbitkan ORDER_PAID.
-- ============================================================

ALTER TABLE tbl_orders_v2
ADD COLUMN IF NOT EXISTS
    payment_mode VARCHAR(20);

ALTER TABLE tbl_orders_v2
ADD COLUMN IF NOT EXISTS
    credit_account_id UUID;

ALTER TABLE tbl_orders_v2
ADD COLUMN IF NOT EXISTS
    tempo_due_at TIMESTAMPTZ;

UPDATE tbl_orders_v2
SET payment_mode = 'DIRECT'
WHERE payment_mode IS NULL;

ALTER TABLE tbl_orders_v2
ALTER COLUMN payment_mode
SET DEFAULT 'DIRECT';

ALTER TABLE tbl_orders_v2
ALTER COLUMN payment_mode
SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_orders_v2_payment_mode_check'
    ) THEN
        ALTER TABLE tbl_orders_v2
        ADD CONSTRAINT
            tbl_orders_v2_payment_mode_check
        CHECK (
            payment_mode IN (
                'DIRECT',
                'TEMPO'
            )
        );
    END IF;
END
$$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_orders_v2_credit_account_id_fkey'
    ) THEN
        ALTER TABLE tbl_orders_v2
        ADD CONSTRAINT
            tbl_orders_v2_credit_account_id_fkey
        FOREIGN KEY (credit_account_id)
        REFERENCES tbl_credit_accounts(id);
    END IF;
END
$$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname =
            'tbl_orders_v2_payment_contract_check'
    ) THEN
        ALTER TABLE tbl_orders_v2
        ADD CONSTRAINT
            tbl_orders_v2_payment_contract_check
        CHECK (
            (
                payment_mode = 'DIRECT'
                AND credit_account_id IS NULL
                AND tempo_due_at IS NULL
            )
            OR
            (
                payment_mode = 'TEMPO'
                AND credit_account_id IS NOT NULL
                AND tempo_due_at IS NOT NULL
            )
        );
    END IF;
END
$$;

CREATE INDEX IF NOT EXISTS
    idx_orders_v2_credit_account
ON tbl_orders_v2 (
    credit_account_id,
    status,
    created_at DESC
)
WHERE credit_account_id IS NOT NULL;

