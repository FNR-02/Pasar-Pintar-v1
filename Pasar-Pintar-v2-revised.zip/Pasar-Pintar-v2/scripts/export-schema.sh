#!/usr/bin/env bash
# Ekspor skema database produksi/staging yang SEBENARNYA ke schema_snapshot.sql.
# Alasan: enterprise_schema.sql di repo tidak membuat tbl_orders_v2, tbl_event_store, dll.,
# sehingga database baru tidak bisa dibangun dari repo. Simpan hasil ekspor ini di git.
set -euo pipefail
: "${DATABASE_URL:?Isi DATABASE_URL, mis. postgres://user:pass@host:5432/dbname}"
pg_dump --schema-only --no-owner --no-privileges "$DATABASE_URL" > schema_snapshot.sql
echo "Tersimpan: schema_snapshot.sql ($(wc -l < schema_snapshot.sql) baris)"
