'use strict';
// Memeriksa sintaks seluruh file .js (src, scripts, server.js, public/*.html inline) tanpa menjalankan apa pun.
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

function walk(dir, out = []) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
        const full = path.join(dir, e.name);
        if (e.isDirectory()) walk(full, out);
        else if (e.name.endsWith('.js')) out.push(full);
    }
    return out;
}
let bad = 0;
const files = [...walk('src'), ...walk('scripts'), 'server.js'];
for (const f of files) {
    try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
    catch (e) { bad += 1; console.error('GAGAL', f, String(e.stderr).split('\n')[0]); }
}
for (const f of fs.readdirSync('public').filter((n) => n.endsWith('.html'))) {
    const html = fs.readFileSync(path.join('public', f), 'utf8');
    const blocks = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
    blocks.forEach((code, i) => {
        const tmp = path.join(os.tmpdir(), `chk-${f}-${i}.js`);
        fs.writeFileSync(tmp, code);
        try { execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' }); }
        catch (e) { bad += 1; console.error('GAGAL inline', f, `blok ${i}`); }
    });
}
console.log(bad ? `${bad} file bermasalah` : `Semua sintaks OK (${files.length} file js + HTML inline)`);
process.exit(bad ? 1 : 0);
