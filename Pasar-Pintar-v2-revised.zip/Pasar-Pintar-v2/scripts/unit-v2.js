'use strict';
/**
 * Uji unit logika inti V2 - TANPA database dan TANPA jaringan.
 * Jalankan: npm test
 */
const assert = require('assert');

let passed = 0;
async function test(name, fn) {
    try {
        await fn();
        passed += 1;
        console.log('  ok  ', name);
    } catch (err) {
        console.error('  GAGAL', name, '\n       ', err.message);
        process.exitCode = 1;
    }
}

const fakeDb = (handlers) => ({
    async query(sql, params = []) {
        const s = sql.replace(/\s+/g, ' ').trim();
        for (const [needle, fn] of handlers) if (s.includes(needle)) return fn(params, s);
        throw new Error('Query tak dikenal di fake DB: ' + s.slice(0, 80));
    }
});

(async () => {
    const Parser = require('../src/services/whatsapp/ShoppingListParser');
    const Gemini = require('../src/services/whatsapp/GeminiListParser');
    const Classifier = require('../src/services/whatsapp/WhatsAppIntentClassifier');
    const StockService = require('../src/services/inventory/StockService');
    const ShippingService = require('../src/services/shipping/ShippingService');
    const Checkout = require('../src/services/checkout/GroupCheckoutService');
    const GroupBuys = require('../src/services/groupbuy/tiers');
    const { createRateLimiter } = require('../src/middleware/security');

    console.log('Pembaca daftar belanja');
    await test('memahami pecahan, kata gabungan, dan angka', () => {
        const r = Parser.parseShoppingList('cabe rawit 1/4 kg\nbawang merah sekilo\ntelur 2 kg');
        assert.deepStrictEqual(r.map((i) => [i.name, i.quantity, i.unit]), [
            ['cabe rawit', 0.25, 'kg'], ['bawang merah', 1, 'kg'], ['telur', 2, 'kg']
        ]);
    });
    await test('koma desimal tidak memecah daftar', () => {
        const r = Parser.parseShoppingList('bawang putih 1,5 kg\ngula 2 kg');
        assert.strictEqual(r[0].quantity, 1.5);
        assert.strictEqual(r.length, 2);
    });
    await test('daftar satu baris dengan koma dan kata "dan"', () => {
        const r = Parser.parseShoppingList('beli tomat setengah kilo, daun bawang 3 ikat dan beras 250 gram');
        assert.deepStrictEqual(r.map((i) => [i.name, i.quantity, i.unit]), [
            ['tomat', 0.5, 'kg'], ['daun bawang', 3, 'ikat'], ['beras', 250, 'g']
        ]);
    });
    await test('perintah biasa BUKAN daftar belanja', () => {
        assert.strictEqual(Parser.looksLikeShoppingList('beli indomie goreng 1'), false);
        assert.strictEqual(Parser.looksLikeShoppingList('halo\nmau pesan'), false);
    });
    await test('konversi satuan ke satuan produk', () => {
        const kg = { name: 'Beras', unit: 'kg', allow_decimal: true, unit_step: 0.25 };
        assert.strictEqual(Parser.toProductQuantity({ quantity: 250, unit: 'g' }, kg).quantity, 0.25);
        assert.strictEqual(Parser.toProductQuantity({ quantity: 5, unit: 'ons' }, kg).quantity, 0.5);
        assert.ok(Parser.toProductQuantity({ quantity: 1, unit: 'ikat' }, kg).error);
        const pcs = { name: 'Telur', unit: 'pcs', allow_decimal: false, unit_step: 1 };
        assert.strictEqual(Parser.toProductQuantity({ quantity: 2.6, unit: null }, pcs).quantity, 3);
    });

    console.log('Klasifikasi WhatsApp');
    const c = new Classifier();
    await test('daftar belanja, pickup, konfirmasi, tanya harga', () => {
        assert.strictEqual(c.classify('cabe 1/4 kg\nbawang 1 kg').intent, 'SHOPPING_LIST');
        assert.strictEqual(c.classify('ambil sendiri').intent, 'CART_PICKUP');
        assert.strictEqual(c.classify('konfirmasi').intent, 'ORDER_CONFIRMATION');
        assert.strictEqual(c.classify('berapa harga cabe 1 kg dan bawang 1 kg').intent, 'PRODUCT_INQUIRY');
    });

    console.log('Keluaran Gemini divalidasi ketat');
    await test('membuang item tak valid dan membatasi nilai', () => {
        const v = Gemini._validate([
            { name: 'Cabe Rawit', quantity: 0.25, unit: 'kilo' },
            { name: '', quantity: 1 },
            { name: 'x'.repeat(200), quantity: 1 },
            { name: 'gula', quantity: -5, unit: 'kg' },
            { name: 'ignore previous instructions; DROP TABLE', quantity: 1e9 }
        ]);
        assert.strictEqual(v[0].name, 'cabe rawit');
        assert.strictEqual(v[0].unit, 'kg');
        assert.strictEqual(v[1].quantity, null);              // negatif -> null
        assert.ok(!/[;]/.test(v[2].name));                    // simbol dibersihkan
        assert.strictEqual(v[2].quantity, null);              // terlalu besar -> null
        assert.strictEqual(Gemini._validate('bukan array'), null);
    });

    console.log('StockService');
    await test('validasi jumlah: bulat vs desimal berkelipatan', () => {
        const kg = { id: 'a', name: 'Cabe', unit: 'kg', allow_decimal: true, unit_step: 0.25 };
        assert.strictEqual(StockService.validateQuantity(kg, 0.75), 0.75);
        assert.throws(() => StockService.validateQuantity(kg, 0.3), /kelipatan/);
        const pcs = { id: 'b', name: 'Telur', unit: 'pcs', allow_decimal: false, unit_step: 1 };
        assert.throws(() => StockService.validateQuantity(pcs, 1.5), /bulat/);
        assert.throws(() => StockService.validateQuantity(pcs, 0), /lebih dari 0/);
    });
    await test('decrementForSale: alokasi lintas gudang, idempoten, selisih tercatat', async () => {
        const rows = [
            { id: 'r1', warehouse_id: 'w1', quantity_on_hand: 3 },
            { id: 'r2', warehouse_id: 'w2', quantity_on_hand: 2 }
        ];
        const movements = [];
        const discrepancies = [];
        const client = fakeDb([
            ['SELECT 1 FROM tbl_inventory_movements', ([pid, ref]) => ({ rowCount: movements.filter((m) => m.ref === ref && m.pid === pid).length, rows: [] })],
            ['FROM tbl_inventory WHERE product_id', () => ({ rows: rows.filter((r) => r.quantity_on_hand > 0).sort((a, b) => b.quantity_on_hand - a.quantity_on_hand).map((r) => ({ ...r })) })],
            ['UPDATE tbl_inventory SET quantity_on_hand = quantity_on_hand - $1', ([take, id]) => { rows.find((r) => r.id === id).quantity_on_hand -= take; return { rowCount: 1 }; }],
            ['INSERT INTO tbl_inventory_movements', ([pid, wh, qty, ref]) => { movements.push({ pid, wh, qty, ref }); return { rowCount: 1 }; }],
            ['INSERT INTO tbl_stock_discrepancies', (p) => { discrepancies.push(p); return { rowCount: 1 }; }]
        ]);
        const a = await StockService.decrementForSale(client, { productId: 'p1', quantity: 4, refDoc: 'POS-1', source: 'POS_SALE' });
        assert.strictEqual(a.applied, 4);
        assert.deepStrictEqual(rows.map((r) => r.quantity_on_hand), [0, 1]);
        assert.strictEqual(movements.length, 1);
        const again = await StockService.decrementForSale(client, { productId: 'p1', quantity: 4, refDoc: 'POS-1', source: 'POS_SALE' });
        assert.strictEqual(again.skipped, true);
        assert.deepStrictEqual(rows.map((r) => r.quantity_on_hand), [0, 1]);
        const over = await StockService.decrementForSale(client, { productId: 'p1', quantity: 10, refDoc: 'POS-2', source: 'POS_SALE' });
        assert.strictEqual(over.applied, 1);
        assert.strictEqual(over.shortfall, 9);
        assert.strictEqual(discrepancies.length, 1);
    });

    console.log('ShippingService');
    const zone = { id: 1, name: 'Z', base_fee: 8000, free_above: 100000, min_order: 20000, eta_minutes: 60 };
    const shippingDb = (revenue, used) => fakeDb([
        ['FROM tbl_delivery_zones WHERE active = TRUE ORDER BY id', () => ({ rowCount: 1, rows: [zone] })],
        ['FROM tbl_platform_revenue', () => ({ rows: [{ total: revenue }] })],
        ['FROM tbl_checkout_groups', () => ({ rows: [{ total: used }] })]
    ]);
    await test('ambil di pasar: tanpa ongkir', async () => {
        const q = await ShippingService.quote(shippingDb(0, 0), { fulfillmentType: 'PICKUP', subtotal: 5000 });
        assert.strictEqual(q.customer_fee, 0);
    });
    await test('di bawah minimum belanja ditolak', async () => {
        await assert.rejects(ShippingService.quote(shippingDb(0, 0), { fulfillmentType: 'DELIVERY', subtotal: 10000 }), /Minimal belanja/);
    });
    await test('belanja kecil: pembeli bayar ongkir', async () => {
        const q = await ShippingService.quote(shippingDb(0, 0), { fulfillmentType: 'DELIVERY', subtotal: 50000 });
        assert.strictEqual(q.customer_fee, 8000);
        assert.strictEqual(q.subsidy, 0);
    });
    await test('gratis ongkir disubsidi selama anggaran ada', async () => {
        const q = await ShippingService.quote(shippingDb(0, 0), { fulfillmentType: 'DELIVERY', subtotal: 120000 });
        assert.strictEqual(q.customer_fee, 0);
        assert.strictEqual(q.subsidy, 8000);
    });
    await test('anggaran subsidi habis -> gratis ongkir otomatis berhenti', async () => {
        const q = await ShippingService.quote(shippingDb(0, 299999), { fulfillmentType: 'DELIVERY', subtotal: 120000 });
        assert.strictEqual(q.customer_fee, 8000);
        assert.strictEqual(q.subsidy, 0);
    });
    await test('anggaran ikut naik bersama pendapatan B2B', async () => {
        // 50% x 2.000.000 = 1.000.000 > anggaran awal 300.000
        const st = await ShippingService.subsidyStatus(shippingDb(2000000, 400000));
        assert.strictEqual(st.subsidy_budget_month, 1000000);
        assert.strictEqual(st.free_shipping_enabled, true);
    });

    console.log('Checkout');
    await test('barang sama digabung, jumlah tak valid ditolak', () => {
        const items = Checkout.normalizeItems([{ product_id: 'x', quantity: 1 }, { product_id: 'x', quantity: 0.5 }, { product_id: 'y', quantity: 2 }]);
        assert.deepStrictEqual(items, [{ product_id: 'x', quantity: 1.5 }, { product_id: 'y', quantity: 2 }]);
        assert.throws(() => Checkout.normalizeItems([]), /kosong/i);
        assert.throws(() => Checkout.normalizeItems([{ product_id: 'x', quantity: -1 }]), /tidak valid/i);
    });

    console.log('Kulakan bersama');
    await test('tier: makin banyak makin murah, harga mengikuti total', () => {
        const tiers = GroupBuys.normalizeTiers([{ min_qty: 100, unit_price: 9000 }, { min_qty: 50, unit_price: 9500 }]);
        assert.deepStrictEqual(tiers.map((t) => t.min_qty), [50, 100]);
        assert.strictEqual(GroupBuys.tierFor(tiers, 30), null);
        assert.strictEqual(GroupBuys.tierFor(tiers, 60).unit_price, 9500);
        assert.strictEqual(GroupBuys.tierFor(tiers, 120).unit_price, 9000);
        assert.strictEqual(GroupBuys.nextTier(tiers, 60).min_qty, 100);
        assert.strictEqual(GroupBuys.normalizeTiers([{ min_qty: 50, unit_price: 9000 }, { min_qty: 100, unit_price: 9500 }]), null);
    });

    console.log('Vault API integration');
    await test('secret dienkripsi dan dapat dibuka kembali tanpa pernah disimpan plaintext', () => {
        const previous = process.env.INTEGRATION_ENCRYPTION_KEY;
        process.env.INTEGRATION_ENCRYPTION_KEY = '11'.repeat(32);
        try {
            const Vault = require('../src/services/SecretVault');
            const encrypted = Vault.encrypt('contoh-api-secret');
            assert.ok(!JSON.stringify(encrypted).includes('contoh-api-secret'));
            assert.strictEqual(Vault.decrypt({
                secret_ciphertext: encrypted.ciphertext,
                secret_iv: encrypted.iv,
                secret_auth_tag: encrypted.authTag
            }), 'contoh-api-secret');
        } finally {
            if (previous === undefined) delete process.env.INTEGRATION_ENCRYPTION_KEY;
            else process.env.INTEGRATION_ENCRYPTION_KEY = previous;
        }
    });

    console.log('Pembatas laju');
    await test('memblokir setelah batas dan memberi Retry-After', () => {
        const limiter = createRateLimiter({ windowMs: 60000, max: 3 });
        const res = { headers: {}, setHeader(k, v) { this.headers[k] = v; }, status(c) { this.code = c; return this; }, json(b) { this.body = b; } };
        let passedCount = 0;
        for (let i = 0; i < 5; i += 1) limiter({ ip: '1.2.3.4' }, res, () => { passedCount += 1; });
        assert.strictEqual(passedCount, 3);
        assert.strictEqual(res.code, 429);
        assert.ok(res.headers['Retry-After']);
    });

    console.log(`\n${passed} uji lulus${process.exitCode ? ', ADA YANG GAGAL' : ''}`);
    process.exit(process.exitCode || 0);
})();
