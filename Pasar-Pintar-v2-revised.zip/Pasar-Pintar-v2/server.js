require('dotenv').config();

const express = require('express');
const {
    securityHeaders,
    requestId,
    createRateLimiter,
    notFoundHandler,
    errorHandler,
    validateEnv
} = require('./src/middleware/security');

// Gagal cepat bila konfigurasi wajib belum lengkap.
validateEnv();

const pool = require('./src/config/db');

const authRoutes = require('./src/routes/auth');
const merchantRoutes = require('./src/routes/merchant');
const merchantOrdersV2Routes = require('./src/routes/merchantOrdersV2');
const merchantSalesV2Routes = require('./src/routes/merchantSalesV2');
const merchantAccountV2Routes = require('./src/routes/merchantAccountV2');
const courierRoutes = require('./src/routes/courier');
const financeRoutes = require('./src/routes/finance');
const warehouseRoutes = require('./src/routes/warehouse');
const crmRoutes = require('./src/routes/crm');
const purchaseOrderRoutes = require('./src/routes/purchaseOrders');
const orderRoutes = require('./src/routes/orders');
const purchaseOrderApprovalRoutes = require('./src/routes/purchaseOrderApproval');
const checkoutV2Routes = require('./src/routes/checkoutV2');
const paymentV2Routes = require('./src/routes/paymentV2');
const creditAccountsV1Routes = require('./src/routes/creditAccountsV1');
const purchaseOrderReceivingRoutes = require('./src/routes/purchaseOrderReceiving');
const evolutionWebhookRoutes = require('./src/routes/evolutionWebhook');
const whatsappOperationsRoutes = require('./src/routes/whatsappOperations');
const adminEnterpriseRoutes = require('./src/routes/adminEnterprise');

// ---- V2 ----
const checkoutV3Routes = require('./src/routes/checkoutV3');
const posRoutes = require('./src/routes/pos');
const opsRoutes = require('./src/routes/ops');
const groupBuyRoutes = require('./src/routes/groupBuys');
const StockService = require('./src/services/inventory/StockService');

const app = express();

// Di belakang reverse proxy (Nginx/Caddy) agar req.ip benar untuk pembatas laju.
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);
app.disable('x-powered-by');

app.use(requestId);
app.use(securityHeaders);
app.use(express.json({ limit: '200kb' }));
app.use(express.static('public'));

// Pembatas laju umum untuk seluruh API (login/daftar punya pembatas sendiri yang lebih ketat).
app.use(
    '/api',
    createRateLimiter({
        windowMs: 60 * 1000,
        max: Number(process.env.API_RATE_LIMIT_PER_MIN || 300),
        keyFn: (req) => req.ip
    })
);

// Inisialisasi Kernel Enterprise
const CommerceKernel = require('./src/kernel/EventKernel');
require('./src/kernel/productSubscribers');
require('./src/kernel/inventorySubscribers');
require('./src/kernel/orderSubscribers');
// Automatic finance posting is intentionally paused until each payment, commission,
// merchant payable, voucher subsidy and gateway fee has a verified accounting mapping.
require('./src/kernel/warehouseSubscribers');
require('./src/kernel/crmSubscribers');
require('./src/kernel/whatsappSubscribers');
require('./src/kernel/purchaseOrderSubscribers');

// Modul eksperimental (brain/copilot/agents/aiEngine + agen restock otomatis).
// Perilaku lama DIPERTAHANKAN (aktif). Rekomendasi: matikan dengan DISABLE_EXPERIMENTAL=true
// bila tidak dipakai, agar permukaan serangan kecil dan tidak ada PO otomatis tak terduga.
const experimental = String(process.env.DISABLE_EXPERIMENTAL || '').toLowerCase() !== 'true';
if (experimental) {
    require('./src/brain/GraphBuilder');
    require('./src/brain/agents/InventoryAgent');
}

// Rute modular
app.use('/api', authRoutes(pool, CommerceKernel));
app.use('/api', merchantRoutes(pool, CommerceKernel));
app.use('/api', merchantOrdersV2Routes);
app.use('/api', merchantSalesV2Routes);
app.use('/api', merchantAccountV2Routes);
app.use('/api', courierRoutes(pool, CommerceKernel));
app.use('/api', financeRoutes);
app.use('/api', warehouseRoutes);
app.use('/api', crmRoutes);
app.use('/api', purchaseOrderReceivingRoutes);
app.use('/api', purchaseOrderApprovalRoutes);
app.use('/api', purchaseOrderRoutes);
app.use('/api', checkoutV2Routes);
app.use('/api', checkoutV3Routes);
app.use('/api', paymentV2Routes);
app.use('/api', creditAccountsV1Routes);
app.use('/api', orderRoutes);
app.use('/api', posRoutes);
app.use('/api', opsRoutes);
app.use('/api', groupBuyRoutes);
app.use('/api', evolutionWebhookRoutes(pool, CommerceKernel));
app.use('/api', whatsappOperationsRoutes(pool));
app.use('/api', adminEnterpriseRoutes);

if (experimental) {
    app.use('/api', require('./src/routes/aiEngine')(pool, CommerceKernel));
    app.use('/api', require('./src/routes/brain'));
    app.use('/api', require('./src/routes/copilot'));
    app.use('/api', require('./src/routes/agents'));
}

// Health check minimal: tanpa detail internal (nama event, jumlah audit).
app.get('/api/health', async (req, res) => {
    try {
        await pool.query('SELECT 1');
        res.json({ status: 'success', db: 'ok' });
    } catch (err) {
        res.status(503).json({ status: 'error', db: 'down' });
    }
});

app.use(notFoundHandler);
app.use((req, res) => {
    res.status(404).json({ status: 'error', message: 'Endpoint tidak ditemukan' });
});
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server Pasar Pintar berjalan di port ${PORT}`);
});

// Pekerjaan berkala stok: lepas tahanan kedaluwarsa & selesaikan komit yang terlewat.
const reconcilerTimer = StockService.startReconciler(pool);

function shutdown(signal) {
    console.log(`[${signal}] mematikan server dengan rapi...`);
    clearInterval(reconcilerTimer);
    server.close(() => {
        pool.end().finally(() => process.exit(0));
    });
    setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
