/* Service worker kasir: menyimpan "cangkang" aplikasi agar bisa dibuka tanpa internet.
 * Data (katalog, antrean penjualan) disimpan di IndexedDB oleh pos.html, bukan di sini. */
const CACHE = 'pp-pos-shell-v1';
const SHELL = ['/pos.html', '/pos-manifest.webmanifest', '/logo-pasar-pintar.jpg'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  if (url.pathname.startsWith('/api/')) return; // API tidak pernah di-cache
  if (!SHELL.includes(url.pathname)) return;
  // jaringan dulu agar versi terbaru terpakai; jatuh ke cache saat offline
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
        return res;
      })
      .catch(() => caches.match(e.request))
  );
});
