# Audit Kesenjangan Admin, Finance, dan IT — Pasar Pintar V2

## Ringkasan keputusan

Kode V2 sudah memiliki fondasi transaksi marketplace, POS, stok, checkout grup, WhatsApp, CRM, gudang, dan pembelian. Namun belum memiliki satu control center admin yang menyatukan seluruh operasi. Modul akuntansi lama juga belum cukup aman untuk menjadi sumber laporan resmi. Perubahan V3 dalam arsip ini adalah fondasi administrasi tambahan, bukan sertifikasi kesiapan produksi.

## Temuan berbasis kode

1. `public/ceo.html` sebelumnya hanya menampilkan empat metrik dan meminta `/api/metrics`. Metrik pendapatan membaca `tbl_general_ledger`, sedangkan tabel itu tidak dibuat dalam `enterprise_schema.sql` maupun migrasi V2.
2. `src/routes/finance.js` sebelumnya hanya mengambil 50 baris dari `tbl_general_ledger`; tidak ada chart of accounts, periode akuntansi, posting jurnal, neraca saldo, laba rugi, atau neraca.
3. `src/kernel/financeSubscribers.js` sebelumnya memeriksa dua baris lalu memasukkan debit dan kredit dalam dua query terpisah tanpa satu transaksi database. Pola ini rentan terhadap event paralel dan jurnal setengah jadi.
4. Checkout V3 multi-merchant tersedia di backend, tetapi `public/customer.html` masih memakai `/api/orders/checkout-v2` dan membatasi keranjang ke satu merchant. Alur pelanggan belum konsisten dengan target satu keranjang banyak jongko.
5. Adapter integrasi masih menggunakan environment variable. Tidak ada pengelolaan secret terpusat melalui admin sebelumnya.
6. Monitoring health utama hanya memeriksa koneksi database. Worker heartbeat sudah ada sebagai fondasi tetapi belum ditampilkan dalam control center.
7. Skema repo bukan dump skema produksi lengkap; dokumentasi V2 sudah menyebut tabel runtime yang tidak dibuat oleh `enterprise_schema.sql`.

## Implementasi dalam patch ini

- Admin Control Center `/admin-v2.html`, dan `ceo.html` diarahkan ke control center tersebut.
- Voucher: kode, nama campaign, persentase, nominal, gratis ongkir, minimum belanja, maksimum diskon, kuota total, batas per pelanggan, periode, aktif/nonaktif.
- Redeem voucher V3 dilakukan dalam transaksi checkout, mengunci baris voucher untuk melindungi kuota bersamaan, dan mencatat redemption.
- Akuntansi double-entry: chart of accounts awal, periode, jurnal seimbang, ledger, neraca saldo, laba rugi, neraca, mutasi akun kas/bank, pembalikan jurnal, dan penutupan periode.
- Akses staf: role `FINANCE`, `IT_ADMIN`, `OPERATIONS_ADMIN`; izin diberikan terpisah dan role 4 tetap Super Admin.
- Integrasi: secret write-only dienkripsi AES-256-GCM dengan kunci server yang terpisah. Secret tidak pernah dikembalikan dari endpoint list.
- IT: ping DB, uptime, versi Node, memori proses, load average, worker heartbeat, dan audit log admin.
- Tabel `tbl_general_ledger` dipertahankan sebagai kompatibilitas untuk service TEMPO/kredit lama. Laporan formal V3 membaca jurnal baru, bukan tabel kompatibilitas.
- Posting jurnal otomatis lama dihentikan agar total transaksi pelanggan tidak salah diakui sebagai pendapatan Pasar Pintar.

## Hal yang belum boleh dianggap selesai

### Marketplace Admin
- Moderasi produk/kategori, persetujuan merchant dan KYC, komisi per kategori/merchant, retur/refund, sengketa, chargeback, SLA kurir, fraud/risk rules, campaign banner, iklan/sponsored listing, flash sale, loyalty tiers, referral, customer support/ticketing, review moderation, dan bulk catalog tools.
- Voucher saat ini global; segmentasi pelanggan, voucher merchant/kategori/produk, stacking rules, approval campaign, budget cap, dan laporan ROI belum tersedia.
- Frontend pelanggan belum menggunakan checkout V3. Voucher V3 belum tampil di cart pelanggan lama; multi-merchant belum diaktifkan pada UI.

### Finance
- Migrasi saldo awal dan rekonsiliasi semua transaksi historis.
- Subledger piutang pelanggan, utang pemasok, payable merchant, settlement, payout, refund, reserve, komisi, dan fee gateway harus direkonsiliasi ke jurnal umum.
- Pemetaan pendapatan platform vs dana titipan merchant; HPP/COGS, persediaan perpetual, pajak/PPN/PPh, aset tetap, depresiasi, accrual, prepaid, payroll, budgeting, cash forecast, bank reconciliation, dan laporan arus kas formal.
- Tutup buku bulanan/tahunan, retained earnings, audit trail koreksi, approval matrix dua tingkat, bukti transaksi, export XLSX/PDF, dan audit eksternal.
- Chart of accounts seed adalah starter template. Finance wajib menyesuaikan dengan kebijakan akuntansi dan konsultan pajak/auditor Indonesia.

### IT & Security
- Monitoring CPU/disk/DB connection pool secara host-level, APM/tracing, log aggregation, alerting WhatsApp/email, uptime probe eksternal, backup verification/restore drill, vulnerability scanning, dependency scanning, WAF, secret rotation, dan incident response.
- Penyimpanan API Key melalui database belum dihubungkan ke adapter runtime Midtrans, Evolution, Gemini, FCM, SMTP, Maps, dan storage. Penghubung per provider harus diselesaikan sebelum menghapus env var lama.
- Secret key encryption rotation dan key versioning belum tersedia. Simpan kunci di secret manager, backup terenkripsi, dan buat prosedur rotasi.

## Matriks akses yang disarankan

| Role | Izin minimum |
|---|---|
| Super Admin (role 4) | Semua; gunakan untuk konfigurasi kritis saja |
| FINANCE | `admin.finance.read`; `admin.finance.post` hanya untuk petugas yang berwenang |
| IT_ADMIN | `admin.security.read`, `admin.integrations.manage`; jangan otomatis diberi akses jurnal |
| OPERATIONS_ADMIN | `admin.operations.manage`, `admin.vouchers.manage` sesuai tanggung jawab |

## Validasi sebelum deploy

- Backup database, ekspor skema produksi, lalu jalankan migrasi V2 dan V3 di staging.
- Pastikan role name dan ID aktual, kolom `tbl_users.updated_at`, tabel `tbl_checkout_groups`, `tbl_orders_v2`, `tbl_customers`, dan objek lain cocok dengan skema produksi.
- Uji voucher: kode tidak valid, belum aktif, kedaluwarsa, minimum order, batas per-user, kuota habis, dua checkout bersamaan, quote rollback, pickup vs delivery, dan payment gateway amount.
- Uji jurnal: tidak seimbang ditolak, akun tidak aktif ditolak, periode tertutup ditolak, reversal membuat jurnal lawan, duplikasi sumber, dan saldo debit-kredit sama.
- Uji secret: salah kunci gagal decrypt, secret tidak muncul di GET/log, secret lama tetap terjaga saat update konfigurasi tanpa secret, dan prosedur backup kunci.
- Uji seluruh flow order, TEMPO, PAY_AT_OUTLET, refund, settlement merchant, POS offline, dan webhook.
- Jangan deploy langsung ke produksi hanya berdasarkan `npm test` dan pemeriksaan sintaks.
