# Perubahan V2

Ringkasan: memperbaiki celah stok dan pembayaran, mewujudkan konsep inti (banyak jongko, satu checkout), menambah kasir offline yang terintegrasi, daftar belanja WhatsApp, kulakan bersama, pagar subsidi ongkir, dan pengamanan dasar.

## 1. Perbaikan celah dari analisis

| Celah (V1) | Perbaikan (V2) | Berkas |
|---|---|---|
| Checkout menolak pesanan lebih dari satu lapak | Checkout multi-lapak: 1 grup bayar + 1 order per lapak | `checkoutV3.js`, `GroupCheckoutService.js` |
| Stok tidak ditahan; dua pembeli bisa memesan stok terakhir; stok baru dikurangi lewat event memori setelah uang masuk | Penahanan stok saat checkout (TTL 30 menit), dikomit **di transaksi yang sama** dengan konfirmasi bayar; pekerjaan berkala menyelesaikan yang terlewat | `StockService.js`, `GroupPaymentService.js`, `warehouseSubscribers.js` |
| Tidak ada ongkir | Zona antar, minimum belanja, gratis ongkir dengan pagar subsidi otomatis | `ShippingService.js`, `ops.js` |
| Stok bilangan bulat tanpa satuan | Kuantitas desimal (kg, ons, ikat), `unit_step`, mode stok `COUNTED`/`TOGGLE` (ada/habis) | migrasi 002 |
| Bot WhatsApp hanya kata kunci, daftar multi-baris diabaikan | Daftar belanja: pembaca bawaan + Gemini opsional, pencocokan ke katalog, konfirmasi manusia | `ShoppingListParser.js`, `GeminiListParser.js`, `ShoppingListHandler.js` |
| Tidak ada pembatas login, galat seragam, `is_active` diabaikan, pesan galat DB bocor | Pembatas laju, login seragam, cek `is_active`, kebijakan password, 41 respons 500 tidak lagi membocorkan detail | `security.js`, `auth.js` |
| Webhook Midtrans membandingkan signature tidak aman waktu | `timingSafeEqual` + cabang pembayaran grup | `paymentV2.js` |
| `.env.example` kurang ±14 variabel, tidak ada validasi saat start | Dilengkapi, server gagal cepat jika konfigurasi wajib kosong | `.env.example`, `validateEnv()` |
| Health check membuka nama event & jumlah audit | Hanya status DB | `server.js` |

## 2. Fitur baru

- **Kasir (POS) offline-first** (`/pos.html`, `src/routes/pos.js`): dipasang sebagai PWA, katalog di IndexedDB, antrean penjualan lokal, sinkronisasi **idempoten** (`client_sale_id`), shift kas, void 24 jam, pesanan online tampil di layar yang sama. Penjualan fisik selalu menang: jika stok sistem kurang, penjualan tetap dicatat dan selisih masuk daftar tinjauan.
- **Stok & harga cepat**: tombol Ada/Habis, opname, ubah harga massal (riwayat harga tersimpan), satuan jual (`ops.js`).
- **Papan "Harga hari ini"** publik: `GET /api/public/price-board`.
- **Checkout multi-lapak + QRIS tunggal** (`/api/v3/checkout`).
- **Pagar subsidi ongkir**: anggaran bulan ini = `max(SUBSIDY_BOOTSTRAP_BUDGET, SUBSIDY_CAP_PCT x pendapatan B2B)`. Bila habis, gratis ongkir otomatis berhenti.
- **Kulakan bersama** (`groupBuys.js`): komitmen banyak lapak, harga bertingkat, Pasar Pintar tidak memegang uang/barang, pendapatan dicatat saat selesai.
- **KPI mingguan** (`GET /api/admin/kpi/weekly`): lima angka (lapak aktif, pesanan/hari, ongkir ditanggung/pesanan, hasil B2B, pelanggan pesan ulang) + status anggaran subsidi.
- **Pendapatan platform** (`tbl_platform_revenue`) dan **selisih stok** (`tbl_stock_discrepancies`).

## 3. Yang dihapus

- Endpoint legacy yang sudah mengembalikan 410: `POST /api/purchase`, `GET /api/courier/tasks`, `POST /api/courier/update`, `POST /api/orders/checkout`.
- Dependensi ganda `bcryptjs` (tetap memakai `bcrypt`).
- `test-server.js` (server contoh tanpa dipakai).
- Logika stok lama di `warehouseSubscribers.js` (digantikan `StockService`).

## 4. Yang menurut saya sebaiknya dihapus (belum saya hapus karena bisa mengubah perilaku produksi)

1. **Modul eksperimental `brain/`, `copilot`, `agents`, `aiEngine`** (±1.400 baris). Tidak dipakai halaman publik mana pun. Terutama `InventoryAgent`, yang bisa membuat purchase order otomatis tanpa persetujuan manusia. Matikan dengan `DISABLE_EXPERIMENTAL=true`; hapus kodenya setelah yakin tidak dipakai.
2. **Tumpukan tempo/kredit pelanggan** (`creditAccountsV1`, layanan piutang, ±7 skrip uji). Utang pelanggan menambah risiko hukum dan arus kas; belum dibutuhkan sebelum model utama terbukti.
3. **`XenditAdapter.js`** (stub 19 baris, tidak berfungsi).
4. **`public/index`** (berkas tanpa ekstensi, berbeda dari `index.html`): kemungkinan sisa lama.
5. **Halaman dan modul yang tidak dipakai pedagang nyata** (mis. dasbor CEO) sampai ada pengguna yang membutuhkannya. Setiap halaman tambahan harus dirawat dan diamankan.

## 5. Risiko dan hal yang BELUM terbukti (baca sebelum produksi)

- **Saya tidak bisa menjalankan aplikasi atau database di sini.** Yang sudah terverifikasi: sintaks seluruh proyek (108 file JS + skrip inline HTML) dan 18 uji unit logika murni (`npm test`). **Belum terverifikasi:** semua query SQL, migrasi, alur pembayaran Midtrans, dan webhook WhatsApp terhadap database/layanan nyata. Jalankan di staging dengan salinan data.
- **Skema produksi tidak ada di repo.** `enterprise_schema.sql` tidak membuat `tbl_orders_v2`, `tbl_event_store`, dan beberapa tabel lain, dan `tbl_order_items` di sana masih mereferensikan `tbl_orders`. Jalankan `npm run db:export-schema` untuk menyimpan skema nyata ke git. Migrasi 002 hanya **menambah** objek dan memeriksa tipe kolom lebih dulu.
- Mengubah kolom stok dari `INT` ke `NUMERIC(12,3)` gagal bila ada view lain yang bergantung padanya; migrasi akan berhenti dengan pesan jelas (`ON_ERROR_STOP`).
- `movement_type` baru `SALE_VOID` bisa ditolak jika database produksi punya CHECK constraint pada kolom itu.
- Retry pembayaran grup yang kedaluwarsa belum didukung (pembeli membuat pesanan baru). Itu disengaja agar `order_id` Midtrans tidak bentrok.
- Pembatas laju bersifat per-proses (di memori). Bila menjalankan banyak instance, pindahkan ke Redis.
- Nilai zona antar bawaan (Rp8.000, gratis di atas Rp100.000, minimum Rp20.000) hanyalah **contoh**. Ganti lewat `/api/admin/delivery-zones`.
- Gemini bersifat opsional dan hanya membaca teks; harga, stok, dan pembuatan pesanan tetap dari kode dan database.
- Token login disimpan di `localStorage` (pola lama). Halaman kasir meng-escape data dinamis, tetapi halaman lama belum diaudit satu per satu untuk XSS.


## 6. Tambahan Admin Enterprise (audit lanjutan)

- `public/admin-v2.html`: Control Center admin dengan menu ringkasan, voucher, keuangan, integrasi, dan hak akses.
- `migrations/003_marketplace_admin_finance.sql`: tabel permission staf, audit admin, voucher dan redemption, chart of accounts, periode, jurnal berpasangan, dan konfigurasi integrasi terenkripsi.
- `src/routes/adminEnterprise.js`: API admin voucher, laporan akuntansi, posting/pembalikan jurnal, pengaturan integrasi, dan permission staf.
- `src/services/SecretVault.js`: enkripsi AES-256-GCM untuk secret integrasi.
- `src/services/checkout/GroupCheckoutService.js`: validasi dan redeem voucher dalam transaksi checkout grup; kuota global dan per-user dikunci.
- `src/routes/finance.js`: endpoint ledger lama membaca model jurnal V3.
- Posting jurnal otomatis legacy dihentikan agar nilai order tidak keliru dicatat sebagai pendapatan platform. Pemetaan transaksi marketplace wajib diselesaikan sebelum mengaktifkan posting otomatis.
