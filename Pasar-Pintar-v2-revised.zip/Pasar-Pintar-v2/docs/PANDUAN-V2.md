# Panduan V2

## 1. Migrasi (urutan aman)
1. Backup penuh database.
2. `npm run db:export-schema` (simpan `schema_snapshot.sql` ke git).
3. Di **staging**: `npm run db:migrate:v2` lalu jalankan aplikasi dan uji manual (bagian 6).
4. Atur zona antar: `POST /api/admin/delivery-zones` (nilai bawaan hanyalah contoh).
5. Atur satuan jual barang desimal: `PATCH /api/merchant/products/:id/selling-unit` (`{"unit":"kg","allow_decimal":true,"unit_step":0.25}`). Untuk sayur/ikan segar tanpa hitung angka, pakai `"stock_mode":"TOGGLE"`.
6. Produksi: ulangi langkah 1 dan 3.

## 2. Alur WhatsApp (daftar belanja)
Pembeli mengirim:
```
cabe rawit 1/4 kg
bawang merah sekilo
telur 2 kg
```
Bot menampilkan ringkasan per lapak, ongkir, dan total. Perintah lanjutan: `antar ke <alamat>`, `AMBIL`, `KONFIRMASI`, `BATAL`, lalu `BAYAR` untuk satu QRIS seluruh keranjang. Harga atau stok yang berubah sebelum konfirmasi memunculkan ringkasan baru yang harus dikonfirmasi lagi.

Opsional Gemini: isi `GEMINI_API_KEY` dan `GEMINI_MODEL`. Tanpa keduanya, pembaca bawaan dipakai.

## 3. Kasir offline
Buka `https://<domain>/pos.html` di HP/tablet pedagang, masuk dengan akun merchant, lalu "Tambahkan ke layar utama". Setelah dibuka sekali online, aplikasi bisa dibuka tanpa internet. Penjualan disimpan di perangkat dan dikirim otomatis saat online (juga tiap 30 detik). Jika sesi habis, masuk lagi: antrean tidak hilang.

## 4. Kulakan bersama
1. Admin membuat kampanye: `POST /api/groupbuys` dengan `tiers` (makin banyak makin murah).
2. Pedagang ikut: `POST /api/groupbuys/:id/commit {"quantity":20}`.
3. Admin menutup: `POST /api/groupbuys/:id/close` (hasil: harga akhir dan alokasi per lapak).
4. Tiap lapak membayar langsung ke prinsipal; setelah barang sampai: `POST /api/groupbuys/:id/settle` mencatat bagian pendapatan Pasar Pintar.

## 5. Ringkasan API baru
| Metode | Path | Peran |
|---|---|---|
| POST | `/api/v3/checkout/quote` / `/api/v3/checkout` | pelanggan |
| POST | `/api/v3/checkout/:id/pay` | pelanggan |
| GET | `/api/v3/checkout/:id`, `/api/v3/shipping/zones` | pelanggan/admin |
| GET | `/api/pos/catalog`, `/api/pos/summary` | merchant |
| POST | `/api/pos/sync`, `/api/pos/sales`, `/api/pos/sales/:id/void` | merchant |
| GET/POST | `/api/pos/shifts/current`, `/open`, `/close` | merchant |
| PATCH/POST | `/api/merchant/stock/quick`, `/stock/set`, `/prices/quick` | merchant |
| PATCH | `/api/merchant/products/:id/selling-unit` | merchant |
| GET | `/api/public/price-board` | publik |
| GET | `/api/admin/kpi/weekly`, `/stock-discrepancies` | admin |
| POST/PATCH | `/api/admin/delivery-zones`, `/platform-revenue` | admin |
| * | `/api/groupbuys...` | admin/merchant |

## 6. Daftar uji manual di staging
1. **Stok terakhir:** barang stok 1; dua akun pelanggan checkout bersamaan. Hasil benar: satu berhasil, satu menerima 409 "tidak mencukupi".
2. **Satu keranjang, dua lapak:** checkout, bayar QRIS satu kali (simulator Midtrans). Kedua order menjadi `PAID`, stok kedua lapak berkurang tepat sekali.
3. **Kedaluwarsa:** checkout lalu jangan bayar; setelah TTL, order `CANCELLED` dan stok kembali tersedia (lihat log `[STOCK RECONCILE]`).
4. **Webhook ganda:** kirim notifikasi Midtrans yang sama dua kali; stok tidak berkurang dua kali.
5. **Kasir offline:** putus internet, catat 3 penjualan, sambungkan lagi; ketiganya masuk sekali. Kirim ulang antrean yang sama; hasilnya `duplicate`, stok tidak berubah.
6. **Penjualan melebihi stok sistem:** kasir tetap mencatat; muncul di `/api/admin/stock-discrepancies`.
7. **Gratis ongkir:** belanja di atas ambang; subsidi tercatat. Habiskan anggaran; gratis ongkir berhenti.
8. **Login:** 11 kali password salah beruntun mengembalikan 429.


## 7. Admin, Finance, IT, dan integrasi (tambahan)

1. Backup database penuh dan uji migrasi V2 terlebih dahulu. Setelah sukses, jalankan `npm run db:migrate:v3` di staging.
2. Isi `INTEGRATION_ENCRYPTION_KEY` dengan hasil `openssl rand -hex 32`. Jangan memakai JWT secret yang sama. Simpan kunci di secret manager/lingkungan server; jangan commit `.env`.
3. Login sebagai Super Admin (role 4), buka `/admin-v2.html`.
4. Buat periode akuntansi sebelum posting jurnal. Periode yang sudah ditutup tidak menerima jurnal baru.
5. Jurnal harus seimbang (total debit = total kredit). Jurnal terposting tidak diedit; gunakan jurnal pembalik.
6. Buat voucher melalui menu Voucher & Promo. Kode voucher diterapkan di `POST /api/v3/checkout` dengan field `promo_code`; pemakaian dan kuota dikunci dalam transaksi checkout.
7. Berikan izin Finance dan IT kepada user melalui menu Hak Akses. Berikan `admin.finance.read` untuk laporan dan `admin.finance.post` untuk posting/penutupan periode. Jangan memberikan `admin.access.manage` kepada staf biasa.
8. Menu API & Integrasi menyimpan secret terenkripsi AES-256-GCM. Secret hanya dapat ditulis, tidak dapat dibaca kembali melalui API. Mengaktifkan integrasi hanya menyimpan konfigurasi; belum melakukan tes koneksi ke provider.

### Batasan yang harus diselesaikan sebelum produksi
- UI pelanggan pada ZIP ini masih memakai endpoint checkout V2 satu merchant. Endpoint V3 sudah menerima voucher dan multi-merchant, tetapi UI pelanggan belum dipindahkan ke alur pembayaran grup. Jangan menghapus validasi satu merchant di UI sebelum alur payment, pickup, dan tempo dimigrasikan dan diuji.
- Jurnal otomatis lama dihentikan. Akuntansi marketplace harus memisahkan uang titipan/utang merchant dari pendapatan Pasar Pintar. Gross order tidak boleh otomatis dianggap pendapatan platform.
- Belum ada migrasi saldo awal, rekonsiliasi bank/payment gateway, subledger AR/AP lengkap, pemetaan pajak, HPP/COGS, aset tetap dan depresiasi, persediaan akuntansi, closing laba ditahan, serta laporan arus kas formal metode langsung/tidak langsung.
- Mutasi kas/bank yang disediakan adalah ringkasan pergerakan akun kas, bukan laporan arus kas formal.
- Pengaturan API saat ini menyimpan secret dan metadata; adapter Midtrans/Evolution/Gemini yang ada masih membaca environment variable. Penghubung runtime dari tabel integrasi ke setiap adapter perlu dilakukan per provider setelah uji staging.
- Migrasi V3 belum dapat diuji terhadap database nyata dari arsip ini. `enterprise_schema.sql` bukan dump skema produksi lengkap. Ekspor schema database staging/produksi dan cocokkan objek sebelum migrasi.
